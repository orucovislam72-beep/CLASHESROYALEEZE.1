export interface AppVersionInfo {
  versionName: string;
  versionCode: number;
  buildDate: string;
  appId: string;
}

export const CURRENT_APP_VERSION: AppVersionInfo = {
  versionName: '1.0.0',
  versionCode: 1,
  buildDate: '2026-08-17',
  appId: 'com.irondominiongame.app'
};
