import { GoogleGenAI } from "@google/genai";

// Client-side direct Gemini API integration configured for standalone Capacitor Android APK builds.
// API Key is injected at build time via VITE_GEMINI_API_KEY environment variable.
const CLIENT_GEMINI_KEY = (import.meta.env.VITE_GEMINI_API_KEY || "").trim();

let clientGenAI: GoogleGenAI | null = null;

function getClientGenAI(): GoogleGenAI | null {
  if (clientGenAI) return clientGenAI;
  if (CLIENT_GEMINI_KEY) {
    clientGenAI = new GoogleGenAI({
      apiKey: CLIENT_GEMINI_KEY,
    });
    return clientGenAI;
  }
  return null;
}

export async function generateWithGemini(prompt: string, systemInstruction?: string): Promise<any> {
  const ai = getClientGenAI();

  // 1. Direct client-side Gemini execution (Primary for Android APK)
  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          systemInstruction:
            systemInstruction ||
            "You are the Causal Inference Engine for Iron Dominion. Process simulation requests and return valid JSON data only.",
          responseMimeType: "application/json",
          temperature: 0.7,
        },
      });

      let text = response.text || "{}";
      text = text.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      return JSON.parse(text);
    } catch (error) {
      console.error("Direct Gemini API error:", error);
      throw error;
    }
  }

  // 2. Fallback to /api/gemini proxy if running in web development mode without client key
  try {
    const response = await fetch("/api/gemini", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ prompt, systemInstruction }),
    });

    if (!response.ok) {
      const errData = await response.json().catch(() => ({}));
      throw new Error(errData.error || `HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Gemini API connection error:", error);
    throw error;
  }
}
