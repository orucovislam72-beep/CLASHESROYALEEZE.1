// Game State Manager & Simulation Loop Controller
import {
  GameState,
  INITIAL_GAME_STATE,
  GameSpeed,
  formatDate,
  ChronicleEntry,
  DeferredConsequence,
  ActiveCrisisModal,
  RANDOM_CRISES_POOL,
  SPY_MISSION_TYPES,
  SpyAgent
} from './gameState';
import { audioEngine } from './audioEngine';
import { radioLogsStore } from './radioLogsStore';
import { generateWithGemini } from './geminiAI';
import { aiEventDirector } from './aiEventDirector';

type StateListener = (state: GameState) => void;

class GameStore {
  private state: GameState;
  private listeners: Set<StateListener> = new Set();
  private timer: number | null = null;
  private isGeneratingEvent = false;
  private storageKey = 'iron_dominion_grand_state_v1';

  constructor() {
    const saved = localStorage.getItem(this.storageKey);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Ensure structure matches INITIAL_GAME_STATE
        this.state = { ...INITIAL_GAME_STATE, ...parsed };
      } catch (e) {
        console.warn('Failed to parse saved game state, using initial', e);
        this.state = INITIAL_GAME_STATE;
      }
    } else {
      this.state = INITIAL_GAME_STATE;
    }

    this.startSimulationLoop();
  }

  public getState(): GameState {
    return this.state;
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.save();
    // Defer notification to avoid synchronous state updates during React's render phase
    setTimeout(() => {
      this.listeners.forEach(cb => cb(this.state));
    }, 0);
  }

  private save() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.state));
    } catch (e) {
      console.error('Error saving state:', e);
    }
  }

  public resetGame() {
    this.state = JSON.parse(JSON.stringify(INITIAL_GAME_STATE));
    this.notify();
    audioEngine.playClick('heavy');
  }

  public setSpeed(speed: GameSpeed) {
    this.state.gameSpeed = speed;
    this.state.isPaused = speed === 0;
    this.restartLoop();
    this.notify();
    audioEngine.playClick('switch');
  }

  public togglePause() {
    this.state.isPaused = !this.state.isPaused;
    if (!this.state.isPaused && this.state.gameSpeed === 0) {
      this.state.gameSpeed = 1;
    }
    this.restartLoop();
    this.notify();
    audioEngine.playClick('toggle');
  }

  public completeTutorial() {
    this.state.tutorialCompleted = true;
    this.notify();
    audioEngine.playStamp();
  }

  public resetTutorial() {
    this.state.tutorialCompleted = false;
    this.notify();
    audioEngine.playTuningSweep();
  }

  public randomizeScenario() {
    // 1. Reset to baseline
    const s = JSON.parse(JSON.stringify(INITIAL_GAME_STATE));

    // 2. Randomize Global Metrics
    s.stability = Math.max(10, Math.min(95, s.stability + (Math.random() * 30 - 15)));
    s.warWeariness = Math.max(0, Math.min(80, s.warWeariness + (Math.random() * 20 - 5)));
    s.militaryReadiness = Math.max(30, Math.min(100, s.militaryReadiness + (Math.random() * 20 - 10)));

    // 3. Randomize Resources (+/- 25%)
    Object.keys(s.resources).forEach(key => {
      if (typeof s.resources[key] === 'number') {
        const variance = 1 + (Math.random() * 0.5 - 0.25);
        s.resources[key] = Math.round(s.resources[key] * variance);
      }
    });

    // 4. Randomize Factions
    s.factions = s.factions.map(f => ({
      ...f,
      loyalty: Math.max(10, Math.min(100, f.loyalty + (Math.random() * 40 - 20))),
      influence: Math.max(5, Math.min(60, f.influence + (Math.random() * 20 - 10)))
    }));

    // 5. Randomize Countries (Political Map)
    s.countries = s.countries.map(c => ({
      ...c,
      relations: Math.max(-100, Math.min(100, c.relations + (Math.random() * 60 - 30))),
      tension: Math.max(0, Math.min(100, c.tension + (Math.random() * 40 - 10))),
      intelCoverage: Math.max(5, Math.min(80, c.intelCoverage + (Math.random() * 30 - 15)))
    }));

    // 6. Randomize Provinces
    s.provinces = s.provinces.map(p => ({
      ...p,
      unrest: Math.max(0, Math.min(100, p.unrest + (Math.random() * 40 - 20))),
      controlPercent: Math.max(30, Math.min(100, p.controlPercent + (Math.random() * 30 - 15))),
      garrisonDivisions: Math.max(1, Math.min(12, p.garrisonDivisions + Math.floor(Math.random() * 5 - 2)))
    }));

    // 7. Pick a random starting crisis from pool
    const pool = RANDOM_CRISES_POOL;
    if (pool.length > 0) {
      const randomIndex = Math.floor(Math.random() * pool.length);
      const selected = pool[randomIndex];
      s.activeCrisis = {
        ...selected,
        id: `start_random_${Date.now()}`
      };
    }

    // 8. Wipe history for fresh start
    s.chronicle = [];
    s.consequences = [];
    s.totalDaysElapsed = 0;
    
    this.state = s;
    this.notify();
    audioEngine.playTuningSweep();
    audioEngine.playMorseBeep(false);
  }

  private restartLoop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.startSimulationLoop();
  }

  private startSimulationLoop() {
    if (this.state.isPaused || this.state.gameSpeed === 0) return;

    // Interval based on game speed: 1x = 3200ms per day, 2x = 1600ms, 5x = 700ms
    const intervalMs = Math.round(3200 / this.state.gameSpeed);

    this.timer = window.setInterval(() => {
      if (!this.state.isPaused && !this.state.activeCrisis) {
        this.advanceDay();
      }
    }, intervalMs);
  }

  /**
   * Main Simulation Step: Advances the world by 1 simulated day.
   */
  public advanceDay() {
    const s = { ...this.state };
    const date = { ...s.currentDate };

    // Advance calendar
    date.day += 1;
    const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (date.day > daysInMonth[date.month - 1]) {
      date.day = 1;
      date.month += 1;
      if (date.month > 12) {
        date.month = 1;
        date.year += 1;
      }
    }

    s.currentDate = date;
    s.totalDaysElapsed += 1;
    const currentDayStamp = formatDate(date);

    // 1. Economic Resource Ticking
    const res = { ...s.resources };
    
    // Base resource yield from controlled provinces
    let dailyOil = 0;
    let dailySteel = 0;
    let dailyFood = 0;
    let dailyRareEarth = 0;
    let dailyElectricity = 0;
    let dailyTreasury = 50; // base taxes

    s.provinces.forEach(p => {
      const efficiency = p.controlPercent / 100 * (p.supplyStatus === 'optimal' ? 1.0 : p.supplyStatus === 'strained' ? 0.6 : 0.2);
      dailyOil += Math.round(p.resourceYield.oil * efficiency);
      dailySteel += Math.round(p.resourceYield.steel * efficiency);
      dailyFood += Math.round(p.resourceYield.food * efficiency);
      dailyRareEarth += Math.round(p.resourceYield.rareEarth * efficiency);
      dailyElectricity += Math.round(p.resourceYield.electricity * efficiency);
      dailyTreasury += Math.round(p.resourceYield.treasury * efficiency);
    });

    // Upkeep costs (Armies, Intelligence, Forts)
    const activeDivisions = s.provinces.reduce((acc, p) => acc + p.garrisonDivisions, 0);
    const oilConsumption = activeDivisions * 8 + 30; // tanks & trucks
    const foodConsumption = activeDivisions * 15 + 80; // rations & cities
    const treasuryUpkeep = activeDivisions * 12 + 40;

    res.oilDelta = dailyOil - oilConsumption;
    res.steelDelta = dailySteel;
    res.foodDelta = dailyFood - foodConsumption;
    res.rareEarthDelta = dailyRareEarth;
    res.electricityDelta = dailyElectricity - 400; // industrial consumption
    res.treasuryDelta = dailyTreasury - treasuryUpkeep;

    res.oil = Math.max(0, res.oil + res.oilDelta);
    res.steel = Math.max(0, res.steel + res.steelDelta);
    res.food = Math.max(0, res.food + res.foodDelta);
    res.rareEarth = Math.max(0, res.rareEarth + res.rareEarthDelta);
    res.electricity = Math.max(0, res.electricity + (res.electricityDelta > 0 ? 5 : -5));
    res.treasury = res.treasury + res.treasuryDelta;
    s.resources = res;

    // Food deficit penalty
    if (res.food <= 0) {
      s.stability = Math.max(10, s.stability - 2);
      if (s.totalDaysElapsed % 7 === 0) {
        this.addChronicleEntry({
          id: `famine_${Date.now()}`,
          timestamp: currentDayStamp,
          dayCount: s.totalDaysElapsed,
          category: 'economy',
          title: 'ДЕФИЦИТ ПРОДОВОЛЬСТВИЯ В ГОРОДАХ',
          details: 'Запасы зерна исчерпаны. В рабочих кварталах Остенмарка выстраиваются очереди за хлебом.',
          badge: 'КРИЗИС СНАБЖЕНИЯ',
          impactColor: '#dc2626'
        });
      }
    }

    // Oil deficit penalty (Fuel starvation)
    if (res.oil <= 0) {
      s.militaryReadiness = Math.max(20, s.militaryReadiness - 1);
    }

    // 2. Frontline War & Battle Simulation
    s.provinces = s.provinces.map(prov => {
      if (!prov.combatFrontlineActive) return prov;

      // Calculate battle skirmish
      const alliedAdvantage = prov.garrisonDivisions * 1.2 - prov.enemyDivisions;
      const alliedLosses = Math.floor(Math.random() * 45) + (prov.supplyStatus === 'optimal' ? 10 : 35);
      const enemyLosses = Math.floor(Math.random() * 65) + 15;

      const newAlliedTotal = prov.frontlineCasualties.alliedTotal + alliedLosses;
      const newEnemyTotal = prov.frontlineCasualties.enemyTotal + enemyLosses;
      s.warSummary.alliedCasualties += alliedLosses;
      s.warSummary.enemyCasualties += enemyLosses;

      let newControl = prov.controlPercent;
      if (alliedAdvantage > 0) {
        newControl = Math.min(100, newControl + 1);
      } else if (alliedAdvantage < 0) {
        newControl = Math.max(0, newControl - 1);
      }

      let newController = prov.controller;
      if (newControl >= 80) newController = 'allied';
      else if (newControl <= 20) newController = 'enemy';
      else newController = 'contested';

      return {
        ...prov,
        controlPercent: newControl,
        controller: newController,
        frontlineCasualties: {
          alliedTotal: newAlliedTotal,
          enemyTotal: newEnemyTotal
        }
      };
    });

    // 2.5 Dynamic Foreign Diplomacy & Mobilization Ticking
    s.countries = (s.countries || []).map(country => {
      let relationsDelta = 0;
      let tensionDelta = 0;

      // When tension is high, foreign power quietly mobilizes
      if (country.tension > 60 && s.totalDaysElapsed % 8 === 0) {
        country.mobilizationDivisions = Math.min(15, country.mobilizationDivisions + 1);
      }

      // If counter-intel active, small chance to hunt our agents in that territory
      if (country.counterIntelActive) {
        s.agents = s.agents.map(ag => {
          if (ag.assignedLocation.toLowerCase().includes(country.id) || ag.assignedLocation.toLowerCase().includes(country.name.toLowerCase().substring(0, 5))) {
            if (!ag.isTargetedByCounterIntel && Math.random() < 0.25) {
              this.addChronicleEntry({
                id: `ci_target_${Date.now()}`,
                timestamp: currentDayStamp,
                dayCount: s.totalDaysElapsed,
                category: 'espionage',
                title: `КОНТРРАЗВЕДКА ${country.code}: СЛЕЖКА ЗА АГЕНТОМ ${ag.codename}`,
                details: `Спецслужбы державы ${country.name} вышли на след резидентуры. Агенту ${ag.codename} грозит немедленный арест при отсутствии маневра уклонения.`,
                badge: 'УГРОЗА ПРОВАЛА',
                impactColor: '#dc2626'
              });
              audioEngine.playMorseBeep(false);
              return { ...ag, isTargetedByCounterIntel: true, threatLevel: 75, status: 'compromised' };
            }
          }
          return ag;
        });
      }

      // Unlock known intel reports if coverage is high enough
      const updatedReports = country.knownIntelReports.map(rep => ({
        ...rep,
        unlocked: country.intelCoverage >= rep.minIntel
      }));

      return {
        ...country,
        relations: Math.max(-100, Math.min(100, country.relations + relationsDelta)),
        tension: Math.max(0, Math.min(100, country.tension + tensionDelta)),
        knownIntelReports: updatedReports
      };
    });

    // 3. Spy Agent Mission Timers
    s.agents = s.agents.map(agent => {
      if (agent.status === 'on_mission' && agent.currentMission) {
        const remaining = agent.currentMission.daysRemaining - 1;
        if (remaining <= 0) {
          // Mission completed!
          this.resolveSpyMission(agent, currentDayStamp);
          return {
            ...agent,
            status: 'idle',
            currentMission: null,
            missionsCompleted: agent.missionsCompleted + 1
          };
        } else {
          return {
            ...agent,
            currentMission: {
              ...agent.currentMission,
              daysRemaining: remaining
            }
          };
        }
      }
      return agent;
    });

    // 4. Tech Research Progress
    s.techTree = s.techTree.map(tech => {
      if (tech.status === 'researching') {
        const rem = tech.daysRemaining - 1;
        if (rem <= 0) {
          // Tech finished
          this.addChronicleEntry({
            id: `tech_done_${tech.id}_${Date.now()}`,
            timestamp: currentDayStamp,
            dayCount: s.totalDaysElapsed,
            category: 'tech',
            title: `ТЕХНОЛОГИЧЕСКИЙ ПРОРЫВ: ${tech.name.toUpperCase()}`,
            details: `КБ №7 завершило разработку технологии. ${tech.effectDesc}`,
            badge: 'ИЗОБРЕТЕНИЕ',
            impactColor: '#059669'
          });
          audioEngine.playMorseBeep(true);
          return {
            ...tech,
            daysRemaining: 0,
            status: 'completed'
          };
        } else {
          return { ...tech, daysRemaining: rem };
        }
      }
      return tech;
    });

    // 5. Consequence Queue Processing & Causal Graph Progression
    const nextConsequences: DeferredConsequence[] = [];
    s.consequences.forEach(cq => {
      const remaining = cq.daysLeft - 1;
      if (remaining <= 0 && !cq.applied) {
        // Trigger Consequence Event!
        this.applyConsequence(cq, currentDayStamp);
      } else if (!cq.applied) {
        nextConsequences.push({ ...cq, daysLeft: remaining });
      }
    });
    s.consequences = nextConsequences;

    // Update days remaining in causalGraph for pending nodes
    s.causalGraph = (s.causalGraph || []).map(node => {
      if (node.status === 'pending') {
        const nextDays = Math.max(0, node.daysRemaining - 1);
        return {
          ...node,
          daysRemaining: nextDays
        };
      }
      return node;
    });

    // 5.5 Critical Fuel Starvation Trigger
    if (!s.activeCrisis && res.oil <= 250 && s.totalDaysElapsed > 3) {
      s.activeCrisis = {
        id: `fuel_crisis_${Date.now()}`,
        title: 'СТРАТЕГИЧЕСКИЙ ТОПЛИВНЫЙ ГОЛОД // КОЛЛАПС РЕЗЕРВОВ ГСМ',
        stamp: 'SUPPLY EMERGENCY // FLASH',
        origin: 'Доклад начальника Управления Снабжения РКК',
        severity: 'critical',
        description: 'Резервуары главного нефтехранилища опустели. Танковые дивизии и моторизованные корпуса рискуют встать на марше в течение 72 часов. Необходимы чрезвычайные меры импорта или реквизиции.',
        options: [
          {
            id: 'opt_fuel_black_market',
            text: 'Закупить партию нефти через швейцарский картель в Базеле',
            costDesc: '-1200 тыс. рейхсмарок из казны',
            consequenceDesc: '+1800 баррелей нефти немедленно, скрытые контакты с картелем «Red Meridian».',
            instantEffect: () => {
              this.state.resources.treasury = Math.max(0, this.state.resources.treasury - 1200);
              this.state.resources.oil += 1800;
              this.advanceSecretScenario('red_meridian', 1);
            },
            deferredEffect: {
              title: 'Вексельный шантаж картеля Базеля',
              daysDelay: 8,
              description: 'Теневые финансисты требуют монопольных прав на экспорт сырья Доминиона.',
              severity: 'warning',
              effect: {
                treasuryDelta: -400,
                stabilityDelta: -4
              }
            }
          },
          {
            id: 'opt_fuel_requisition_ethelgard',
            text: 'Принудительно задержать морские танкеры Республики Этельгард в портах',
            costDesc: '-35 отношений с Этельгардом, +15% международной напряженности',
            consequenceDesc: '+2500 баррелей нефти, но угроза морской блокады торгового флота.',
            instantEffect: () => {
              this.state.resources.oil += 2500;
              this.state.countries = this.state.countries.map(c => 
                c.id === 'ethelgard_republic' ? { ...c, relations: c.relations - 35, tension: c.tension + 25 } : c
              );
            },
            deferredEffect: {
              title: 'Дипломатическая нота Этельгарда и бойкот портов',
              daysDelay: 6,
              description: 'Торговый совет Этельгарда заморозил экспорт оборудования в Штальбург.',
              severity: 'critical',
              effect: {
                treasuryDelta: -500,
                countryId: 'ethelgard_republic',
                countryRelationsDelta: -20
              }
            }
          },
          {
            id: 'opt_fuel_fischer_synth',
            text: 'Приказ химическим заводам: экстренный синтез бензина из угля Остенмарка',
            costDesc: '-600 стали (перенаправление коксовых печей), -10% лояльности рабочих',
            consequenceDesc: '+1200 баррелей синтетического топлива, ускорение R&D «Синтетический бензин».',
            instantEffect: () => {
              this.state.resources.steel = Math.max(0, this.state.resources.steel - 600);
              this.state.resources.oil += 1200;
              this.state.factions = this.state.factions.map(f => 
                f.id === 'labor' ? { ...f, loyalty: Math.max(0, f.loyalty - 10) } : f
              );
            }
          }
        ]
      };
      audioEngine.setTheme('orchestral');
    }

    // 6. Event Generation (AI Director or Fallback)
    if (!s.activeCrisis && s.totalDaysElapsed >= 4 && !this.isGeneratingEvent) {
      this.triggerAIEventGeneration();
    }

    this.state = s;
    this.notify();
  }

  /**
   * Resolves completed spy operations
   */
  private resolveSpyMission(agent: SpyAgent, dateStamp: string) {
    const mission = agent.currentMission;
    if (!mission) return;

    const roll = Math.random() * 100;
    const isSuccess = roll < (60 + agent.skill * 8);

    if (isSuccess) {
      this.addChronicleEntry({
        id: `spy_succ_${Date.now()}`,
        timestamp: dateStamp,
        dayCount: this.state.totalDaysElapsed,
        category: 'espionage',
        title: `УСПЕХ ОПЕРАЦИИ: ${agent.codename}`,
        details: `Агент ${agent.codename} успешно выполнил задание в локации ${agent.assignedLocation}: «${mission.name}». Результат: ${mission.rewardDesc}.`,
        badge: 'СПЕЦОПЕРАЦИЯ',
        impactColor: '#0284c7'
      });

      // Bonus clues to secret scenarios based on location
      this.advanceRandomSecretScenario(1);
    } else {
      this.addChronicleEntry({
        id: `spy_fail_${Date.now()}`,
        timestamp: dateStamp,
        dayCount: this.state.totalDaysElapsed,
        category: 'espionage',
        title: `ПРОВАЛ РЕЗИДЕНТУРЫ: ${agent.codename}`,
        details: `Связь с агентом ${agent.codename} в секторе ${agent.assignedLocation} временно потеряна из-за облавы контрразведки противника.`,
        badge: 'ТРЕВОГА РАЗВЕДКИ',
        impactColor: '#dc2626'
      });
    }
  }

  /**
   * Applies deferred ripple consequence
   */
  private applyConsequence(cq: DeferredConsequence, dateStamp: string) {
    cq.applied = true;
    const eff = cq.effect;

    if (eff.stabilityDelta) {
      this.state.stability = Math.max(0, Math.min(100, this.state.stability + eff.stabilityDelta));
    }
    if (eff.warWearinessDelta) {
      this.state.warWeariness = Math.max(0, Math.min(100, this.state.warWeariness + eff.warWearinessDelta));
    }
    if (eff.militaryReadinessDelta) {
      this.state.militaryReadiness = Math.max(0, Math.min(100, this.state.militaryReadiness + eff.militaryReadinessDelta));
    }
    if (eff.oilDelta) {
      this.state.resources.oil = Math.max(0, this.state.resources.oil + eff.oilDelta);
    }
    if (eff.steelDelta) {
      this.state.resources.steel = Math.max(0, this.state.resources.steel + eff.steelDelta);
    }
    if (eff.treasuryDelta) {
      this.state.resources.treasury = this.state.resources.treasury + eff.treasuryDelta;
    }
    if (eff.frontlineShiftProvinceId && eff.frontlineShiftDelta) {
      this.state.provinces = this.state.provinces.map(p => {
        if (p.id === eff.frontlineShiftProvinceId) {
          const next = Math.max(0, Math.min(100, p.controlPercent + eff.frontlineShiftDelta!));
          return { ...p, controlPercent: next };
        }
        return p;
      });
    }
    if (eff.factionId && eff.factionLoyaltyDelta) {
      this.state.factions = this.state.factions.map(f => {
        if (f.id === eff.factionId) {
          const nextLoyalty = Math.max(0, Math.min(100, f.loyalty + eff.factionLoyaltyDelta!));
          return { ...f, loyalty: nextLoyalty };
        }
        return f;
      });
    }
    if (eff.triggerEvent && !this.state.activeCrisis) {
      this.state.activeCrisis = {
        id: `chained_event_${Date.now()}`,
        ...eff.triggerEvent,
        causalOriginId: cq.parentCausalId || cq.id.replace('cq_', 'cnode_')
      };
      this.state.isPaused = true;
      audioEngine.setTheme('orchestral');
    } else if (eff.triggerEvent && this.state.activeCrisis) {
      // If there's already a crisis, defer this event by 1 day as a new consequence
      this.scheduleConsequence({
        id: `cq_delayed_event_${Date.now()}`,
        title: eff.triggerEvent.title,
        triggerDateDay: this.state.totalDaysElapsed + 1,
        daysLeft: 1,
        originAction: cq.originAction,
        description: 'Событие отложено из-за другого кризиса.',
        severity: 'warning',
        applied: false,
        effect: {
          triggerEvent: eff.triggerEvent
        }
      });
    }

    if (eff.countryId) {
      this.state.countries = this.state.countries.map(c => {
        if (c.id === eff.countryId) {
          const nextRel = eff.countryRelationsDelta ? Math.max(-100, Math.min(100, c.relations + eff.countryRelationsDelta)) : c.relations;
          const nextTens = eff.countryTensionDelta ? Math.max(0, Math.min(100, c.tension + eff.countryTensionDelta)) : c.tension;
          return { ...c, relations: nextRel, tension: nextTens };
        }
        return c;
      });
    }
    if (eff.secretScenarioId && eff.secretScenarioClueDelta) {
      this.advanceSecretScenario(eff.secretScenarioId, eff.secretScenarioClueDelta);
    }

    // Update matching causalGraph node
    this.state.causalGraph = (this.state.causalGraph || []).map(node => {
      if (node.originAction === cq.originAction || node.id === cq.parentCausalId) {
        return {
          ...node,
          status: 'triggered',
          daysRemaining: 0,
          resultingEventTitle: cq.title
        };
      }
      return node;
    });

    // If consequence is the Norland Insurgency blowback, spawn the Diplomatic Crisis!
    if (cq.title.includes('Контрразведка Норланда') && !this.state.activeCrisis) {
      this.state.activeCrisis = {
        id: `norland_ultimatum_${Date.now()}`,
        title: 'УЛЬТИМАТУМ НОРЛАНДА // ДЕЛО О ТАЙНЫХ ПОСТАВКАХ ОРУЖИЯ',
        stamp: 'DIPLOMATIC CRISIS // URGENT',
        origin: 'Чрезвычайная нота Посольства Королевства Норланд',
        severity: 'critical',
        description: 'Служба безопасности Норланда перехватила тайный караван с оружием с маркировкой Штальбурга. Премьер-министр Норланда требует официальных объяснений и угрожает немедленным разрывом торговых договоров и мобилизацией флота.',
        causalOriginId: cq.parentCausalId,
        options: [
          {
            id: 'opt_deny_arms',
            text: 'Категорически отвергнуть обвинения: «Это провокация третьей стороны»',
            costDesc: '-20 отношений с Норландом, +15% напряженности границы',
            consequenceDesc: 'Сохранит лицо и агентурную сеть, но Норланд приведет армию в боевую готовность.',
            instantEffect: () => {
              this.state.countries = this.state.countries.map(c => 
                c.id === 'norland' ? { ...c, relations: c.relations - 20, tension: c.tension + 15, counterIntelActive: true } : c
              );
            },
            deferredEffect: {
              title: 'Скрытое развертывание 3-й дивизии Норланда',
              daysDelay: 7,
              description: 'Норланд усилил приграничный гарнизон 120 орудиями и танками.',
              severity: 'warning',
              effect: {
                frontlineShiftProvinceId: 'falkenburg',
                frontlineShiftDelta: -10,
                countryId: 'norland',
                countryTensionDelta: 10
              }
            }
          },
          {
            id: 'opt_pay_reparations',
            text: 'Принести тайные извинения и выплатить «компенсацию за инцидент»',
            costDesc: '-900 тыс. рейхсмарок из казны',
            consequenceDesc: 'Полная стабилизация отношений с Норландом, прекращение охоты на наших агентов.',
            instantEffect: () => {
              this.state.resources.treasury = Math.max(0, this.state.resources.treasury - 900);
              this.state.countries = this.state.countries.map(c => 
                c.id === 'norland' ? { ...c, relations: Math.min(100, c.relations + 15), tension: Math.max(0, c.tension - 20), counterIntelActive: false } : c
              );
              this.state.agents = this.state.agents.map(a => ({ ...a, isTargetedByCounterIntel: false, status: a.status === 'compromised' ? 'idle' : a.status }));
            }
          },
          {
            id: 'opt_threaten_war',
            text: 'Выдвинуть встречный ультиматум и провести демонстративные маневры танков',
            costDesc: '+20% боевого духа армии, -50 отношений с Норландом',
            consequenceDesc: 'Перевод Норланда в статус открытого военного противника (WAR STATE).',
            instantEffect: () => {
              this.state.militaryReadiness = Math.min(100, this.state.militaryReadiness + 12);
              this.state.stability = Math.min(100, this.state.stability + 8);
              this.state.countries = this.state.countries.map(c => 
                c.id === 'norland' ? { ...c, relations: -75, tension: 90, status: 'war' } : c
              );
            },
            deferredEffect: {
              title: 'Открытие Северного Фронта',
              daysDelay: 5,
              description: 'Норланд объявил войну и начал бомбардировку железнодорожных мостов.',
              severity: 'critical',
              effect: {
                frontlineShiftProvinceId: 'falkenburg',
                frontlineShiftDelta: -25,
                stabilityDelta: -10
              }
            }
          }
        ]
      };
      audioEngine.setTheme('orchestral');
    }

    this.addChronicleEntry({
      id: `cq_applied_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'politics',
      title: `ПОСЛЕДСТВИЕ РЕШЕНИЯ: ${cq.title.toUpperCase()}`,
      details: `${cq.description} (Причина: «${cq.originAction}»).`,
      badge: 'ЦЕПЬ СОБЫТИЙ',
      impactColor: cq.severity === 'triumph' ? '#059669' : cq.severity === 'critical' ? '#dc2626' : '#d97706'
    });
  }

  /**
   * Public Action: Manual Day Step (Turn progression)
   */
  public executeOrderOfTheDay() {
    audioEngine.playClick('heavy');
    this.advanceDay();
  }

  /**
   * Public Action: Dispatch Spy Agent
   */
  public dispatchAgentMission(agentId: string, missionId: string, location: string) {
    const missionType = SPY_MISSION_TYPES.find(m => m.id === missionId);
    if (!missionType) return;

    if (this.state.resources.treasury < missionType.costTreasury) {
      return; // Insufficient funds
    }

    this.state.resources.treasury -= missionType.costTreasury;
    this.state.agents = this.state.agents.map(a => {
      if (a.id === agentId) {
        return {
          ...a,
          assignedLocation: location,
          status: 'on_mission',
          currentMission: {
            id: missionType.id,
            name: missionType.name,
            daysRemaining: missionType.durationDays,
            totalDays: missionType.durationDays,
            risk: missionType.risk,
            rewardDesc: missionType.potentialRewards.join(', '),
            causalOriginAction: missionType.name
          }
        };
      }
      return a;
    });

    // If mission produces a hidden consequence, register into causalGraph and consequences queue!
    if (missionType.causesHiddenConsequence) {
      const parentNodeId = `cnode_${Date.now()}`;
      const hiddenCq = missionType.causesHiddenConsequence;

      const newCausalNode: import('./gameState').CausalNode = {
        id: parentNodeId,
        originAction: missionType.name,
        originDay: this.state.totalDaysElapsed,
        triggerDay: this.state.totalDaysElapsed + hiddenCq.daysDelay,
        daysRemaining: hiddenCq.daysDelay,
        severity: 'high',
        status: 'pending',
        knownEffects: [missionType.potentialRewards[0]],
        hiddenEffectsCount: 2,
        intelRequiredToForecast: hiddenCq.intelRequired,
        forecastHint: hiddenCq.forecast,
        decisionChoiceTaken: `Отправка агента в сектор ${location}`
      };

      this.state.causalGraph = [newCausalNode, ...(this.state.causalGraph || [])];

      this.scheduleConsequence({
        id: `cq_spy_${Date.now()}`,
        title: hiddenCq.title,
        triggerDateDay: this.state.totalDaysElapsed + hiddenCq.daysDelay,
        daysLeft: hiddenCq.daysDelay,
        originAction: missionType.name,
        description: hiddenCq.possibleOutcomeDesc,
        severity: 'warning',
        applied: false,
        parentCausalId: parentNodeId,
        intelRequired: hiddenCq.intelRequired,
        forecast: hiddenCq.forecast,
        effect: {
          stabilityDelta: -5,
          countryId: location.toLowerCase().includes('норланд') ? 'norland' : undefined,
          countryRelationsDelta: -15,
          countryTensionDelta: 20
        }
      });
    }

    const dateStamp = formatDate(this.state.currentDate);
    this.addChronicleEntry({
      id: `agent_dispatch_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'espionage',
      title: `НАПРАВЛЕНИЕ АГЕНТА: ${missionType.name.toUpperCase()}`,
      details: `Агент отправлен в сектор ${location}. Срок операции: ${missionType.durationDays} дней. Стоимость: ${missionType.costTreasury} рейхсмарок.`,
      badge: 'ДИРЕКТИВА РАЗВЕДКИ',
      impactColor: '#0284c7'
    });

    audioEngine.playClick('switch');
    this.notify();
  }

  /**
   * Public Action: Recall Agent (Emergency Evacuation)
   */
  public recallAgent(agentId: string) {
    const agent = this.state.agents.find(a => a.id === agentId);
    if (!agent) return;

    this.state.agents = this.state.agents.map(a => {
      if (a.id === agentId) {
        return {
          ...a,
          status: 'idle',
          currentMission: null,
          isTargetedByCounterIntel: false,
          threatLevel: 0
        };
      }
      return a;
    });

    const dateStamp = formatDate(this.state.currentDate);
    this.addChronicleEntry({
      id: `agent_recall_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'espionage',
      title: `ЭВАКУАЦИЯ АГЕНТА: ${agent.codename}`,
      details: `Агент ${agent.codename} экстренно вывезен через нейтральную границу. Провал резидентуры предотвращен, миссия свернута.`,
      badge: 'ЭВАКУАЦИЯ',
      impactColor: '#059669'
    });

    audioEngine.playClick('toggle');
    this.notify();
  }

  /**
   * Public Action: Change Agent Cover Identity
   */
  public changeAgentIdentity(agentId: string) {
    const cost = 150;
    if (this.state.resources.treasury < cost) return;

    this.state.resources.treasury -= cost;
    this.state.agents = this.state.agents.map(a => {
      if (a.id === agentId) {
        return {
          ...a,
          isTargetedByCounterIntel: false,
          threatLevel: 15,
          status: a.status === 'compromised' ? 'idle' : a.status
        };
      }
      return a;
    });

    const dateStamp = formatDate(this.state.currentDate);
    this.addChronicleEntry({
      id: `agent_cover_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'espionage',
      title: `СМЕНА ЛЕГЕНДЫ АГЕНТА`,
      details: `Агенту выданы новые швейцарские документы и дипломатический паспорт. Хвост контрразведки сброшен.`,
      badge: 'КОНСПИРАЦИЯ',
      impactColor: '#059669'
    });

    audioEngine.playStamp();
    this.notify();
  }

  /**
   * Public Action: Sacrifice Local Contact to save Agent
   */
  public sacrificeAgentContact(agentId: string) {
    this.state.stability = Math.max(0, this.state.stability - 8);
    this.state.agents = this.state.agents.map(a => {
      if (a.id === agentId) {
        return {
          ...a,
          isTargetedByCounterIntel: false,
          threatLevel: 0,
          status: a.status === 'compromised' ? 'idle' : a.status
        };
      }
      return a;
    });

    const dateStamp = formatDate(this.state.currentDate);
    this.addChronicleEntry({
      id: `agent_sacrifice_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'espionage',
      title: `ОПЕРАЦИЯ ПРИКРЫТИЯ // ЖЕРТВА СВЯЗНЫМ`,
      details: `Подставной агент арестован полицией противника. Основной резидент ушел в подполье. Внутренняя стабильность: -8%.`,
      badge: 'ОТВЛЕКАЮЩИЙ МАНЕВР',
      impactColor: '#d97706'
    });

    audioEngine.playStamp();
    this.notify();
  }

  /**
   * Public Action: Launch Aerial Reconnaissance Flight
   */
  public launchAerialRecon(countryId: string) {
    const fuelCost = 150;
    const treasuryCost = 80;

    if (this.state.resources.oil < fuelCost || this.state.resources.treasury < treasuryCost) {
      return false;
    }

    this.state.resources.oil -= fuelCost;
    this.state.resources.treasury -= treasuryCost;

    this.state.countries = this.state.countries.map(c => {
      if (c.id === countryId) {
        const nextIntel = Math.min(100, c.intelCoverage + 25);
        return {
          ...c,
          intelCoverage: nextIntel,
          knownIntelReports: c.knownIntelReports.map(rep => ({
            ...rep,
            unlocked: nextIntel >= rep.minIntel
          }))
        };
      }
      return c;
    });

    const targetCountry = this.state.countries.find(c => c.id === countryId);
    const dateStamp = formatDate(this.state.currentDate);

    this.addChronicleEntry({
      id: `air_recon_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'espionage',
      title: `ВЫСОТНЫЙ РАЗВЕДВЫЛЕТ: ${targetCountry?.name.toUpperCase() || countryId}`,
      details: `Эскадрилья «Юнкерс» провела аэрофотосъемку приграничных укрепрайонов. Разведпокрытие державы увеличено до ${targetCountry?.intelCoverage}%.`,
      badge: 'АВИАРАЗВЕДКА',
      impactColor: '#0284c7'
    });

    audioEngine.playClick('switch');
    this.notify();
    return true;
  }

  /**
   * Public Action: Start Tech Research
   */
  public startResearch(techId: string) {
    const tech = this.state.techTree.find(t => t.id === techId);
    if (!tech || tech.status !== 'available') return;

    if (
      this.state.resources.steel < tech.costSteel ||
      this.state.resources.rareEarth < tech.costRareEarth ||
      this.state.resources.treasury < tech.costTreasury
    ) {
      return; // Insufficient resources
    }

    this.state.resources.steel -= tech.costSteel;
    this.state.resources.rareEarth -= tech.costRareEarth;
    this.state.resources.treasury -= tech.costTreasury;

    this.state.techTree = this.state.techTree.map(t => {
      if (t.id === techId) {
        return {
          ...t,
          status: 'researching',
          daysRemaining: t.costDays
        };
      }
      return t;
    });

    const dateStamp = formatDate(this.state.currentDate);
    this.addChronicleEntry({
      id: `research_start_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'tech',
      title: `ЗАПУСК ПРОЕКТА КБ №7: ${tech.name.toUpperCase()}`,
      details: `Выделены производственные мощности: ${tech.costSteel}т стали, ${tech.costRareEarth}кг вольфрама. Срок завершения: ${tech.costDays} дней.`,
      badge: 'НИОКР',
      impactColor: '#059669'
    });

    audioEngine.playClick('toggle');
    this.notify();
  }

  /**
   * Public Action: Launch Offensive in War Room
   */
  public launchWarRoomOffensive(targetProvinceId: string, doctrine: string) {
    const province = this.state.provinces.find(p => p.id === targetProvinceId) || this.state.provinces[0];
    const fuelCost = 350;
    const ammoCost = 400; // Steel

    if (this.state.resources.oil < fuelCost || this.state.resources.steel < ammoCost) {
      // Insufficient supply
      return false;
    }

    this.state.resources.oil -= fuelCost;
    this.state.resources.steel -= ammoCost;

    const shift = Math.floor(Math.random() * 15) + 12;
    this.state.provinces = this.state.provinces.map(p => {
      if (p.id === targetProvinceId) {
        const nextControl = Math.min(100, p.controlPercent + shift);
        return {
          ...p,
          controlPercent: nextControl,
          controller: nextControl >= 75 ? 'allied' : 'contested'
        };
      }
      return p;
    });

    this.state.warSummary.totalBattlesFought += 1;
    const dateStamp = formatDate(this.state.currentDate);

    this.addChronicleEntry({
      id: `war_offensive_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'war',
      title: `ШТАБНОЙ ПРОРЫВ: СЕКТОР ${province.name.toUpperCase()}`,
      details: `Нанесен концентрированный удар по доктрине «${doctrine}». Израсходовано ${fuelCost} баррелей топлива, контроль сектора увеличен на +${shift}%.`,
      badge: 'НАСТУПЛЕНИЕ',
      impactColor: '#dc2626'
    });

    // Schedule delayed counterattack consequence in 7 days
    this.scheduleConsequence({
      id: `cq_counter_atk_${Date.now()}`,
      title: `Контрудар резервов Норланда под ${province.name}`,
      triggerDateDay: this.state.totalDaysElapsed + 7,
      daysLeft: 7,
      originAction: `Наступление на ${province.name} (${doctrine})`,
      description: 'Вражеские самоходные орудия попытаются срезать выступ прорыва.',
      severity: 'warning',
      applied: false,
      effect: {
        frontlineShiftProvinceId: province.id,
        frontlineShiftDelta: -8,
        stabilityDelta: -3
      }
    }, {
      intelRequired: 45,
      forecastHint: 'В тылу противника замечено перемещение тяжелых тягачей с боеприпасами.',
      hiddenEffectsCount: 1
    });

    audioEngine.setTheme('orchestral');
    this.notify();
    return true;
  }

  /**
   * Public Action: Resolve Crisis Modal
   */
  
  private async triggerDynamicCausalEngine(crisis: ActiveCrisisModal, chosenOption: any) {
    // Only fire 50% of the time to not overwhelm the player, or only for major crises
    

    try {
      const prompt = `Игрок принял историческое решение в ходе события:
Событие: ${crisis.title}
Описание: ${crisis.description}
Выбранное действие: ${chosenOption.text}
Текущая стабильность: ${this.state.stability}, Готовность: ${this.state.militaryReadiness}, Усталость от войны: ${this.state.warWeariness}.

Создай логичное продолжение (эффект бабочки), которое произойдет через 2-7 дней. 
Оно может быть двух типов:
1. Простое последствие (только изменение статов).
2. Новое интерактивное событие (игрок снова должен будет сделать выбор), может быть кризисом, возможностью или мирным событием.

Ответь СТРОГО в JSON без markdown:
{
  "title": "КРАТКИЙ ЗАГОЛОВОК НОВОГО ПОСЛЕДСТВИЯ",
  "description": "Описание того, как решение игрока привело к этому.",
  "daysDelay": число_2_7,
  "severity": "warning" | "alert" | "success" | "critical",
  "hasFollowUpEvent": true_или_false,
  "statChanges": {
    "stabilityDelta": число, "warWearinessDelta": число, "militaryReadinessDelta": число
  },
  "followUpEvent": {
    "title": "ЗАГОЛОВОК НОВОЙ СИТУАЦИИ",
    "stamp": "КАТЕГОРИЯ (например, WAR, DIPLOMACY, SOCIETY, SCIENCE, OPPORTUNITY)",
    "origin": "Источник (например, Доклад разведки)",
    "description": "Суть новой ситуации...",
    "severity": "low" | "medium" | "high" | "critical" | "opportunity" | "event",
    "category": "politics" | "war" | "economy" | "diplomacy" | "society" | "science" | "peacetime",
    "options": [
      {
        "id": "opt_1", "text": "Действие 1", "costDesc": "Цена 1", "consequenceDesc": "Эффект 1",
        "statChanges": {"stabilityDelta": число, "militaryReadinessDelta": число}
      },
      {
        "id": "opt_2", "text": "Действие 2", "costDesc": "Цена 2", "consequenceDesc": "Эффект 2",
        "statChanges": {"stabilityDelta": число, "warWearinessDelta": число}
      }
    ]
  }
}`;
      const response = await generateWithGemini(prompt, "You are the Causal Inference Engine for Iron Dominion. Return valid JSON only.");
      
      if (response && response.title && response.description) {
        const childNodeId = `cnode_dynamic_${Date.now()}`;
        
        let effectPayload: any = {
          stabilityDelta: response.statChanges?.stabilityDelta || 0,
          warWearinessDelta: response.statChanges?.warWearinessDelta || 0,
          militaryReadinessDelta: response.statChanges?.militaryReadinessDelta || 0
        };

        if (response.hasFollowUpEvent && response.followUpEvent) {
          effectPayload.triggerEvent = {
            title: response.followUpEvent.title,
            stamp: response.followUpEvent.stamp,
            origin: response.followUpEvent.origin,
            description: response.followUpEvent.description,
            severity: response.followUpEvent.severity || 'medium',
            category: response.followUpEvent.category || 'politics',
            options: response.followUpEvent.options.map((o: any) => ({
              id: o.id,
              text: o.text,
              costDesc: o.costDesc,
              consequenceDesc: o.consequenceDesc,
              instantEffect: () => {},
              deferredEffect: {
                title: `Последствие: ${o.text.substring(0, 20)}...`,
                daysDelay: 3,
                description: o.consequenceDesc,
                severity: 'warning',
                effect: {
                  stabilityDelta: o.statChanges?.stabilityDelta || 0,
                  warWearinessDelta: o.statChanges?.warWearinessDelta || 0,
                  militaryReadinessDelta: o.statChanges?.militaryReadinessDelta || 0
                }
              }
            }))
          };
        }

        this.scheduleConsequence({
          id: `cq_dynamic_${Date.now()}`,
          title: response.title,
          triggerDateDay: this.state.totalDaysElapsed + (response.daysDelay || 4),
          daysLeft: response.daysDelay || 4,
          originAction: `Последствие: ${chosenOption.text}`,
          description: response.description,
          severity: response.severity || 'warning',
          applied: false,
          parentCausalId: crisis.causalOriginId || childNodeId,
          effect: effectPayload
        }, {
          causalNodeId: childNodeId,
          parentId: crisis.causalOriginId,
          intelRequired: 50,
          forecastHint: "Разведка предупреждает о развивающихся последствиях...",
          decisionChoice: chosenOption.text,
          knownEffects: ["Цепная реакция (Эффект бабочки)"],
          hiddenEffectsCount: 1
        });
        this.notify();
      }
    } catch (e) {
      console.warn("Causal Engine missed a dynamic link:", e);
    }
  }


  private async triggerAIEventGeneration() {
    if (this.isGeneratingEvent || this.state.activeCrisis) return;
    this.isGeneratingEvent = true;

    try {
      const aiEvent = await aiEventDirector.generateDynamicEvent(this.state);
      
      if (aiEvent && !this.state.activeCrisis) {
        this.state.activeCrisis = {
          ...aiEvent,
          id: `ai_event_${Date.now()}`
        };
        this.state.isPaused = true;
        audioEngine.setTheme('orchestral');
        this.notify();
      }
    } catch (err) {
      console.warn("AI Director execution encountered error:", err);
    } finally {
      this.isGeneratingEvent = false;
    }
  }

  public resolveCrisis(optionId: string) {
    if (!this.state.activeCrisis) return;

    const crisis = this.state.activeCrisis;
    const opt = crisis.options.find(o => o.id === optionId);
    if (opt) {
      opt.instantEffect?.();

      let childNodeId: string | undefined = undefined;
      if (opt.deferredEffect) {
        childNodeId = `cnode_child_${Date.now()}`;
        this.scheduleConsequence({
          id: `cq_crisis_${Date.now()}`,
          title: opt.deferredEffect.title,
          triggerDateDay: this.state.totalDaysElapsed + opt.deferredEffect.daysDelay,
          daysLeft: opt.deferredEffect.daysDelay,
          originAction: crisis.title,
          description: opt.deferredEffect.description,
          severity: opt.deferredEffect.severity,
          applied: false,
          parentCausalId: crisis.causalOriginId || childNodeId,
          effect: opt.deferredEffect.effect
        }, {
          causalNodeId: childNodeId,
          parentId: crisis.causalOriginId,
          intelRequired: 40,
          forecastHint: opt.deferredEffect.description,
          decisionChoice: opt.text,
          knownEffects: [opt.consequenceDesc],
          hiddenEffectsCount: 1
        });
      }

      // Update parent causal node if linked
      if (crisis.causalOriginId) {
        this.state.causalGraph = (this.state.causalGraph || []).map(cn => {
          if (cn.id === crisis.causalOriginId) {
            return {
              ...cn,
              status: 'resolved',
              decisionChoiceTaken: opt.text
            };
          }
          return cn;
        });
      }

      // Category and visual impact mapping
      const categoryMap: Record<string, ChronicleEntry['category']> = {
        war: 'war',
        politics: 'politics',
        economy: 'economy',
        espionage: 'espionage',
        secret: 'secret',
        tech: 'tech',
        diplomacy: 'politics',
        society: 'politics',
        science: 'tech',
        peacetime: 'politics'
      };
      const chronicleCat = categoryMap[crisis.category || 'politics'] || 'politics';
      const impactColor = crisis.severity === 'opportunity' ? '#059669' :
                          crisis.severity === 'critical' ? '#dc2626' :
                          crisis.severity === 'event' ? '#0284c7' : '#d97706';

      const dateStamp = formatDate(this.state.currentDate);
      this.addChronicleEntry({
        id: `crisis_resolved_${Date.now()}`,
        timestamp: dateStamp,
        dayCount: this.state.totalDaysElapsed,
        category: chronicleCat,
        title: `РЕЗОЛЮЦИЯ СТАВКИ: ${crisis.title}`,
        details: `Принято решение: «${opt.text}». ${opt.consequenceDesc}`,
        badge: crisis.stamp || 'УКАЗ ГЛАВНОКОМАНДУЮЩЕГО',
        impactColor,
        causalChainId: crisis.causalOriginId,
        causedByAction: crisis.title,
        causedByDay: this.state.totalDaysElapsed
      });
    }

    this.state.activeCrisis = null;
    audioEngine.playStamp();
    this.notify();
  }

  /**
   * Advances a specific secret conspiracy
   */
  public advanceSecretScenario(scenarioId: string, clueCount: number = 1) {
    this.state.secretScenarios = this.state.secretScenarios.map(sc => {
      if (sc.id === scenarioId) {
        const nextProgress = Math.min(100, sc.progressPercent + clueCount * 25);
        const stage = Math.min(4, Math.floor(nextProgress / 25) + 1);
        return {
          ...sc,
          progressPercent: nextProgress,
          unlockedStage: stage,
          countermeasureAvailable: nextProgress >= 75
        };
      }
      return sc;
    });

    const found = this.state.secretScenarios.find(s => s.id === scenarioId);
    if (found) {
      const dateStamp = formatDate(this.state.currentDate);
      this.addChronicleEntry({
        id: `secret_clue_${Date.now()}`,
        timestamp: dateStamp,
        dayCount: this.state.totalDaysElapsed,
        category: 'secret',
        title: `РАСШИФРОВКА АРХИВА: ${found.code}`,
        details: `Спецслужбы вскрыли секретный протокол по делу «${found.name}». Прогресс расследования: ${found.progressPercent}%.`,
        badge: 'СЕКРЕТНО // LEVEL 5',
        impactColor: '#7c3aed'
      });
    }
  }

  private advanceRandomSecretScenario(clues: number) {
    const list = this.state.secretScenarios;
    const item = list[Math.floor(Math.random() * list.length)];
    if (item) {
      this.advanceSecretScenario(item.id, clues);
    }
  }

  /**
   * Schedule a future consequence and link it to the Causal Graph for long-term "Memory"
   */
  public scheduleConsequence(
    consequence: DeferredConsequence, 
    causalMeta?: { 
      intelRequired?: number; 
      forecastHint?: string; 
      parentId?: string;
      hiddenEffectsCount?: number;
      knownEffects?: string[];
      decisionChoice?: string;
      causalNodeId?: string;
    }
  ) {
    this.state.consequences.push(consequence);

    // If causalMeta provided, add/update node in causalGraph
    if (causalMeta || consequence.parentCausalId) {
      const nodeId = causalMeta?.causalNodeId || consequence.id.replace('cq_', 'cnode_').replace('counter_atk_', 'cnode_war_');
      
      // Check if node already exists to avoid duplicates
      const exists = (this.state.causalGraph || []).some(n => n.id === nodeId);
      if (exists) return;

      const newNode: import('./gameState').CausalNode = {
        id: nodeId,
        parentCausalId: causalMeta?.parentId || consequence.parentCausalId,
        originAction: consequence.originAction,
        originDay: this.state.totalDaysElapsed,
        triggerDay: consequence.triggerDateDay,
        daysRemaining: consequence.daysLeft,
        severity: consequence.severity === 'info' ? 'low' : 
                  consequence.severity === 'warning' ? 'medium' : 
                  consequence.severity === 'critical' ? 'critical' : 'triumph',
        status: 'pending',
        knownEffects: causalMeta?.knownEffects || [consequence.title],
        hiddenEffectsCount: causalMeta?.hiddenEffectsCount || 0,
        intelRequiredToForecast: causalMeta?.intelRequired || consequence.intelRequired || 35,
        forecastHint: causalMeta?.forecastHint || consequence.forecast || 'Разведка фиксирует косвенные признаки подготовки...',
        decisionChoiceTaken: causalMeta?.decisionChoice
      };

      this.state.causalGraph = [newNode, ...(this.state.causalGraph || [])];

      if (newNode.parentCausalId) {
        this.state.causalGraph = this.state.causalGraph.map(n => {
          if (n.id === newNode.parentCausalId) {
            return {
              ...n,
              childCausalIds: [...(n.childCausalIds || []), newNode.id]
            };
          }
          return n;
        });
      }
    }
  }

  /**
   * Add a record to the World History Chronicle
   */
  public addChronicleEntry(entry: ChronicleEntry) {
    this.state.chronicle = [entry, ...this.state.chronicle];
  }

  /**
   * Gazette Propaganda Published - connects with national state
   */
  public publishGazetteHeadline(headline: string, stance: 'militarist' | 'calm' | 'censored', cost: number = 120) {
    this.state.resources.treasury = Math.max(0, this.state.resources.treasury - cost);

    let stabilityShift = 0;
    let laborShift = 0;
    let militaryShift = 0;

    if (stance === 'militarist') {
      stabilityShift = +8;
      militaryShift = +12;
      laborShift = -6;
      this.state.militaryReadiness = Math.min(100, this.state.militaryReadiness + 5);
    } else if (stance === 'calm') {
      stabilityShift = +12;
      laborShift = +10;
      militaryShift = -5;
    } else {
      stabilityShift = +5;
      this.advanceSecretScenario('phantom', 1);
    }

    this.state.stability = Math.max(0, Math.min(100, this.state.stability + stabilityShift));
    this.state.factions = this.state.factions.map(f => {
      if (f.id === 'military') return { ...f, loyalty: Math.min(100, f.loyalty + militaryShift) };
      if (f.id === 'labor') return { ...f, loyalty: Math.min(100, f.loyalty + laborShift) };
      return f;
    });

    const dateStamp = formatDate(this.state.currentDate);
    this.addChronicleEntry({
      id: `gazette_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'politics',
      title: `ВЫПУСК «ШТАЛЬБУРГСКИХ ВЕДОМОСТЕЙ»`,
      details: `Главная полоса: «${headline}». Моральный дух нации изменился на ${stabilityShift > 0 ? `+${stabilityShift}` : stabilityShift}%.`,
      badge: 'ПЕЧАТЬ & ЦЕНЗУРА',
      impactColor: '#d97706'
    });

    audioEngine.playStamp();
    this.notify();
  }

  /**
   * Tribunal Verdict executed - impacts factions & secret investigations
   */
  public executeTribunalVerdict(suspectName: string, verdict: 'execute' | 'imprison' | 'exile' | 'acquit', role: string) {
    let militaryDelta = 0;
    let stabilityDelta = 0;

    if (verdict === 'execute') {
      militaryDelta = -15;
      stabilityDelta = -8;
      this.advanceSecretScenario('phantom', 1);
    } else if (verdict === 'imprison') {
      militaryDelta = -5;
      stabilityDelta = +4;
      this.advanceSecretScenario('black_sun', 1);
    } else if (verdict === 'acquit') {
      militaryDelta = +10;
      stabilityDelta = +5;
    }

    this.state.stability = Math.max(0, Math.min(100, this.state.stability + stabilityDelta));
    this.state.factions = this.state.factions.map(f => {
      if (f.id === 'military') return { ...f, loyalty: Math.max(0, Math.min(100, f.loyalty + militaryDelta)) };
      return f;
    });

    const dateStamp = formatDate(this.state.currentDate);
    this.addChronicleEntry({
      id: `tribunal_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'politics',
      title: `ВЕРДИКТ ВОЕННОГО ТРИБУНАЛА: ${suspectName.toUpperCase()}`,
      details: `По делу «${role}» вынесен окончательный приговор: ${verdict.toUpperCase()}. Офицерский корпус отреагировал сдвигом лояльности на ${militaryDelta}%.`,
      badge: 'ТРИБУНАЛ',
      impactColor: verdict === 'execute' ? '#dc2626' : '#d97706'
    });

    // Causal Ripple based on verdict
    if (verdict === 'execute') {
      this.scheduleConsequence({
        id: `cq_tribunal_revenge_${Date.now()}`,
        title: `Ропот в офицерском собрании после казни ${suspectName}`,
        triggerDateDay: this.state.totalDaysElapsed + 9,
        daysLeft: 9,
        originAction: `Казнь ${suspectName}`,
        description: 'Адъютанты и соратники казненного генерала ведут опасные разговоры в кулуарах.',
        severity: 'warning',
        applied: false,
        effect: {
          stabilityDelta: -5,
          factionId: 'military',
          factionLoyaltyDelta: -10
        }
      }, {
        intelRequired: 55,
        forecastHint: 'В штабах фронтов замечено нетипичное оживление курьеров и зашифрованных депеш.',
        hiddenEffectsCount: 1
      });
    } else if (verdict === 'acquit') {
      this.scheduleConsequence({
        id: `cq_tribunal_sabotage_${Date.now()}`,
        title: `Взрыв на узловой станции после оправдания ${suspectName}`,
        triggerDateDay: this.state.totalDaysElapsed + 5,
        daysLeft: 5,
        originAction: `Оправдание ${suspectName}`,
        description: 'Спецслужбы подозревают, что оправданный агент противника активировал спящую ячейку.',
        severity: 'critical',
        applied: false,
        effect: {
          frontlineShiftProvinceId: 'ostenmark',
          frontlineShiftDelta: -5,
          oilDelta: -400
        }
      }, {
        intelRequired: 45,
        forecastHint: 'Разведка перехватила сигнал «Птица на свободе», адресованный резидентуре в Штальбурге.'
      });
    }

    audioEngine.playStamp();
    this.notify();
  }

  /**
   * Tank / Weapon production order from Arsenal
   */
  public produceArsenalBlueprint(blueprintName: string, steelCost: number, rareEarthCost: number, targetProvinceId: string = 'ostenmark') {
    if (this.state.resources.steel < steelCost || this.state.resources.rareEarth < rareEarthCost) {
      return false;
    }

    this.state.resources.steel -= steelCost;
    this.state.resources.rareEarth -= rareEarthCost;

    this.state.provinces = this.state.provinces.map(p => {
      if (p.id === targetProvinceId) {
        return {
          ...p,
          garrisonDivisions: p.garrisonDivisions + 1
        };
      }
      return p;
    });

    const dateStamp = formatDate(this.state.currentDate);
    this.addChronicleEntry({
      id: `arsenal_build_${Date.now()}`,
      timestamp: dateStamp,
      dayCount: this.state.totalDaysElapsed,
      category: 'war',
      title: `ПРИЕМКА ТЕХНИКИ: ${blueprintName.toUpperCase()}`,
      details: `КБ №7 передало бронетанковым войскам в секторе ${targetProvinceId} новую партию боевых машин. Израсходовано ${steelCost}т стали.`,
      badge: 'ВООРУЖЕНИЕ',
      impactColor: '#059669'
    });

    audioEngine.playClick('heavy');
    this.notify();
    return true;
  }

  /**
   * Update resources partially
   */

  public applyQuickEffect(effect: any) {
    if (!effect) return;
    if (effect.stabilityDelta) this.state.stability = Math.max(0, Math.min(100, this.state.stability + effect.stabilityDelta));
    if (effect.warWearinessDelta) this.state.warWeariness = Math.max(0, Math.min(100, this.state.warWeariness + effect.warWearinessDelta));
    if (effect.militaryReadinessDelta) this.state.militaryReadiness = Math.max(0, Math.min(100, this.state.militaryReadiness + effect.militaryReadinessDelta));
    if (effect.treasuryDelta) this.state.resources.treasury = Math.max(0, this.state.resources.treasury + effect.treasuryDelta);
    if (effect.oilDelta) this.state.resources.oil = Math.max(0, this.state.resources.oil + effect.oilDelta);
    if (effect.steelDelta) this.state.resources.steel = Math.max(0, this.state.resources.steel + effect.steelDelta);
    this.notify();
  }

  public updateResources(partial: Partial<import('./gameState').GameResources>) {
    this.state.resources = {
      ...this.state.resources,
      ...partial
    };
    this.notify();
  }
}

export const gameStore = new GameStore();
