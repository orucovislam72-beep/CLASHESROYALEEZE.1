// Store for Radio Intercept Logs (last 5 dispatches) synchronized across the app

export type RadioLogStatus = 'active' | 'investigating' | 'resolved' | 'decrypted' | 'archived';

export interface RadioLogEntry {
  id: string;
  time: string;
  frequency: number;
  title: string;
  desc: string;
  source: string;
  status: RadioLogStatus;
  type: 'alert' | 'warning' | 'success' | 'secret';
  morse?: string;
  classification?: string;
  impact?: string;
}

export const INITIAL_RADIO_LOGS: RadioLogEntry[] = [
  {
    id: 'log-1',
    time: '14:22:10',
    frequency: 1140,
    title: 'ШТАБНОЙ ПЕРЕХВАТ // ОСТЕНМАРК',
    desc: 'Массовая забастовка на угольных копях парализовала снабжение эшелонов. Лояльность рабочих снижена на 20%.',
    source: 'Гарнизон ТВД',
    status: 'active',
    type: 'alert',
    morse: '... -.-. .-. .. ... .. ...',
    classification: 'ШТАБ // ПРИОРИТЕТ 1',
    impact: 'Задержка подвоза угля: 3 дня'
  },
  {
    id: 'log-2',
    time: '14:18:45',
    frequency: 1420,
    title: 'ЗУММЕР УВБ-34 // ПАКЕТ 88-14',
    desc: 'Перехвачена 16-значная группа цифр. Зафиксирована координация подпольных ячеек в лесах Корсака.',
    source: 'Станция УВБ-34',
    status: 'investigating',
    type: 'warning',
    morse: '--- --. . -. - ...',
    classification: 'КОНТРРАЗВЕДКА // СЕКРЕТНО',
    impact: 'Угроза диверсии на ж/д линии'
  },
  {
    id: 'log-3',
    time: '14:05:30',
    frequency: 780,
    title: 'ДЕПЕША ПРЕССЫ // ВОРН',
    desc: 'Марш лоялистов прошел без инцидентов. Местное население добровольно сдает излишки зерна на военные склады.',
    source: 'Редакция Ведомостей',
    status: 'resolved',
    type: 'success',
    morse: '...- .. -.-. - --- .-. -.--',
    classification: 'ОДОБРЕНО ЦЕНЗУРОЙ',
    impact: '+15% к продовольственному пайку'
  },
  {
    id: 'log-4',
    time: '13:51:12',
    frequency: 1939,
    title: 'БУНКЕР №4 // ПРОЕКТ «КОЛОСС»',
    desc: 'Засекреченный отчет КБ №7: испытания сверхтяжелого шагохода "Колосс-IX" на полигоне Антарктиды завершены успешно.',
    source: 'Синдикат «Омега»',
    status: 'decrypted',
    type: 'secret',
    morse: '-.-. --- .-.. --- ... ... ..- ...',
    classification: 'ГРИФ: ОСОБОЙ ВАЖНОСТИ',
    impact: 'Доступна секретная ветка вооружений'
  },
  {
    id: 'log-5',
    time: '13:30:04',
    frequency: 890,
    title: 'СВОДКА СИНДИКАТА // ЭТЕЛЬГАРД',
    desc: 'Промышленный картель запросил дополнительные квоты на броневую сталь. Предотвращена попытка саботажа турбин.',
    source: 'Промышленный Совет',
    status: 'archived',
    type: 'warning',
    morse: '... - . . .-..',
    classification: 'ЭКОНОМИКА // АРХИВ',
    impact: 'Выпуск танков: +8 единиц'
  }
];

export const PROCEDURAL_INTERCEPTS = [
  {
    frequency: 1140,
    title: 'АРТНАЛЕТ НА ВЫСОТУ 214 // ВОРН',
    desc: 'Тяжелая артиллерия противника ведет огонь по переправам. Требуется срочная контрбатарейная поддержка.',
    source: '4-й Армейский Корпус',
    type: 'alert' as const,
    morse: '.- .-. - .. .-.. .-.. . .-. -.--',
    classification: 'ОПЕРАТИВНАЯ СВОДКА',
    impact: 'Потери пехоты: 4%, Расход боеприпасов +25%'
  },
  {
    frequency: 1420,
    title: 'ПЕРЕХВАТ ТЕЛЕГРАФА // СИНДИКАТ',
    desc: 'Вскрыты каналы контрабанды вольфрама через нейтральный порт. В документах фигурирует имя Барона Вейса.',
    source: 'Шифровальный Отдел',
    type: 'warning' as const,
    morse: '... -.-- -. -.. .. -.-. .- - .',
    classification: 'ТАЙНЫЙ НАДЗОР',
    impact: 'Улика для военного трибунала'
  },
  {
    frequency: 780,
    title: 'ЭКСТРЕННЫЙ ВЫПУСК // ШТАЛЬБУРГ',
    desc: 'Пресс-бюро сообщает о перевыполнении военного заказа на паровозостроительном заводе №2.',
    source: 'Городская Радиосеть',
    type: 'success' as const,
    morse: '..-. .- -.-. - --- .-. -.--',
    classification: 'ГРАЖДАНСКИЙ ЭФИР',
    impact: 'Темп мобилизации тыла +10%'
  },
  {
    frequency: 1939,
    title: 'РАДИОХРОНИКА БУНКЕРА №4',
    desc: '«Всем постам: активирован резервный протокол Энигма-1934. Передайте командующему ключ активации "Аврора".»',
    source: 'Старший радист Карлсен',
    type: 'secret' as const,
    morse: '.- ..- .-. --- .-. .-',
    classification: 'ВЫСШИЙ ДОПУСК',
    impact: 'Разблокировка секретных архивов'
  },
  {
    frequency: 1020,
    title: 'ДИВЕРСИЯ В ЛЕСАХ КОРСАКА',
    desc: 'Партизанский отряд совершил налет на склад горючего. Пожар локализован силами гарнизона.',
    source: 'Погранслужба',
    type: 'alert' as const,
    morse: '..-. .. .-. .',
    classification: 'ТРЕВОГА // СЕКТОР СЕВЕР',
    impact: 'Потеряно 200 т дизельного топлива'
  },
  {
    frequency: 890,
    title: 'ПОЛИГОННЫЕ ИСПЫТАНИЯ // КБ №7',
    desc: 'Опытный образец тяжелой самоходки "Мамонт-I" успешно поразил мишень на дистанции 1800 метров.',
    source: 'Конструкторское Бюро',
    type: 'success' as const,
    morse: '.- .-. -- --- ..-',
    classification: 'ВОЕНПРИЕМКА',
    impact: 'Готовность чертежей танков +20%'
  }
];

class RadioLogsStore {
  private logs: RadioLogEntry[] = [];
  private subscribers: Set<(logs: RadioLogEntry[]) => void> = new Set();
  private maxLogs: number = 5;

  constructor() {
    this.logs = [...INITIAL_RADIO_LOGS];
  }

  public getLogs(): RadioLogEntry[] {
    return [...this.logs];
  }

  public subscribe(callback: (logs: RadioLogEntry[]) => void) {
    this.subscribers.add(callback);
    callback(this.getLogs());
    return () => {
      this.subscribers.delete(callback);
    };
  }

  private notify() {
    const current = this.getLogs();
    // Defer notification to avoid synchronous state updates during React's render phase
    setTimeout(() => {
      this.subscribers.forEach(cb => cb(current));
    }, 0);
  }

  public addLog(entry: {
    frequency: number;
    title: string;
    desc: string;
    source: string;
    type: 'alert' | 'warning' | 'success' | 'secret';
    morse?: string;
    classification?: string;
    impact?: string;
    status?: RadioLogStatus;
  }) {
    const now = new Date();
    const timeStr = now.toTimeString().substring(0, 8);
    const newLog: RadioLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      time: timeStr,
      frequency: entry.frequency,
      title: entry.title,
      desc: entry.desc,
      source: entry.source,
      status: entry.status || (entry.type === 'secret' ? 'decrypted' : entry.type === 'alert' ? 'active' : 'investigating'),
      type: entry.type,
      morse: entry.morse || '... --- ...',
      classification: entry.classification || 'ШТАБНОЙ ПЕРЕХВАТ',
      impact: entry.impact || 'Информация принята к сведению'
    };

    // Filter out if duplicate by title & timestamp within 5 seconds
    this.logs = [newLog, ...this.logs.filter(l => l.title !== newLog.title)].slice(0, this.maxLogs);
    this.notify();
    return newLog;
  }

  public updateLogStatus(id: string, status: RadioLogStatus) {
    this.logs = this.logs.map(log => log.id === id ? { ...log, status } : log);
    this.notify();
  }

  public cycleLogStatus(id: string) {
    const statusCycle: RadioLogStatus[] = ['active', 'investigating', 'resolved', 'archived', 'decrypted'];
    this.logs = this.logs.map(log => {
      if (log.id === id) {
        const nextIdx = (statusCycle.indexOf(log.status) + 1) % statusCycle.length;
        return { ...log, status: statusCycle[nextIdx] };
      }
      return log;
    });
    this.notify();
  }

  public scanRandomIntercept(): RadioLogEntry {
    const randomIndex = Math.floor(Math.random() * PROCEDURAL_INTERCEPTS.length);
    const template = PROCEDURAL_INTERCEPTS[randomIndex];
    return this.addLog({
      frequency: template.frequency,
      title: template.title,
      desc: template.desc,
      source: template.source,
      type: template.type,
      morse: template.morse,
      classification: template.classification,
      impact: template.impact
    });
  }

  public resetToDefault() {
    this.logs = [...INITIAL_RADIO_LOGS];
    this.notify();
  }

  public clearLogs() {
    this.logs = [];
    this.notify();
  }
}

export const radioLogsStore = new RadioLogsStore();
