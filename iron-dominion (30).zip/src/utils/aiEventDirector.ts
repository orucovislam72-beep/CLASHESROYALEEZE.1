import { GameState, ActiveCrisisModal, RANDOM_CRISES_POOL, DeferredConsequence } from './gameState';
import { routeAIRequest } from './aiRouter';

/**
 * Iron Dominion - Central Dynamic AI Event Director
 * 
 * Orchestrates coherent, non-repetitive, causal storyline events by feeding
 * full World State context into Gemini AI with strict schema validation,
 * anti-repetition filters, category diversity, and resilient procedural fallback.
 */
export class AIEventDirector {
  private lastEventDay: number = 0;
  private cooldownDays: number = 10;
  private recentEventTitles: string[] = [];
  private recentTopics: string[] = [];
  private recentCategories: string[] = [];
  private consecutiveFailures: number = 0;

  /**
   * Builds comprehensive, structured World Context for the AI
   */
  public buildWorldContext(state: GameState): string {
    // 1. Core National Metrics
    const coreMetrics = [
      `- Дни у власти: ${state.totalDaysElapsed}`,
      `- Стабильность Доминиона: ${state.stability}% (${state.stability > 70 ? 'Высокая / Спокойствие' : state.stability > 40 ? 'Умеренная / Напряжение' : 'Критическая / Угроза бунта'})`,
      `- Военная готовность: ${state.militaryReadiness}%`,
      `- Усталость народа от войны: ${state.warWeariness}%`,
      `- Казна: ${state.resources.treasury} тыс. RM (приток: ${state.resources.treasuryDelta > 0 ? '+' : ''}${state.resources.treasuryDelta}/день)`,
      `- Запасы Нефти (ГСМ): ${state.resources.oil} барр. (приток: ${state.resources.oilDelta > 0 ? '+' : ''}${state.resources.oilDelta}/день)`,
      `- Запасы Стали / Снарядов: ${state.resources.steel} т (приток: ${state.resources.steelDelta > 0 ? '+' : ''}${state.resources.steelDelta}/день)`,
      `- Редкие металлы (Вольфрам): ${state.resources.rareEarth} кг`,
      `- Продовольствие: ${state.resources.food} т, Электроэнергия: ${state.resources.electricity} МВт`
    ].join('\n');

    // 2. Provinces & Frontlines
    const provinceSummaries = state.provinces.map(p => 
      `* [Провинция ID: "${p.id}"] «${p.name}»: Контроль ${p.controlPercent}% (${p.controller === 'allied' ? 'Союзный' : p.controller === 'contested' ? 'Оспаривается' : 'Вражеский'}), Беспорядки: ${p.unrest}%, Лояльность: ${p.loyalty}, Гарнизон: ${p.garrisonDivisions} див. против ${p.enemyDivisions} враж. див., Снабжение: ${p.supplyStatus}${p.combatFrontlineActive ? ' [ФРОНТОВОЙ БОЙ АКТИВЕН]' : ''}`
    ).join('\n');

    // 3. Diplomacy & Foreign Powers
    const countrySummaries = state.countries.map(c =>
      `* [Держава ID: "${c.id}"] «${c.name}» (${c.code}): Статус: ${c.status.toUpperCase()}, Отношения: ${c.relations > 0 ? '+' : ''}${c.relations} (-100..+100), Напряженность границы: ${c.tension}%, Разведпокрытие: ${c.intelCoverage}%, Торговля: ${c.tradeStatus}, Мобилизовано: ${c.mobilizationDivisions} див.`
    ).join('\n');

    // 4. Political Factions
    const factionSummaries = state.factions.map(f =>
      `* [Фракция ID: "${f.id}"] «${f.name}» (Лидер: ${f.leader}): Лояльность: ${f.loyalty}%, Влияние: ${f.influence}%, Статус: ${f.status.toUpperCase()}, Особенность: «${f.perk}», Угроза: «${f.threat}»`
    ).join('\n');

    // 5. Intelligence & Secret Conspiracies
    const agentSummaries = state.agents.map(a =>
      `* Агент ${a.codename} (${a.specialty}, локация: ${a.assignedLocation}): статус ${a.status}${a.currentMission ? `, миссия «${a.currentMission.name}» (осталось ${a.currentMission.daysRemaining} дн., риск: ${a.currentMission.risk})` : ''}`
    ).join('\n');

    const secretPlots = state.secretScenarios.map(s =>
      `* [Сюжет ID: "${s.id}"] «${s.name}» (${s.code}): прогресс ${s.progressPercent}%, стадия ${s.unlockedStage}/4, статус: ${s.status}, улик: ${s.cluesFound.length}/${s.maxClues}`
    ).join('\n');

    // 6. Technology & R&D
    const completedTechs = state.techTree.filter(t => t.status === 'completed').map(t => t.name).join(', ') || 'Базовые технологии';
    const activeTechs = state.techTree.filter(t => t.status === 'researching').map(t => `«${t.name}» (${t.daysRemaining} дн.)`).join(', ') || 'Нет активных проектов';

    // 7. Active Deferred Consequences (Future Horizon)
    const activeConsequences = state.consequences.filter(cq => !cq.applied).map(cq =>
      `* «${cq.title}» (Сработает через ${cq.daysLeft} дн., Источник: ${cq.originAction}, Опасность: ${cq.severity}, Суть: ${cq.description})`
    ).join('\n') || 'Нет надвигающихся отложенных последствий.';

    // 8. Causal Graph & Recent Player Decisions (Butterfly Effect Roots)
    const recentDecisions = (state.causalGraph || []).slice(-6).map(cn =>
      `* Узел [${cn.id}]: Событие-причина: «${cn.originAction}» -> Выбор игрока: «${cn.decisionChoiceTaken || 'В процессе'}» (Статус: ${cn.status})${cn.resultingEventTitle ? ` -> Породило: «${cn.resultingEventTitle}»` : ''}`
    ).join('\n') || 'Начало кампании.';

    // 9. World History Chronicle (Last 20-30 events)
    const recentChronicle = state.chronicle.slice(-25).map(c =>
      `* [День ${c.dayCount} | ${c.category.toUpperCase()}] ${c.title}: ${c.details}`
    ).join('\n') || 'Летопись пуста.';

    return `=== ГЛОБАЛЬНЫЙ КОНТЕКСТ МИРА (IRON DOMINION) ===

1. МЕТРИКИ И ЭКОНОМИКА:
${coreMetrics}

2. СТРАТЕГИЧЕСКИЕ ПРОВИНЦИИ И ФРОНТ:
${provinceSummaries}

3. ВНЕШНЯЯ ПОЛИТИКА И ДЕРЖАВЫ:
${countrySummaries}

4. ВНУТРЕННИЕ ПОЛИТИЧЕСКИЕ ФРАКЦИИ:
${factionSummaries}

5. РАЗВЕДКА И ТАЙНЫЕ ЗАГОВОРЫ:
- Агенты:
${agentSummaries}
- Тайные сценарии:
${secretPlots}

6. НАУКА И НИОКР:
- Завершенные исследования: ${completedTechs}
- В разработке: ${activeTechs}

7. ГОРИЗОНТ ОТЛОЖЕННЫХ ПОСЛЕДСТВИЙ (ЧТО УЖЕ ЗАПУЩЕНО):
${activeConsequences}

8. ПРИЧИННО-СЛЕДСТВЕННАЯ ЦЕПЬ И ПОСЛЕДНИЕ РЕШЕНИЯ ИГРОКА:
${recentDecisions}

9. ХРОНИКА ПОСЛЕДНИХ 25 СОБЫТИЙ МИРА:
${recentChronicle}`;
  }

  /**
   * Generates a coherent, rich, non-repetitive dynamic story event
   */
  public async generateDynamicEvent(state: GameState, force: boolean = false): Promise<Omit<ActiveCrisisModal, 'id'> | null> {
    // 1. Pacing & Saturation Check
    if (!force) {
      if (state.activeCrisis) {
        return null;
      }
      
      const dynamicCooldown = (state.stability < 35 || state.warWeariness > 65) ? 5 : 7;
      if (this.lastEventDay === 0) {
        if (state.totalDaysElapsed < 4) return null;
      } else if (state.totalDaysElapsed - this.lastEventDay < dynamicCooldown) {
        return null;
      }

      // Check consequence saturation: don't overwhelm if multiple critical consequences are triggering soon
      const urgentPending = state.consequences.filter(c => !c.applied && c.daysLeft <= 3 && c.severity === 'critical');
      if (urgentPending.length >= 2) {
        return null; // Let the player deal with current consequences first
      }
    }

    const worldContext = this.buildWorldContext(state);

    // Categories rotation
    const allCategories = ['politics', 'war', 'economy', 'diplomacy', 'society', 'science', 'peacetime'];
    const underrepresentedCategories = allCategories.filter(cat => !this.recentCategories.slice(-3).includes(cat));
    const suggestedCategory = underrepresentedCategories[Math.floor(Math.random() * underrepresentedCategories.length)] || 'politics';

    // Banned recent list
    const bannedTitles = this.recentEventTitles.slice(-25).join(' | ') || 'Нет';
    const bannedTopics = this.recentTopics.slice(-15).join(', ') || 'Нет';

    const prompt = `Ты — Центральный Режиссер Событий (AI Event Director) для дизельпанк-стратегии "Iron Dominion".

${worldContext}

=== ПРАВИЛА ГЕНЕРАЦИИ ДИНАМИЧЕСКОГО СОБЫТИЯ ===
1. ЦЕПОЧКА ПРИЧИННОСТИ (ЭФФЕКТ БАБОЧКИ):
Твое новое событие должно логически вытекать из текущего состояния мира, либо стать прямым продолжением недавних решений игрока (из раздела 8 или 9), либо реагировать на критические уязвимости (низкие ресурсы, напряженность границ, восстания в провинциях, заговоры).

2. АРХЕТИП СОБЫТИЯ (РАЗНООБРАЗИЕ):
Не генерируй только кризисы! Событие может быть:
- "opportunity": Уникальная возможность (выгодная сделка, перебежчик, открытие месторождения, триумф).
- "peacetime": Мирное/социальное событие (выставка достижений, фестиваль, культурная реформа, праздник рабочих).
- "diplomacy": Дипломатический инцидент, секретные переговоры, торговый пакт, пограничный ультиматум.
- "science": Прорыв в НИОКР, испытание секретного прототипа, теоретический спор ученых.
- "war": Фронтовой маневр, засада партизан, рейд на склады, инспекция линии обороны.
- "economy": Забастовка картеля, валютный кризис, модернизация заводов, черный рынок сырья.
- "politics": Интриги генералитета, утечка в прессу, выборы в сенат, министерский скандал.

Рекомендуемая категория для разнообразия: "${suggestedCategory}".

3. АНТИ-ПОВТОРЕНИЕ (СТРОГИЙ ЗАПРЕТ):
Запрещено повторять следующие недавно бывшие события и темы:
- Запрещенные заголовки: ${bannedTitles}
- Запрещенные темы: ${bannedTopics}

4. СТРОГИЕ ТРЕБОВАНИЯ К ДАННЫМ:
- В deferredEffect используй ТОЛЬКО реальные ID провинций, стран, фракций или секретных сюжетов из контекста мира!
  Доступные провинции ID: ${state.provinces.map(p => `"${p.id}"`).join(', ')}
  Доступные страны ID: ${state.countries.map(c => `"${c.id}"`).join(', ')}
  Доступные фракции ID: ${state.factions.map(f => `"${f.id}"`).join(', ')}
  Доступные тайные сюжеты ID: ${state.secretScenarios.map(s => `"${s.id}"`).join(', ')}

ВЕРНИ СТРОГО ВАЛИДНЫЙ JSON БЕЗ MARKDOWN И КОММЕНТАРИЕВ:
{
  "title": "ЛАКОНИЧНЫЙ ВОЕННО-ПОЛИТИЧЕСКИЙ ЗАГОЛОВОК (3-6 слов)",
  "stamp": "ШТАМП // ТИП (напр. OPPORTUNITY // SCIENCE, DIPLOMACY // FLASH, PEACETIME // DISPATCH)",
  "origin": "Официальный источник (напр. Донесение коменданта Фалькенбурга, Депеша МИД)",
  "description": "3-5 предложений глубокого, атмосферного дизельпанк-текста с конкретными именами и фактами из мира...",
  "severity": "low" | "medium" | "high" | "critical" | "opportunity" | "event",
  "category": "politics" | "war" | "economy" | "diplomacy" | "society" | "science" | "peacetime",
  "topic": "краткое_ключевое_слово_темы_латиницей",
  "causalOriginId": "ID узла из раздела 8 если это продолжение, иначе null",
  "options": [
    {
      "id": "opt_1",
      "text": "Текст решительного действия верховного главнокомандующего",
      "costDesc": "Текстовое описание затрат/рисков (напр. '-300 казна, -10 лояльности рабочих')",
      "consequenceDesc": "Текстовое описание ожидаемого исхода",
      "immediateStatChanges": {
        "treasuryDelta": 0,
        "oilDelta": 0,
        "steelDelta": 0,
        "stabilityDelta": 0,
        "militaryReadinessDelta": 0
      },
      "deferredEffect": {
        "title": "Краткий заголовок отложенного последствия",
        "daysDelay": число_дней_от_2_до_7,
        "description": "Художественное описание того, что произойдет спустя дни.",
        "severity": "info" | "warning" | "critical" | "triumph",
        "effect": {
          "stabilityDelta": число_от_минус_20_до_20,
          "warWearinessDelta": число_от_минус_20_до_20,
          "militaryReadinessDelta": число_от_минус_20_до_20,
          "treasuryDelta": число_от_минус_1000_до_1000,
          "oilDelta": число_от_минус_600_до_600,
          "steelDelta": число_от_минус_600_до_600,
          "countryId": "ID страны из списка доступных (или не указывать)",
          "countryRelationsDelta": число_от_минус_30_до_30,
          "countryTensionDelta": число_от_минус_30_до_30,
          "factionId": "ID фракции из списка доступных (или не указывать)",
          "factionLoyaltyDelta": число_от_минус_25_до_25,
          "frontlineShiftProvinceId": "ID провинции из списка (или не указывать)",
          "frontlineShiftDelta": число_от_минус_25_до_25,
          "secretScenarioId": "ID сюжета из списка (или не указывать)",
          "secretScenarioClueDelta": 1
        }
      }
    }
  ]
}`;

    try {
      const isCritical = state.stability < 35 || state.warWeariness > 70;
      const rawResult = await routeAIRequest({
        prompt,
        systemInstruction: "You are the central AI Event Director for Iron Dominion. Return strictly valid JSON only. Never use markdown fences.",
        urgency: isCritical ? 'critical' : 'medium',
        isKeyMoment: isCritical
      });

      const validatedEvent = this.sanitizeAndValidateEvent(rawResult, state);
      if (!validatedEvent) {
        throw new Error("AI returned invalid event schema");
      }

      // Update historical trackers
      this.lastEventDay = state.totalDaysElapsed;
      this.recentEventTitles.push(validatedEvent.title);
      if (this.recentEventTitles.length > 30) this.recentEventTitles.shift();

      if (rawResult.topic) {
        this.recentTopics.push(String(rawResult.topic));
        if (this.recentTopics.length > 20) this.recentTopics.shift();
      }

      if (validatedEvent.category) {
        this.recentCategories.push(validatedEvent.category);
        if (this.recentCategories.length > 10) this.recentCategories.shift();
      }

      this.consecutiveFailures = 0;
      return validatedEvent;
    } catch (error) {
      console.warn("AI Event Director generation failed, falling back to intelligent procedural selection:", error);
      this.consecutiveFailures++;
      this.lastEventDay = state.totalDaysElapsed;
      return this.getFallbackEvent(state);
    }
  }

  /**
   * Strict schema validation and data sanitization
   * Guarantees that AI output never corrupts GameState
   */
  private sanitizeAndValidateEvent(data: any, state: GameState): Omit<ActiveCrisisModal, 'id'> | null {
    if (!data || typeof data !== 'object') return null;

    const title = typeof data.title === 'string' && data.title.trim().length > 3 ? data.title.trim() : null;
    const description = typeof data.description === 'string' && data.description.trim().length > 10 ? data.description.trim() : null;
    if (!title || !description) return null;

    const stamp = typeof data.stamp === 'string' ? data.stamp.trim() : 'MILITARY ARCHIVE // DISPATCH';
    const origin = typeof data.origin === 'string' ? data.origin.trim() : 'Главный Штаб Обороны';

    const validSeverities = ['low', 'medium', 'high', 'critical', 'opportunity', 'event'];
    const severity = validSeverities.includes(data.severity) ? data.severity : 'medium';

    const validCategories = ['politics', 'war', 'economy', 'diplomacy', 'society', 'science', 'peacetime'];
    const category = validCategories.includes(data.category) ? data.category : 'politics';

    if (!Array.isArray(data.options) || data.options.length === 0) return null;

    const validCountryIds = new Set(state.countries.map(c => c.id));
    const validFactionIds = new Set(state.factions.map(f => f.id));
    const validProvinceIds = new Set(state.provinces.map(p => p.id));
    const validScenarioIds = new Set(state.secretScenarios.map(s => s.id));

    const options = data.options.slice(0, 3).map((opt: any, index: number) => {
      const optText = typeof opt.text === 'string' && opt.text.trim().length > 0 ? opt.text.trim() : `Решение №${index + 1}`;
      const costDesc = typeof opt.costDesc === 'string' ? opt.costDesc.trim() : 'Стандартные затраты';
      const consequenceDesc = typeof opt.consequenceDesc === 'string' ? opt.consequenceDesc.trim() : 'Влияние на обстановку';

      let deferredEffect: any = undefined;
      if (opt.deferredEffect && typeof opt.deferredEffect === 'object') {
        const defTitle = typeof opt.deferredEffect.title === 'string' ? opt.deferredEffect.title.trim() : `Последствие: ${optText.substring(0, 20)}...`;
        const daysDelay = Math.max(1, Math.min(14, Number(opt.deferredEffect.daysDelay) || 4));
        const defDesc = typeof opt.deferredEffect.description === 'string' ? opt.deferredEffect.description.trim() : consequenceDesc;
        const defSeverity = ['info', 'warning', 'critical', 'triumph'].includes(opt.deferredEffect.severity) ? opt.deferredEffect.severity : 'warning';

        const rawEff = opt.deferredEffect.effect || {};
        const safeEffect: DeferredConsequence['effect'] = {};

        if (typeof rawEff.stabilityDelta === 'number' && !isNaN(rawEff.stabilityDelta)) {
          safeEffect.stabilityDelta = Math.max(-25, Math.min(25, Math.round(rawEff.stabilityDelta)));
        }
        if (typeof rawEff.warWearinessDelta === 'number' && !isNaN(rawEff.warWearinessDelta)) {
          safeEffect.warWearinessDelta = Math.max(-25, Math.min(25, Math.round(rawEff.warWearinessDelta)));
        }
        if (typeof rawEff.militaryReadinessDelta === 'number' && !isNaN(rawEff.militaryReadinessDelta)) {
          safeEffect.militaryReadinessDelta = Math.max(-25, Math.min(25, Math.round(rawEff.militaryReadinessDelta)));
        }
        if (typeof rawEff.treasuryDelta === 'number' && !isNaN(rawEff.treasuryDelta)) {
          safeEffect.treasuryDelta = Math.max(-1500, Math.min(1500, Math.round(rawEff.treasuryDelta)));
        }
        if (typeof rawEff.oilDelta === 'number' && !isNaN(rawEff.oilDelta)) {
          safeEffect.oilDelta = Math.max(-1000, Math.min(1000, Math.round(rawEff.oilDelta)));
        }
        if (typeof rawEff.steelDelta === 'number' && !isNaN(rawEff.steelDelta)) {
          safeEffect.steelDelta = Math.max(-1000, Math.min(1000, Math.round(rawEff.steelDelta)));
        }

        if (typeof rawEff.countryId === 'string' && validCountryIds.has(rawEff.countryId)) {
          safeEffect.countryId = rawEff.countryId;
          if (typeof rawEff.countryRelationsDelta === 'number') {
            safeEffect.countryRelationsDelta = Math.max(-35, Math.min(35, Math.round(rawEff.countryRelationsDelta)));
          }
          if (typeof rawEff.countryTensionDelta === 'number') {
            safeEffect.countryTensionDelta = Math.max(-35, Math.min(35, Math.round(rawEff.countryTensionDelta)));
          }
        }

        if (typeof rawEff.factionId === 'string' && validFactionIds.has(rawEff.factionId)) {
          safeEffect.factionId = rawEff.factionId;
          if (typeof rawEff.factionLoyaltyDelta === 'number') {
            safeEffect.factionLoyaltyDelta = Math.max(-30, Math.min(30, Math.round(rawEff.factionLoyaltyDelta)));
          }
        }

        if (typeof rawEff.frontlineShiftProvinceId === 'string' && validProvinceIds.has(rawEff.frontlineShiftProvinceId)) {
          safeEffect.frontlineShiftProvinceId = rawEff.frontlineShiftProvinceId;
          if (typeof rawEff.frontlineShiftDelta === 'number') {
            safeEffect.frontlineShiftDelta = Math.max(-30, Math.min(30, Math.round(rawEff.frontlineShiftDelta)));
          }
        }

        if (typeof rawEff.secretScenarioId === 'string' && validScenarioIds.has(rawEff.secretScenarioId)) {
          safeEffect.secretScenarioId = rawEff.secretScenarioId;
          safeEffect.secretScenarioClueDelta = Math.max(1, Math.min(2, Number(rawEff.secretScenarioClueDelta) || 1));
        }

        deferredEffect = {
          title: defTitle,
          daysDelay,
          description: defDesc,
          severity: defSeverity,
          effect: safeEffect
        };
      }

      const imm = opt.immediateStatChanges || opt.immediateEffect;
      const instantEffect = imm && typeof imm === 'object' ? () => {
        if (typeof imm.treasuryDelta === 'number' && !isNaN(imm.treasuryDelta)) {
          state.resources.treasury = Math.max(0, state.resources.treasury + Math.round(imm.treasuryDelta));
        }
        if (typeof imm.oilDelta === 'number' && !isNaN(imm.oilDelta)) {
          state.resources.oil = Math.max(0, state.resources.oil + Math.round(imm.oilDelta));
        }
        if (typeof imm.steelDelta === 'number' && !isNaN(imm.steelDelta)) {
          state.resources.steel = Math.max(0, state.resources.steel + Math.round(imm.steelDelta));
        }
        if (typeof imm.stabilityDelta === 'number' && !isNaN(imm.stabilityDelta)) {
          state.stability = Math.max(0, Math.min(100, state.stability + Math.round(imm.stabilityDelta)));
        }
        if (typeof imm.militaryReadinessDelta === 'number' && !isNaN(imm.militaryReadinessDelta)) {
          state.militaryReadiness = Math.max(0, Math.min(100, state.militaryReadiness + Math.round(imm.militaryReadinessDelta)));
        }
        if (typeof imm.warWearinessDelta === 'number' && !isNaN(imm.warWearinessDelta)) {
          state.warWeariness = Math.max(0, Math.min(100, state.warWeariness + Math.round(imm.warWearinessDelta)));
        }
      } : () => {};

      return {
        id: opt.id || `opt_${index + 1}`,
        text: optText,
        costDesc,
        consequenceDesc,
        instantEffect,
        deferredEffect
      };
    });

    const event: Omit<ActiveCrisisModal, 'id'> = {
      title,
      stamp,
      origin,
      description,
      severity,
      category,
      type: severity === 'opportunity' ? 'opportunity' : 'event',
      causalOriginId: typeof data.causalOriginId === 'string' ? data.causalOriginId : undefined,
      options
    };

    return event;
  }

  /**
   * Contextual, diverse procedural fallback when AI is temporarily unreachable
   */
  public getFallbackEvent(state: GameState): Omit<ActiveCrisisModal, 'id'> {
    // 1. Filter pool excluding recent titles
    let candidates = RANDOM_CRISES_POOL.filter(ev => !this.recentEventTitles.includes(ev.title));
    if (candidates.length === 0) candidates = [...RANDOM_CRISES_POOL];

    // 2. Score candidates based on relevance to current state
    if (state.resources.oil < 400) {
      const fuelMatch = candidates.find(c => c.category === 'economy' || c.title.toLowerCase().includes('топлив') || c.title.toLowerCase().includes('шахт'));
      if (fuelMatch) return fuelMatch;
    }

    if (state.stability < 40) {
      const unrestMatch = candidates.find(c => c.category === 'politics' || c.category === 'society' || c.severity === 'critical');
      if (unrestMatch) return unrestMatch;
    }

    if (state.warWeariness > 60) {
      const warMatch = candidates.find(c => c.category === 'war' || c.title.toLowerCase().includes('фронт'));
      if (warMatch) return warMatch;
    }

    // 3. Fallback to category rotation
    const chosen = candidates[Math.floor(Math.random() * candidates.length)] || RANDOM_CRISES_POOL[0];
    return chosen;
  }

  /**
   * Generates atmospheric radio intercept with contextual world awareness
   */
  public async generateRadioEvent(state: GameState): Promise<any | null> {
    const recentChronicle = state.chronicle.slice(-5).map(c => `- [${c.category}] ${c.title}: ${c.details}`).join('\n');
    const topTensionCountry = [...state.countries].sort((a, b) => b.tension - a.tension)[0];

    const prompt = `Ты — оператор радиоперехвата ставки Доминиона ("Iron Dominion").
Сгенерируй ОДИН короткий, атмосферный перехват (шпионская шифрограмма, перехваченное донесение, слух в приграничной таверне или сводка с передовой).

КОНТЕКСТ МИРА:
- Глобальная стабильность Доминиона: ${state.stability}%
- Напряженность с державой ${topTensionCountry?.name || 'соседями'}: ${topTensionCountry?.tension || 20}%
- Недавние события в империи:
${recentChronicle || 'Пока спокойно.'}

ВЕРНИ СТРОГО ВАЛИДНЫЙ JSON БЕЗ MARKDOWN:
{
  "title": "КРАТКИЙ ЗАГОЛОВОК ШИФРОГРАММЫ",
  "desc": "Текст перехвата (2-3 коротких предложения в стиле военной радиограммы 1940-х)",
  "region": "Регион (напр. ОСТЕНМАРК, ЭТЕЛЬГАРД, ФАЛЬКЕНБУРГ, СТОЛИЦА)",
  "type": "alert" | "warning" | "success",
  "options": [
    {
      "text": "Быстрое распоряжение (напр. 'Усилить патрулирование' или 'Передать в архив')",
      "effect": {
        "stabilityDelta": число,
        "treasuryDelta": число,
        "militaryReadinessDelta": число
      }
    }
  ]
}`;

    try {
      const result = await routeAIRequest({
        prompt,
        systemInstruction: "Generate strict JSON. No markdown fences.",
        urgency: 'low'
      });

      if (!result || !result.title || !result.desc) return null;

      return {
        id: `radio_${Date.now()}`,
        title: result.title,
        desc: result.desc,
        region: result.region || 'СЕКТОР СВЯЗИ',
        type: result.type || 'warning',
        options: Array.isArray(result.options) ? result.options.slice(0, 2) : []
      };
    } catch (e) {
      console.error("Radio Event generation failed:", e);
      return null;
    }
  }
}

export const aiEventDirector = new AIEventDirector();
