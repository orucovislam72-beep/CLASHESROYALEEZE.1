// Web Audio API procedural sound engine for 1930s radio, jazz, military march & secret shortwave broadcast

export type AudioTheme = 'jazz' | 'orchestral' | 'numbers' | 'secret_broadcast';

export interface RadioStation {
  id: AudioTheme;
  frequency: number; // in kHz
  name: string;
  genre: string;
  signalStrength: number; // 0-100
  isSecret?: boolean;
}

export const RADIO_STATIONS: RadioStation[] = [
  {
    id: 'jazz',
    frequency: 780,
    name: '«Голос Штальбурга»',
    genre: 'Свинг и Городские Вести 1930-х',
    signalStrength: 95
  },
  {
    id: 'orchestral',
    frequency: 1140,
    name: '«Штабной Военный Канал»',
    genre: 'Маршевые Барабаны и Сводки Фронта',
    signalStrength: 90
  },
  {
    id: 'numbers',
    frequency: 1420,
    name: '«Номерная Станция УВБ-34»',
    genre: 'Зашифрованные Радиограммы и Зуммер',
    signalStrength: 75
  },
  {
    id: 'secret_broadcast',
    frequency: 1939,
    name: 'СЕКРЕТНЫЙ КАНАЛ // ПРОЕКТ АВРОРА',
    genre: 'Радиохроника Бункера №4',
    signalStrength: 100,
    isSecret: true
  }
];

export interface EasterEggChapter {
  id: number;
  title: string;
  speaker: string;
  timeCode: string;
  transcript: string;
  secretClue: string;
  morse: string;
}

export const EASTER_EGG_STORY: EasterEggChapter[] = [
  {
    id: 1,
    title: 'Глава I: Полночь в Бункере №4',
    speaker: 'Старший радист Карлсен (Архив 14.X.1938)',
    timeCode: '00:01:24',
    transcript: '«Всем постам, это не учения! Генерал фон Блюхер только что вошёл в командный отсек и заблокировал гермодвери изнутри. Он кричит, что чертежи "Колосса" — это ловушка банкиров, и что эта война срежиссирована задолго до нашего рождения... Слышны выстрелы охраны в коридоре Б-2!»',
    secretClue: 'Код доступа к архивам: "COLOSSUS-1938"',
    morse: '-.-. --- .-.. --- ... ... ..- -...'
  },
  {
    id: 2,
    title: 'Глава II: Сигнал из ледяной бездны',
    speaker: 'Перехват станции «Новая Швабия»',
    timeCode: '00:02:50',
    transcript: '«Мы пробурили шельфовый лёд на глубину 800 метров. Там нет руды. Там колоссальная пирамидальная структура из черного металла, излучающая тепловой импульс каждые 4 минуты. Она глушит все приборы. Шахтёры отказываются спускаться... Оно реагирует на радиоволны!»',
    secretClue: 'Координаты точки раскопок: 70°14′S 02°30′W',
    morse: '... --- ...   .- -. - .- .-. -.-. - .. -.-. .-.'
  },
  {
    id: 3,
    title: 'Глава III: Теневой синдикат «Омега»',
    speaker: 'Агент "Тень" (Шифровка в Женеву)',
    timeCode: '00:04:12',
    transcript: '«Обе стороны фронта покупают сталь у одного и того же холдинга в Базеле. Золотой эшелон №42 благополучно пересёк границу под видом санитарного поезда. Если правители узнают, что война оплачена из одного сейфа — кабинеты министров падут до рассвета...»',
    secretClue: 'Пароль разблокировки тайной ложи: "OMEGA-SYNDICATE"',
    morse: '--- -- . --. .-'
  },
  {
    id: 4,
    title: 'Глава IV: Последняя депеша',
    speaker: 'Голос из радиоэфира',
    timeCode: '00:05:45',
    transcript: '«Если ты слышишь это сообщение на волне 1939 кГц, командующий... значит, ты заглянул глубже, чем положено простым стратегам. Настоящая победа куется не на полях сражений, а в расшифровке невидимых нитей судьбы. Запомни этот код — он откроет тебе проект "Колосс" в Главном Штабе!»',
    secretClue: 'СЕКРЕТНЫЙ РЕЖИМ РАЗБЛОКИРОВАН В ПАНЕЛИ ДОСЬЕ!',
    morse: '...- .. -.-. - --- .-. -.--'
  }
];

class AudioEngine {
  private ctx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private isMuted: boolean = false;
  private volume: number = 0.4;
  private currentTheme: AudioTheme = 'jazz';
  private frequency: number = 780;
  
  private masterGain: GainNode | null = null;
  private jazzGain: GainNode | null = null;
  private orchGain: GainNode | null = null;
  private numbersGain: GainNode | null = null;
  private secretGain: GainNode | null = null;
  
  private loopInterval: number | null = null;
  private step: number = 0;
  private noiseNode: AudioNode | null = null;
  private isSpeaking: boolean = false;

  private onStateChangeCallbacks: Set<(state: { 
    isPlaying: boolean; 
    theme: AudioTheme; 
    isMuted: boolean; 
    volume: number;
    frequency: number;
    isSpeaking: boolean;
  }) => void> = new Set();

  public subscribe(cb: (state: { 
    isPlaying: boolean; 
    theme: AudioTheme; 
    isMuted: boolean; 
    volume: number;
    frequency: number;
    isSpeaking: boolean;
  }) => void) {
    this.onStateChangeCallbacks.add(cb);
    return () => {
      this.onStateChangeCallbacks.delete(cb);
    };
  }

  private notify() {
    const state = {
      isPlaying: this.isPlaying,
      theme: this.currentTheme,
      isMuted: this.isMuted,
      volume: this.volume,
      frequency: this.frequency,
      isSpeaking: this.isSpeaking
    };
    // Defer notification to avoid synchronous state updates during React's render phase
    setTimeout(() => {
      this.onStateChangeCallbacks.forEach(cb => cb(state));
    }, 0);
  }

  public init() {
    if (this.ctx) return;
    const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AudioCtxClass();

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
    this.masterGain.connect(this.ctx.destination);

    // 4 Sub-gains for smooth multi-station crossfading
    this.jazzGain = this.ctx.createGain();
    this.orchGain = this.ctx.createGain();
    this.numbersGain = this.ctx.createGain();
    this.secretGain = this.ctx.createGain();

    this.jazzGain.gain.setValueAtTime(this.currentTheme === 'jazz' ? 1.0 : 0.0, this.ctx.currentTime);
    this.orchGain.gain.setValueAtTime(this.currentTheme === 'orchestral' ? 1.0 : 0.0, this.ctx.currentTime);
    this.numbersGain.gain.setValueAtTime(this.currentTheme === 'numbers' ? 1.0 : 0.0, this.ctx.currentTime);
    this.secretGain.gain.setValueAtTime(this.currentTheme === 'secret_broadcast' ? 1.0 : 0.0, this.ctx.currentTime);

    this.jazzGain.connect(this.masterGain);
    this.orchGain.connect(this.masterGain);
    this.numbersGain.connect(this.masterGain);
    this.secretGain.connect(this.masterGain);

    this.startVinylNoise();
  }

  private startVinylNoise() {
    if (!this.ctx || !this.masterGain) return;
    try {
      // 1930s Vinyl & Gramophone Crackle Noise
      const bufferSize = this.ctx.sampleRate * 2;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        const crackle = Math.random() > 0.997 ? (Math.random() * 2 - 1) * 4 : 0;
        output[i] = white * 0.04 + crackle * 0.15;
      }

      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 1400;
      filter.Q.value = 1.2;

      const noiseGain = this.ctx.createGain();
      noiseGain.gain.value = 0.25;

      whiteNoise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(this.masterGain);
      whiteNoise.start();
      this.noiseNode = whiteNoise;
    } catch {
      // Ignore if web audio blocked
    }
  }

  public async start() {
    this.init();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
    this.isPlaying = true;
    this.notify();

    if (this.loopInterval) clearInterval(this.loopInterval);
    this.step = 0;
    this.loopInterval = window.setInterval(() => this.tick(), 280);
  }

  public pause() {
    this.isPlaying = false;
    if (this.loopInterval) {
      clearInterval(this.loopInterval);
      this.loopInterval = null;
    }
    if (this.ctx && this.ctx.state === 'running') {
      this.ctx.suspend();
    }
    this.stopSpeech();
    this.notify();
  }

  public togglePlay() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.start();
    }
  }

  public playTuningSweep() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      // White noise radio static sweep
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.25);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * 0.3;
      }
      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(800, now);
      filter.frequency.exponentialRampToValueAtTime(3200, now + 0.15);
      filter.frequency.exponentialRampToValueAtTime(1200, now + 0.24);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      noise.start(now);
      noise.stop(now + 0.25);

      // Heterodyne tuning whistle
      const whistle = this.ctx.createOscillator();
      const wGain = this.ctx.createGain();
      whistle.type = 'sine';
      whistle.frequency.setValueAtTime(2200, now);
      whistle.frequency.exponentialRampToValueAtTime(600, now + 0.18);
      
      wGain.gain.setValueAtTime(0.08, now);
      wGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

      whistle.connect(wGain);
      wGain.connect(this.masterGain);
      whistle.start(now);
      whistle.stop(now + 0.22);
    } catch {
      // safe fallback
    }
  }

  public setFrequency(freq: number) {
    this.frequency = freq;
    this.playTuningSweep();

    // Match station
    const station = RADIO_STATIONS.find(s => Math.abs(s.frequency - freq) < 80);
    if (station) {
      this.setTheme(station.id);
    }
    this.notify();
  }

  public setTheme(theme: AudioTheme) {
    this.currentTheme = theme;
    const station = RADIO_STATIONS.find(s => s.id === theme);
    if (station) {
      this.frequency = station.frequency;
    }

    if (!this.ctx || !this.jazzGain || !this.orchGain || !this.numbersGain || !this.secretGain) {
      this.notify();
      return;
    }

    const t = this.ctx.currentTime;
    const fadeDuration = 1.0;

    const gains = [
      { target: this.jazzGain, active: theme === 'jazz' },
      { target: this.orchGain, active: theme === 'orchestral' },
      { target: this.numbersGain, active: theme === 'numbers' },
      { target: this.secretGain, active: theme === 'secret_broadcast' }
    ];

    gains.forEach(({ target, active }) => {
      target.gain.cancelScheduledValues(t);
      target.gain.setTargetAtTime(active ? 1.0 : 0.0, t, fadeDuration / 3);
    });

    this.notify();
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime, 0.05);
    }
    this.notify();
  }

  public toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime, 0.05);
    }
    this.notify();
  }

  public playClick(variant: 'light' | 'heavy' | 'switch' | 'toggle' | 'ratchet' | 'metal' = 'light') {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;

      if (variant === 'switch' || variant === 'toggle') {
        // Heavy military toggle / knife-switch sound
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(420, now);
        osc.frequency.exponentialRampToValueAtTime(80, now + 0.04);

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(950, now);
        filter.Q.setValueAtTime(3.0, now);

        gain.gain.setValueAtTime(0.28, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.045);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.masterGain);

        osc.start(now);
        osc.stop(now + 0.05);

        // Secondary metal contact snap
        const clickOsc = this.ctx.createOscillator();
        const clickGain = this.ctx.createGain();
        clickOsc.type = 'square';
        clickOsc.frequency.setValueAtTime(2400, now);
        clickGain.gain.setValueAtTime(0.12, now);
        clickGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.015);
        clickOsc.connect(clickGain);
        clickGain.connect(this.masterGain);
        clickOsc.start(now);
        clickOsc.stop(now + 0.02);

      } else if (variant === 'ratchet') {
        // Rotary dial / mechanical detent tooth ratchet
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(1600, now);
        osc.frequency.exponentialRampToValueAtTime(300, now + 0.018);

        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.018);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + 0.02);

      } else if (variant === 'heavy') {
        // Industrial relay / solenoid latch impact
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.exponentialRampToValueAtTime(45, now + 0.06);

        gain.gain.setValueAtTime(0.32, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.065);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + 0.07);

      } else if (variant === 'metal') {
        // Metallic instrument ping
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(2800, now);
        gain.gain.setValueAtTime(0.14, now);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.05);
        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + 0.055);

      } else {
        // 'light' default: crisp typewriter keycap click
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(1400, now);
        osc.frequency.exponentialRampToValueAtTime(350, now + 0.022);

        gain.gain.setValueAtTime(0.16, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.025);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + 0.028);
      }
    } catch {
      // safe fallback
    }
  }

  public playTeletypeKey() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      // 1. Mechanical metal typebar strike
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(1800 + Math.random() * 400, now);
      osc.frequency.exponentialRampToValueAtTime(250, now + 0.035);

      gain.gain.setValueAtTime(0.22, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.04);

      // 2. Carriage platen impact thud
      const thudOsc = this.ctx.createOscillator();
      const thudGain = this.ctx.createGain();
      thudOsc.type = 'sine';
      thudOsc.frequency.setValueAtTime(140, now);
      thudOsc.frequency.exponentialRampToValueAtTime(45, now + 0.05);
      thudGain.gain.setValueAtTime(0.18, now);
      thudGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
      thudOsc.connect(thudGain);
      thudGain.connect(this.masterGain);
      thudOsc.start(now);
      thudOsc.stop(now + 0.055);
    } catch {
      // safe fallback
    }
  }

  public playStampThud() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      // Heavy rubber/wooden seal stamp impact
      const boom = this.ctx.createOscillator();
      const boomGain = this.ctx.createGain();
      boom.type = 'sine';
      boom.frequency.setValueAtTime(110, now);
      boom.frequency.exponentialRampToValueAtTime(30, now + 0.12);

      boomGain.gain.setValueAtTime(0.45, now);
      boomGain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);

      boom.connect(boomGain);
      boomGain.connect(this.masterGain);
      boom.start(now);
      boom.stop(now + 0.14);

      // Paper slap transient
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.04);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * 0.25;
      }
      const slap = this.ctx.createBufferSource();
      slap.buffer = buffer;
      const slapFilter = this.ctx.createBiquadFilter();
      slapFilter.type = 'bandpass';
      slapFilter.frequency.setValueAtTime(1200, now);
      const slapGain = this.ctx.createGain();
      slapGain.gain.setValueAtTime(0.2, now);
      slapGain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

      slap.connect(slapFilter);
      slapFilter.connect(slapGain);
      slapGain.connect(this.masterGain);
      slap.start(now);
      slap.stop(now + 0.04);
    } catch {
      // safe fallback
    }
  }

  public playPaperRustle() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      const bufferSize = Math.floor(this.ctx.sampleRate * 0.08);
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * 0.15;
      }
      const rustle = this.ctx.createBufferSource();
      rustle.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(2600, now);
      filter.Q.setValueAtTime(1.5, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.075);

      rustle.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      rustle.start(now);
      rustle.stop(now + 0.08);
    } catch {
      // safe fallback
    }
  }

  public playAlertTone() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(580, now);
      osc.frequency.setValueAtTime(740, now + 0.08);
      osc.frequency.setValueAtTime(580, now + 0.16);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1800, now);

      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.3);
    } catch {
      // safe fallback
    }
  }

  public playTelemetryBeep() {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(1480, now);
      osc.frequency.exponentialRampToValueAtTime(1920, now + 0.06);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.09);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.095);
    } catch {
      // safe fallback
    }
  }

  // Convenient sound aliases
  public playSwitch() { this.playClick('switch'); }
  public playRatchet() { this.playClick('ratchet'); }
  public playStamp() { this.playStampThud(); }
  public playTeletype() { this.playTeletypeKey(); }
  public playAlert() { this.playAlertTone(); }

  public playMorseBeep(isDash: boolean = false) {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    try {
      const now = this.ctx.currentTime;
      const duration = isDash ? 0.20 : 0.07;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      // Authentic 1930s tube radio BFO heterodyne pitch
      osc.type = 'sine';
      osc.frequency.setValueAtTime(780, now);

      // Smooth attack/decay envelope to prevent harsh digital clicks
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.16, now + 0.008);
      gain.gain.setValueAtTime(0.16, now + duration - 0.008);
      gain.gain.linearRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      gain.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + duration + 0.01);
    } catch {
      // safe fallback
    }
  }

  public speakChapter(transcript: string, onEnd?: () => void) {
    if (!('speechSynthesis' in window)) {
      return;
    }

    this.stopSpeech();
    this.isSpeaking = true;
    this.notify();

    const utterance = new SpeechSynthesisUtterance(transcript);
    utterance.lang = 'ru-RU';
    utterance.pitch = 0.85; // Lower, dramatic voice
    utterance.rate = 0.95;  // Deliberate telegraphic tempo

    utterance.onend = () => {
      this.isSpeaking = false;
      this.notify();
      if (onEnd) onEnd();
    };

    utterance.onerror = () => {
      this.isSpeaking = false;
      this.notify();
    };

    window.speechSynthesis.speak(utterance);
  }

  public stopSpeech() {
    if ('speechSynthesis' in window && window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
    }
    this.isSpeaking = false;
    this.notify();
  }

  public getState() {
    return {
      isPlaying: this.isPlaying,
      theme: this.currentTheme,
      isMuted: this.isMuted,
      volume: this.volume,
      frequency: this.frequency,
      isSpeaking: this.isSpeaking
    };
  }

  // --- Procedural Synthesizer Main Loop ---
  private tick() {
    if (!this.ctx || !this.isPlaying) return;
    const now = this.ctx.currentTime;

    // 1. JAZZ (780 kHz)
    if (this.currentTheme === 'jazz' || (this.jazzGain && this.jazzGain.gain.value > 0.05)) {
      this.playJazzStep(now, this.step);
    }

    // 2. ORCHESTRAL (1140 kHz)
    if (this.currentTheme === 'orchestral' || (this.orchGain && this.orchGain.gain.value > 0.05)) {
      this.playOrchestralStep(now, this.step);
    }

    // 3. NUMBERS STATION / THE BUZZER (1420 kHz)
    if (this.currentTheme === 'numbers' || (this.numbersGain && this.numbersGain.gain.value > 0.05)) {
      this.playNumbersStep(now, this.step);
    }

    // 4. SECRET BROADCAST / PROJECT AURORA (1939 kHz)
    if (this.currentTheme === 'secret_broadcast' || (this.secretGain && this.secretGain.gain.value > 0.05)) {
      this.playSecretStep(now, this.step);
    }

    this.step = (this.step + 1) % 16;
  }

  private playJazzStep(now: number, s: number) {
    if (!this.ctx || !this.jazzGain) return;

    // Walking Bassline
    const bassNotes = [
      73.42, 82.41, 87.31, 98.00,
      98.00, 110.00, 116.54, 123.47,
      65.41, 73.42, 82.41, 98.00,
      110.00, 116.54, 103.83, 73.42
    ];
    const bassFreq = bassNotes[s % bassNotes.length];
    
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(bassFreq, now);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, now);

    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.jazzGain);

    osc.start(now);
    osc.stop(now + 0.35);

    // Mellow Piano Chord Stabs
    if ([2, 6, 10, 14].includes(s)) {
      const chords = [
        [293.66, 349.23, 440.00, 523.25], // Dm7
        [392.00, 493.88, 587.33, 698.46], // G7
        [261.63, 329.63, 392.00, 493.88], // Cmaj7
        [220.00, 277.18, 329.63, 392.00]  // A7
      ];
      const chord = chords[Math.floor(s / 4)];
      chord.forEach(freq => {
        if (!this.ctx || !this.jazzGain) return;
        const pOsc = this.ctx.createOscillator();
        const pGain = this.ctx.createGain();
        const pFilter = this.ctx.createBiquadFilter();

        pOsc.type = 'sine';
        pOsc.frequency.setValueAtTime(freq, now);

        pFilter.type = 'lowpass';
        pFilter.frequency.setValueAtTime(800, now);

        pGain.gain.setValueAtTime(0.08, now);
        pGain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

        pOsc.connect(pFilter);
        pFilter.connect(pGain);
        pGain.connect(this.jazzGain);

        pOsc.start(now);
        pOsc.stop(now + 0.48);
      });
    }

    if (s % 2 === 0 || s % 3 === 0) {
      this.playSnareBrush(now, s % 4 === 2 ? 0.08 : 0.03);
    }
  }

  private playOrchestralStep(now: number, s: number) {
    if (!this.ctx || !this.orchGain) return;

    // Heavy War Timpani
    if ([0, 4, 8, 10, 12, 14].includes(s)) {
      const drumOsc = this.ctx.createOscillator();
      const drumGain = this.ctx.createGain();
      
      drumOsc.type = 'sine';
      const rootFreq = s === 0 || s === 8 ? 65 : 55;
      drumOsc.frequency.setValueAtTime(rootFreq + 40, now);
      drumOsc.frequency.exponentialRampToValueAtTime(rootFreq, now + 0.12);

      const vol = s === 0 ? 0.6 : (s === 8 ? 0.5 : 0.35);
      drumGain.gain.setValueAtTime(vol, now);
      drumGain.gain.exponentialRampToValueAtTime(0.001, now + 0.38);

      drumOsc.connect(drumGain);
      drumGain.connect(this.orchGain);

      drumOsc.start(now);
      drumOsc.stop(now + 0.4);
    }

    // Low Cello Drone
    if (s % 8 === 0) {
      const droneOsc = this.ctx.createOscillator();
      const droneOsc2 = this.ctx.createOscillator();
      const droneGain = this.ctx.createGain();
      const droneFilter = this.ctx.createBiquadFilter();

      droneOsc.type = 'sawtooth';
      droneOsc2.type = 'sawtooth';
      
      droneOsc.frequency.setValueAtTime(55, now);
      droneOsc2.frequency.setValueAtTime(55.6, now);

      droneFilter.type = 'lowpass';
      droneFilter.frequency.setValueAtTime(240, now);

      droneGain.gain.setValueAtTime(0.18, now);
      droneGain.gain.exponentialRampToValueAtTime(0.001, now + 2.1);

      droneOsc.connect(droneFilter);
      droneOsc2.connect(droneFilter);
      droneFilter.connect(droneGain);
      droneGain.connect(this.orchGain);

      droneOsc.start(now);
      droneOsc2.start(now);
      droneOsc.stop(now + 2.2);
      droneOsc2.stop(now + 2.2);
    }

    // Menacing Brass Stabs
    if ([0, 3, 6, 8, 12].includes(s)) {
      const brassTones = s < 8 ? [164.81, 196.00, 246.94] : [155.56, 196.00, 233.08];
      brassTones.forEach(freq => {
        if (!this.ctx || !this.orchGain) return;
        const bOsc = this.ctx.createOscillator();
        const bGain = this.ctx.createGain();
        const bFilter = this.ctx.createBiquadFilter();

        bOsc.type = 'sawtooth';
        bOsc.frequency.setValueAtTime(freq, now);

        bFilter.type = 'bandpass';
        bFilter.frequency.setValueAtTime(650, now);
        bFilter.Q.setValueAtTime(2.0, now);

        bGain.gain.setValueAtTime(0.12, now);
        bGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

        bOsc.connect(bFilter);
        bFilter.connect(bGain);
        bGain.connect(this.orchGain);

        bOsc.start(now);
        bOsc.stop(now + 0.38);
      });
    }
  }

  private playNumbersStep(now: number, s: number) {
    if (!this.ctx || !this.numbersGain) return;

    // Iconic Cold War "Buzzer" Pulse every beat
    if (s % 4 === 0) {
      const buzzOsc = this.ctx.createOscillator();
      const buzzGain = this.ctx.createGain();
      const buzzFilter = this.ctx.createBiquadFilter();

      buzzOsc.type = 'sawtooth';
      buzzOsc.frequency.setValueAtTime(140, now);

      buzzFilter.type = 'bandpass';
      buzzFilter.frequency.setValueAtTime(450, now);
      buzzFilter.Q.setValueAtTime(4.0, now);

      buzzGain.gain.setValueAtTime(0.25, now);
      buzzGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      buzzOsc.connect(buzzFilter);
      buzzFilter.connect(buzzGain);
      buzzGain.connect(this.numbersGain);

      buzzOsc.start(now);
      buzzOsc.stop(now + 0.2);
    }

    // Mysterious Chime Melody (Lincolnshire Poacher interval motif)
    if ([1, 3, 7, 9, 13].includes(s)) {
      const chimeNotes = [587.33, 659.25, 783.99, 880.00, 1046.50];
      const noteFreq = chimeNotes[(s * 3) % chimeNotes.length];

      const cOsc = this.ctx.createOscillator();
      const cGain = this.ctx.createGain();

      cOsc.type = 'sine';
      cOsc.frequency.setValueAtTime(noteFreq, now);

      cGain.gain.setValueAtTime(0.12, now);
      cGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);

      cOsc.connect(cGain);
      cGain.connect(this.numbersGain);

      cOsc.start(now);
      cOsc.stop(now + 0.52);
    }
  }

  private playSecretStep(now: number, s: number) {
    if (!this.ctx || !this.secretGain) return;

    // Atmospheric Deep Sub Drone (Occult resonant tone)
    if (s % 8 === 0) {
      const subOsc = this.ctx.createOscillator();
      const subGain = this.ctx.createGain();
      const subFilter = this.ctx.createBiquadFilter();

      subOsc.type = 'sawtooth';
      subOsc.frequency.setValueAtTime(43.65, now); // F0 deep rumble

      subFilter.type = 'lowpass';
      subFilter.frequency.setValueAtTime(180, now);

      subGain.gain.setValueAtTime(0.28, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 2.2);

      subOsc.connect(subFilter);
      subFilter.connect(subGain);
      subGain.connect(this.secretGain);

      subOsc.start(now);
      subOsc.stop(now + 2.3);
    }

    // High Ethereal Glass / Theremin Tone
    if (s % 4 === 2) {
      const etherealOsc = this.ctx.createOscillator();
      const etherealGain = this.ctx.createGain();

      etherealOsc.type = 'sine';
      const tones = [698.46, 830.61, 987.77, 1174.66]; // Suspense minor
      etherealOsc.frequency.setValueAtTime(tones[Math.floor(s / 4)], now);

      etherealGain.gain.setValueAtTime(0.08, now);
      etherealGain.gain.exponentialRampToValueAtTime(0.001, now + 0.7);

      etherealOsc.connect(etherealGain);
      etherealGain.connect(this.secretGain);

      etherealOsc.start(now);
      etherealOsc.stop(now + 0.75);
    }

    // Background Morse Beep Pattern on odd beats
    if ([1, 5, 9, 11, 15].includes(s)) {
      const mOsc = this.ctx.createOscillator();
      const mGain = this.ctx.createGain();

      mOsc.type = 'sine';
      mOsc.frequency.setValueAtTime(950, now);

      const isLong = s === 9 || s === 15;
      mGain.gain.setValueAtTime(0.06, now);
      mGain.gain.exponentialRampToValueAtTime(0.0001, now + (isLong ? 0.16 : 0.06));

      mOsc.connect(mGain);
      mGain.connect(this.secretGain);

      mOsc.start(now);
      mOsc.stop(now + (isLong ? 0.18 : 0.08));
    }
  }

  private playSnareBrush(now: number, vol: number) {
    if (!this.ctx || !this.jazzGain) return;
    try {
      const noiseBuffer = this.ctx.createBuffer(1, this.ctx.sampleRate * 0.08, this.ctx.sampleRate);
      const data = noiseBuffer.getChannelData(0);
      for (let i = 0; i < data.length; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = this.ctx.createBufferSource();
      noise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(4500, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(vol, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.jazzGain);

      noise.start(now);
      noise.stop(now + 0.08);
    } catch {
      // safe fallback
    }
  }
}

export const audioEngine = new AudioEngine();
