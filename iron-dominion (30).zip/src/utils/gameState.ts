// Iron Dominion - Grand Strategy Simulation Engine
// Unified Game State: Time, Economy, Frontline Warfare, Factions, Espionage, R&D, Consequence Queue, Crises & World Chronicle

export type GameSpeed = 0 | 1 | 2 | 5; // 0 = Paused, 1x, 2x, 5x

export interface GameResources {
  oil: number;          // Топливо (баррели)
  oilDelta: number;
  steel: number;        // Сталь (тонны)
  steelDelta: number;
  rareEarth: number;    // Вольфрам и редкие металлы (кг)
  rareEarthDelta: number;
  food: number;         // Продовольствие (тонны)
  foodDelta: number;
  electricity: number;  // Электроэнергия (МВт)
  electricityDelta: number;
  treasury: number;     // Казна (тыс. рейхсмарок)
  treasuryDelta: number;
}

export interface FactionState {
  id: string;
  name: string;
  role: string;
  loyalty: number;    // 0 - 100%
  influence: number;  // 0 - 100%
  leader: string;
  perk: string;
  threat: string;
  status: 'loyal' | 'neutral' | 'unrest' | 'mutinous';
}

export interface StrategicProvince {
  id: string;
  name: string;
  controller: 'allied' | 'contested' | 'enemy';
  controlPercent: number; // 0 - 100%
  unrest: number;         // 0 - 100%
  loyalty: 'Высокая' | 'Средняя' | 'Низкая' | 'Враждебная';
  garrisonDivisions: number;
  enemyDivisions: number;
  fortificationLevel: number; // 0 - 5
  supplyStatus: 'optimal' | 'strained' | 'encircled';
  infrastructure: number; // 0 - 100%
  resourceYield: {
    oil: number;
    steel: number;
    food: number;
    rareEarth: number;
    electricity: number;
    treasury: number;
  };
  combatFrontlineActive: boolean;
  frontlineCasualties: {
    alliedTotal: number;
    enemyTotal: number;
  };
  description: string;
}

export interface CountryDiplomacyState {
  id: string;
  name: string;
  code: string;
  relations: number;        // -100 to +100
  tension: number;          // 0 - 100%
  intelCoverage: number;    // 0 - 100%
  status: 'allied' | 'friendly' | 'neutral' | 'strained' | 'crisis' | 'mobilizing' | 'war' | 'collapsed';
  counterIntelActive: boolean;
  counterIntelTargetArea?: string;
  mobilizationDivisions: number;
  tradeStatus: 'open' | 'embargo' | 'exclusive';
  knownIntelReports: {
    minIntel: number;
    text: string;
    unlocked: boolean;
  }[];
  description: string;
}

export interface CausalNode {
  id: string;
  originAction: string;
  originDay: number;
  triggerDay: number;
  daysRemaining: number;
  severity: 'low' | 'medium' | 'high' | 'critical' | 'triumph';
  status: 'pending' | 'triggered' | 'resolved' | 'averted';
  knownEffects: string[];
  hiddenEffectsCount: number;
  intelRequiredToForecast: number;
  forecastHint: string;
  parentCausalId?: string;
  childCausalIds?: string[];
  decisionChoiceTaken?: string;
  resultingEventTitle?: string;
  conditions?: {
    minTension?: number;
    maxOil?: number;
    minDay?: number;
    maxRelations?: number;
    countryId?: string;
  };
}

export interface SpyAgent {
  id: string;
  codename: string;
  realName: string;
  skill: number; // 1 - 5 stars
  specialty: 'sabotage' | 'infiltration' | 'signals' | 'assassination' | 'propaganda';
  assignedLocation: string; // Province or Country
  currentMission: {
    id: string;
    name: string;
    daysRemaining: number;
    totalDays: number;
    risk: 'low' | 'medium' | 'high' | 'deadly';
    rewardDesc: string;
    causalOriginAction?: string;
  } | null;
  status: 'idle' | 'on_mission' | 'compromised' | 'captured';
  isTargetedByCounterIntel?: boolean;
  threatLevel?: number; // 0 - 100%
  coverIdentity?: string;
  missionsCompleted: number;
}

export interface SpyMissionType {
  id: string;
  name: string;
  specialty: SpyAgent['specialty'];
  durationDays: number;
  risk: 'low' | 'medium' | 'high' | 'deadly';
  costTreasury: number;
  description: string;
  potentialRewards: string[];
  causesHiddenConsequence?: {
    title: string;
    daysDelay: number;
    intelRequired: number;
    forecast: string;
    possibleOutcomeDesc: string;
  };
}

export interface TechNode {
  id: string;
  name: string;
  category: 'armor' | 'signals' | 'logistics' | 'doctrine';
  costDays: number;
  costSteel: number;
  costRareEarth: number;
  costTreasury: number;
  daysRemaining: number;
  status: 'locked' | 'available' | 'researching' | 'completed';
  prereq?: string;
  description: string;
  effectDesc: string;
}

export interface DeferredConsequence {
  id: string;
  title: string;
  triggerDateDay: number; // Target simulated day count
  daysLeft: number;
  originAction: string;
  description: string;
  severity: 'info' | 'warning' | 'critical' | 'triumph';
  applied: boolean;
  parentCausalId?: string;
  intelRequired?: number;
  forecast?: string;
  effect: {
    stabilityDelta?: number;
    warWearinessDelta?: number;
    militaryReadinessDelta?: number;
    oilDelta?: number;
    steelDelta?: number;
    treasuryDelta?: number;
    frontlineShiftProvinceId?: string;
    frontlineShiftDelta?: number;
    factionId?: string;
    factionLoyaltyDelta?: number;
    secretScenarioId?: string;
    secretScenarioClueDelta?: number;
    countryId?: string;
    countryRelationsDelta?: number;
    countryTensionDelta?: number;
    triggerEvent?: Omit<ActiveCrisisModal, 'id'>;
  };
}

export interface SecretScenario {
  id: string;
  code: string;
  name: string;
  icon: string;
  progressPercent: number; // 0 - 100%
  unlockedStage: number;   // 1 to 4
  status: 'dormant' | 'investigating' | 'exposed' | 'countered' | 'cataclysm';
  summary: string;
  cluesFound: string[];
  maxClues: number;
  countermeasureAvailable: boolean;
  countermeasureDesc?: string;
}

export interface ChronicleEntry {
  id: string;
  timestamp: string; // e.g. "18 АВГ 1934"
  dayCount: number;
  category: 'war' | 'politics' | 'economy' | 'espionage' | 'secret' | 'tech';
  title: string;
  details: string;
  badge?: string;
  impactColor?: string;
  causalChainId?: string;
  causedByAction?: string;
  causedByDay?: number;
}

export interface ActiveCrisisModal {
  id: string;
  title: string;
  stamp: string;
  origin: string;
  description: string;
  severity: 'low' | 'medium' | 'high' | 'critical' | 'opportunity' | 'event';
  type?: 'crisis' | 'opportunity' | 'dilemma' | 'event';
  category?: 'politics' | 'war' | 'economy' | 'diplomacy' | 'society' | 'science' | 'peacetime';
  causalOriginId?: string;
  interceptFrequency?: string;
  options: {
    id: string;
    text: string;
    costDesc: string;
    consequenceDesc: string;
    successRate?: number; // 0-100%
    hiddenRiskDesc?: string;
    deferredEffect?: {
      title: string;
      daysDelay: number;
      description: string;
      severity: DeferredConsequence['severity'];
      effect: DeferredConsequence['effect'];
      intelRequired?: number;
      forecast?: string;
    };
    instantEffect?: () => void;
  }[];
}

export interface GameState {
  // Time system
  currentDate: {
    day: number;
    month: number; // 1-12
    year: number;
  };
  totalDaysElapsed: number;
  gameSpeed: GameSpeed;
  isPaused: boolean;

  // National metrics
  stability: number;       // 0 - 100%
  warWeariness: number;    // 0 - 100%
  militaryReadiness: number; // 0 - 100%

  // Economy
  resources: GameResources;

  // Foreign Powers & Diplomacy
  countries: CountryDiplomacyState[];

  // Political Factions
  factions: FactionState[];

  // World Map & Provinces
  provinces: StrategicProvince[];

  // Espionage
  agents: SpyAgent[];

  // Technology
  techTree: TechNode[];

  // Consequence Ripple Queue
  consequences: DeferredConsequence[];

  // Full Causal History Tree
  causalGraph: CausalNode[];

  // 5 Secret Shadow Megaplots
  secretScenarios: SecretScenario[];

  // World History Archive
  chronicle: ChronicleEntry[];

  // Active Emergency Crisis Pop-up
  activeCrisis: ActiveCrisisModal | null;

  // War Stats
  warSummary: {
    totalBattlesFought: number;
    alliedCasualties: number;
    enemyCasualties: number;
    provincesCaptured: number;
    provincesLost: number;
  };

  // Onboarding
  tutorialCompleted: boolean;
}

// Initial Starting Game State
export const INITIAL_GAME_STATE: GameState = {
  currentDate: {
    day: 15,
    month: 8,
    year: 1934
  },
  totalDaysElapsed: 0,
  gameSpeed: 1,
  isPaused: false,

  stability: 74,
  warWeariness: 18,
  militaryReadiness: 85,

  resources: {
    oil: 4200,
    oilDelta: 85,
    steel: 12500,
    steelDelta: 310,
    rareEarth: 890,
    rareEarthDelta: 22,
    food: 18200,
    foodDelta: 140,
    electricity: 920,
    electricityDelta: 15,
    treasury: 14500,
    treasuryDelta: -45
  },

  countries: [
    {
      id: 'norland',
      name: 'Королевство Норланд',
      code: 'NOR',
      relations: 42,
      tension: 18,
      intelCoverage: 35,
      status: 'neutral',
      counterIntelActive: false,
      counterIntelTargetArea: 'Норланд (Столица)',
      mobilizationDivisions: 5,
      tradeStatus: 'open',
      knownIntelReports: [
        { minIntel: 20, text: 'Приграничные гарнизоны несут службу в штатном режиме мирного времени.', unlocked: true },
        { minIntel: 50, text: 'Секретная служба Норланда расследует каналы нелегального ввоза оружия в приграничных провинциях.', unlocked: false },
        { minIntel: 80, text: 'Штаб 3-й механизированной дивизии готов к развертыванию на рубеже «Фалькенбург» за 48 часов.', unlocked: false },
        { minIntel: 95, text: 'Шеф контрразведки полковник Торвальд лично курирует охоту на зарубежную агентурную сеть.', unlocked: false }
      ],
      description: 'Северная индустриальная монархия. Исторический соперник Доминиона, обладающий сильным флотом и развитой сетью контрразведки.'
    },
    {
      id: 'falkenburg_coalition',
      name: 'Фалькенбургская Лига',
      code: 'FLK',
      relations: -65,
      tension: 72,
      intelCoverage: 55,
      status: 'war',
      counterIntelActive: true,
      counterIntelTargetArea: 'Фалькенбург',
      mobilizationDivisions: 8,
      tradeStatus: 'embargo',
      knownIntelReports: [
        { minIntel: 25, text: 'Тяжелые ДОТы и укрепления первой линии укомплектованы на 90%.', unlocked: true },
        { minIntel: 60, text: 'В секторе сосредоточено 6 вражеских дивизий и бронепоезд «Зигфрид».', unlocked: false }
      ],
      description: 'Милитаристская коалиция, удерживающая укрепленный плацдарм на западных рубежах.'
    },
    {
      id: 'ethelgard_republic',
      name: 'Торговая Республика Этельгард',
      code: 'ETH',
      relations: 55,
      tension: 12,
      intelCoverage: 40,
      status: 'friendly',
      counterIntelActive: false,
      mobilizationDivisions: 2,
      tradeStatus: 'exclusive',
      knownIntelReports: [
        { minIntel: 30, text: 'Морские танкеры обеспечивают 40% нефтяного импорта Доминиона.', unlocked: true }
      ],
      description: 'Морская торговая держава, контролирующая нефтяные терминалы и нейтральные проливы.'
    }
  ],

  factions: [
    {
      id: 'military',
      name: 'Генеральный Штаб & Армейский Корпус',
      role: 'Высшее командование сухопутных и бронетанковых сил',
      loyalty: 82,
      influence: 45,
      leader: 'Генерал-фельдмаршал фон Шталь',
      perk: '+15% к боевой мощи танковых клиньев',
      threat: 'Угроза военного путча при снижении лояльности < 30%',
      status: 'loyal'
    },
    {
      id: 'industrialists',
      name: 'Концерн «Штальверке» & Олигархия',
      role: 'Тяжелая промышленность, оружейные синдикаты и сырьевые магнаты',
      loyalty: 68,
      influence: 35,
      leader: 'Барон Курт фон Альтенбург',
      perk: '+20% к скорости производства бронетехники',
      threat: 'Локаут военных заводов и взвинчивание цен на сталь',
      status: 'loyal'
    },
    {
      id: 'labor',
      name: 'Профсоюзы & Рабочий Класс',
      role: 'Трудящиеся угольных копей, заводов и транспортных магистралей',
      loyalty: 58,
      influence: 28,
      leader: 'Председатель союза горняков Рудольф Келлер',
      perk: 'Высокая стабильность и отсутствие забастовок',
      threat: 'Всеобщая стачка и паралич железных дорог',
      status: 'neutral'
    },
    {
      id: 'shadow_elite',
      name: 'Теневой Банковский Картель & Аристократия',
      role: 'Тайные кредиторы, масоны и дипломатические посредники',
      loyalty: 70,
      influence: 40,
      leader: 'Графиня Элеонора де Морнэ',
      perk: '+50 тыс. рейхсмарок экстренного кредита без процентов',
      threat: 'Организация глобального валютного бойкота и эмбарго',
      status: 'loyal'
    }
  ],

  provinces: [
    {
      id: 'ostenmark',
      name: 'Остенмарк',
      controller: 'allied',
      controlPercent: 88,
      unrest: 42,
      loyalty: 'Средняя',
      garrisonDivisions: 4,
      enemyDivisions: 1,
      fortificationLevel: 3,
      supplyStatus: 'optimal',
      infrastructure: 75,
      resourceYield: { oil: 10, steel: 180, food: 20, rareEarth: 12, electricity: 120, treasury: 30 },
      combatFrontlineActive: true,
      frontlineCasualties: { alliedTotal: 1240, enemyTotal: 2180 },
      description: 'Индустриальное сердце Доминиона. Крупнейшие сталеплавильные заводы и угольные копи.'
    },
    {
      id: 'vorn',
      name: 'Ворн',
      controller: 'allied',
      controlPercent: 100,
      unrest: 12,
      loyalty: 'Высокая',
      garrisonDivisions: 2,
      enemyDivisions: 0,
      fortificationLevel: 2,
      supplyStatus: 'optimal',
      infrastructure: 90,
      resourceYield: { oil: 0, steel: 20, food: 190, rareEarth: 0, electricity: 40, treasury: 45 },
      combatFrontlineActive: false,
      frontlineCasualties: { alliedTotal: 80, enemyTotal: 120 },
      description: 'Плодородные житницы и оплот лоялистов. Центр государственной агитации.'
    },
    {
      id: 'korsak',
      name: 'Корсак',
      controller: 'contested',
      controlPercent: 54,
      unrest: 85,
      loyalty: 'Враждебная',
      garrisonDivisions: 3,
      enemyDivisions: 4,
      fortificationLevel: 1,
      supplyStatus: 'strained',
      infrastructure: 40,
      resourceYield: { oil: 0, steel: 15, food: 30, rareEarth: 8, electricity: 10, treasury: -15 },
      combatFrontlineActive: true,
      frontlineCasualties: { alliedTotal: 3400, enemyTotal: 4100 },
      description: 'Непроходимые таёжные леса и горы. Очаг партизанских отрядов и диверсий.'
    },
    {
      id: 'aethelgard',
      name: 'Этельгард',
      controller: 'allied',
      controlPercent: 92,
      unrest: 38,
      loyalty: 'Средняя',
      garrisonDivisions: 3,
      enemyDivisions: 0,
      fortificationLevel: 4,
      supplyStatus: 'optimal',
      infrastructure: 85,
      resourceYield: { oil: 120, steel: 40, food: 40, rareEarth: 5, electricity: 90, treasury: 80 },
      combatFrontlineActive: false,
      frontlineCasualties: { alliedTotal: 400, enemyTotal: 650 },
      description: 'Главный морской порт и нефтяные терминалы Доминиона. Врата международной торговли.'
    },
    {
      id: 'nordgau',
      name: 'Нордгауз',
      controller: 'allied',
      controlPercent: 95,
      unrest: 22,
      loyalty: 'Высокая',
      garrisonDivisions: 2,
      enemyDivisions: 0,
      fortificationLevel: 5,
      supplyStatus: 'optimal',
      infrastructure: 60,
      resourceYield: { oil: 0, steel: 80, food: 10, rareEarth: 25, electricity: 110, treasury: 20 },
      combatFrontlineActive: false,
      frontlineCasualties: { alliedTotal: 150, enemyTotal: 300 },
      description: 'Горные рудники редких металлов и вольфрама. Неприступная цитадель «Орлиное Гнездо».'
    },
    {
      id: 'falkenburg',
      name: 'Фалькенбург',
      controller: 'enemy',
      controlPercent: 15,
      unrest: 90,
      loyalty: 'Враждебная',
      garrisonDivisions: 1,
      enemyDivisions: 6,
      fortificationLevel: 4,
      supplyStatus: 'encircled',
      infrastructure: 30,
      resourceYield: { oil: 15, steel: 50, food: 15, rareEarth: 2, electricity: 20, treasury: -25 },
      combatFrontlineActive: true,
      frontlineCasualties: { alliedTotal: 4800, enemyTotal: 7200 },
      description: 'Вражеский плацдарм коалиции Норланда. Линия тяжелых ДОТов и артиллерии.'
    }
  ],

  agents: [
    {
      id: 'agent_1',
      codename: '«Серая Сова»',
      realName: 'Майор Анна Воронова',
      skill: 4,
      specialty: 'signals',
      assignedLocation: 'Фалькенбург',
      currentMission: null,
      status: 'idle',
      missionsCompleted: 6
    },
    {
      id: 'agent_2',
      codename: '«Чёрный Молот»',
      realName: 'Капитан Эрих Краузе',
      skill: 5,
      specialty: 'sabotage',
      assignedLocation: 'Корсак',
      currentMission: {
        id: 'm_korsak_rails',
        name: 'Подрыв узловой станции снабжения врага',
        daysRemaining: 4,
        totalDays: 8,
        risk: 'high',
        rewardDesc: 'Вражеские дивизии в Корсаке попадут в кольцо блокады'
      },
      status: 'on_mission',
      missionsCompleted: 9
    },
    {
      id: 'agent_3',
      codename: '«Минерва»',
      realName: 'Баронесса София Линд',
      skill: 4,
      specialty: 'infiltration',
      assignedLocation: 'Норланд (Столица врага)',
      currentMission: null,
      status: 'idle',
      missionsCompleted: 4
    },
    {
      id: 'agent_4',
      codename: '«Фантом-07»',
      realName: 'Лейтенант Марк Дюваль',
      skill: 3,
      specialty: 'assassination',
      assignedLocation: 'Этельгард',
      currentMission: null,
      status: 'idle',
      missionsCompleted: 2
    }
  ],

  techTree: [
    {
      id: 'tech_tanks_1',
      name: 'Тяжёлое литое бронирование',
      category: 'armor',
      costDays: 14,
      costSteel: 600,
      costRareEarth: 40,
      costTreasury: 350,
      daysRemaining: 5,
      status: 'researching',
      description: 'Разработка наклонных бронеплит из хромоникелевой стали для тяжелых танков прорыва.',
      effectDesc: '+25% к выживаемости бронетанковых клиньев в War Room'
    },
    {
      id: 'tech_signals_1',
      name: 'Шифровальная машина «Энигма-М»',
      category: 'signals',
      costDays: 10,
      costSteel: 150,
      costRareEarth: 80,
      costTreasury: 500,
      daysRemaining: 10,
      status: 'available',
      description: 'Электромеханический роторный шифратор для защиты штабных депеш и перехвата шифров врага.',
      effectDesc: '+35% к вероятности раскрытия скрытых сценариев и предотвращения диверсий'
    },
    {
      id: 'tech_logistics_1',
      name: 'Синтетический бензин Фишера-Тропша',
      category: 'logistics',
      costDays: 20,
      costSteel: 400,
      costRareEarth: 60,
      costTreasury: 800,
      daysRemaining: 20,
      status: 'available',
      description: 'Превращение каменного угля Остенмарка в высокооктановое синтетическое топливо.',
      effectDesc: '+90 баррелей нефти в день даже при морской блокаде'
    },
    {
      id: 'tech_doctrine_1',
      name: 'Доктрина «Глубокой операции»',
      category: 'doctrine',
      costDays: 15,
      costSteel: 100,
      costRareEarth: 10,
      costTreasury: 400,
      daysRemaining: 0,
      status: 'completed',
      description: 'Скоординированный удар танковых клиньев, моторизованной пехоты и штурмовой авиации.',
      effectDesc: 'Открывает фланговый маневр «Клещи» и прорыв укрепленных линий'
    }
  ],

  consequences: [
    {
      id: 'cq_1',
      title: 'Подкуп бригадного генерала Норланда',
      triggerDateDay: 6,
      daysLeft: 6,
      originAction: 'Спецоперация разведки в Фалькенбурге',
      description: 'Генерал передаст карты минных полей и задержит контратаку 8-го корпуса.',
      severity: 'triumph',
      applied: false,
      effect: {
        frontlineShiftProvinceId: 'falkenburg',
        frontlineShiftDelta: 25,
        secretScenarioId: 'black_sun',
        secretScenarioClueDelta: 1
      }
    },
    {
      id: 'cq_2',
      title: 'Тайный ультиматум профсоюза горняков',
      triggerDateDay: 12,
      daysLeft: 12,
      originAction: 'Отказ от повышения пайков в Остенмарке',
      description: 'Если к этому дню не будет доставлено зерно, шахтёры остановят подачу угля на заводы.',
      severity: 'warning',
      applied: false,
      effect: {
        factionId: 'labor',
        factionLoyaltyDelta: -20,
        steelDelta: -80
      }
    }
  ],

  causalGraph: [
    {
      id: 'cnode_init_1',
      originAction: 'Подкуп бригадного генерала Норланда',
      originDay: 0,
      triggerDay: 6,
      daysRemaining: 6,
      severity: 'triumph',
      status: 'pending',
      knownEffects: ['+25% прорыва фронта', '+1 улика Black Sun'],
      hiddenEffectsCount: 1,
      intelRequiredToForecast: 40,
      forecastHint: 'Генерал передаст карты минных полей, если Норланд не перехватит курьера.',
      childCausalIds: [],
      decisionChoiceTaken: 'Передача 900 золота через подпольный банк'
    },
    {
      id: 'cnode_init_2',
      originAction: 'Отказ от повышения пайков шахтеров Остенмарка',
      originDay: 0,
      triggerDay: 12,
      daysRemaining: 12,
      severity: 'high',
      status: 'pending',
      knownEffects: ['-20% лояльности рабочих', '-80 стали/день'],
      hiddenEffectsCount: 2,
      intelRequiredToForecast: 50,
      forecastHint: 'Подпольная ячейка профсоюза готовит забастовочный комитет.',
      childCausalIds: [],
      decisionChoiceTaken: 'Ввести армейскую охрану на шахты'
    }
  ],

  secretScenarios: [
    {
      id: 'colossus',
      code: 'PROJECT COLOSSUS',
      name: '«Колосс-IX»: Сверхоружие Судного Дня',
      icon: 'Sparkles',
      progressPercent: 35,
      unlockedStage: 2,
      status: 'investigating',
      summary: 'Секретная подземная верфь в глубине Нордгауза строит 800-тонный дизельный титан с орудием калибра 420 мм.',
      cluesFound: [
        'Перехват радиограммы на волне 1939 кГц с кодовым словом AURORA',
        'Чертеж гидравлического шасси сверхтяжелого типа в КБ №7'
      ],
      maxClues: 4,
      countermeasureAvailable: false,
      countermeasureDesc: 'Запустить ускоренное финансирование энергоблока Тесла для завершения сборки'
    },
    {
      id: 'black_sun',
      code: 'BLACK SUN',
      name: '«Чёрное Солнце»: Оккультный Заговор Промышленников',
      icon: 'Eye',
      progressPercent: 20,
      unlockedStage: 1,
      status: 'investigating',
      summary: 'Тайный орден внутри концерна «Штальверке» перенаправляет редкие металлы на секретный культовый бункер.',
      cluesFound: [
        'Аномальные счета за поставки вольфрама через Базельский банк'
      ],
      maxClues: 4,
      countermeasureAvailable: false
    },
    {
      id: 'dead_hand',
      code: 'DEAD HAND (ПЕРИМЕТР)',
      name: '«Мёртвая Рука»: Автоматический Ответный Удар',
      icon: 'Skull',
      progressPercent: 15,
      unlockedStage: 1,
      status: 'investigating',
      summary: 'Автономная сеть ретрансляторов и ракетных шахт, готовая уничтожить ключевые города в случае падения столицы.',
      cluesFound: [
        'Таинственный сейсмический сигнал на сверхдлинных волнах'
      ],
      maxClues: 4,
      countermeasureAvailable: false
    },
    {
      id: 'phantom',
      code: 'PHANTOM NETWORK',
      name: '«Фантом»: Сеть Спящих Кротов в Контрразведке',
      icon: 'ShieldAlert',
      progressPercent: 40,
      unlockedStage: 2,
      status: 'investigating',
      summary: 'Высокопоставленный офицер в Генеральном Штабе сливает шифры движения эшелонов вражеской разведке.',
      cluesFound: [
        'Подозрительный телефонный кабель из кабинета замначальника штаба',
        'Анонимная радиограмма с личным шифром трибунала'
      ],
      maxClues: 4,
      countermeasureAvailable: true,
      countermeasureDesc: 'Провести ночную облаву контрразведки и допрос генералитета'
    },
    {
      id: 'red_meridian',
      code: 'RED MERIDIAN',
      name: '«Красный Меридиан»: Картель Нефтяного Удушья',
      icon: 'Flame',
      progressPercent: 25,
      unlockedStage: 1,
      status: 'investigating',
      summary: 'Синдикат международных танкеров искусственно блокирует проливы, провоцируя топливный коллапс армии.',
      cluesFound: [
        'Таинственное крушение танкера «Валькирия» в порту Этельгарда'
      ],
      maxClues: 4,
      countermeasureAvailable: false
    }
  ],

  chronicle: [
    {
      id: 'chr_1',
      timestamp: '15 АВГ 1934',
      dayCount: 0,
      category: 'politics',
      title: 'Вступление в должность Верховного Главнокомандующего',
      details: 'Принят чрезвычайный декрет №1 о мобилизации промышленного потенциала и реорганизации Генерального Штаба.',
      badge: 'НАЧАЛО КАМПАНИИ',
      impactColor: '#d97706'
    },
    {
      id: 'chr_2',
      timestamp: '15 АВГ 1934',
      dayCount: 0,
      category: 'war',
      title: 'Стабилизация фронта в Корсаке',
      details: '4-й гвардейский корпус занял ключевые высоты вдоль демаркационной линии. Партизанская активность остается высокой.',
      badge: 'ФРОНТ',
      impactColor: '#dc2626'
    }
  ],

  activeCrisis: null,

  warSummary: {
    totalBattlesFought: 14,
    alliedCasualties: 9800,
    enemyCasualties: 14450,
    provincesCaptured: 1,
    provincesLost: 0
  },
  tutorialCompleted: false
};

// Month Names in Russian military archive style
export const MONTH_NAMES = [
  'ЯНВ', 'ФЕВ', 'МАР', 'АПР', 'МАЙ', 'ИЮН',
  'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК'
];

export function formatDate(date: GameState['currentDate']): string {
  return `${date.day.toString().padStart(2, '0')} ${MONTH_NAMES[date.month - 1]} ${date.year}`;
}

export const SPY_MISSION_TYPES: SpyMissionType[] = [
  {
    id: 'support_insurgency',
    name: 'Тайное финансирование повстанцев в Норланде',
    specialty: 'sabotage',
    durationDays: 4,
    risk: 'medium',
    costTreasury: 300,
    description: 'Передача партии трофейных винтовок и золота партизанам северных лесов для дестабилизации противника.',
    potentialRewards: [
      '-20% боеспособности гарнизонов Норланда',
      '+15% к разведданным о северной границе',
      'Запуск цепной реакции: Расследование контрразведки Норланда'
    ],
    causesHiddenConsequence: {
      title: 'Контрразведка Норланда выходит на след',
      daysDelay: 6,
      intelRequired: 45,
      forecast: 'Служба безопасности Норланда арестует связного на пограничной станции.',
      possibleOutcomeDesc: 'Если не провести эвакуацию агента, Норланд выдвинет ультиматум и мобилизует 3 дивизии.'
    }
  },
  {
    id: 'aerial_recon',
    name: 'Глубокая авиаразведка и радиоперехват',
    specialty: 'signals',
    durationDays: 3,
    risk: 'low',
    costTreasury: 180,
    description: 'Вылет высотных самолетов-разведчиков «Юнкерс» с аэрофотокамерами и станциями прослушки эфира.',
    potentialRewards: [
      '+25% к уровню разведданных о выбранной державе',
      'Раскрытие скрытых последствий и точных дат провокаций',
      'Обнаружение скрытых объектов врага'
    ],
    causesHiddenConsequence: {
      title: 'Аналитический отчет разведбюро',
      daysDelay: 3,
      intelRequired: 20,
      forecast: 'Штаб получит расшифрованные сводки о тайных намерениях противника.',
      possibleOutcomeDesc: 'Автоматическое рассекречивание 1 скрытого последствия в очереди.'
    }
  },
  {
    id: 'counter_intel_sweep',
    name: 'Зачистка столицы и контршпионаж',
    specialty: 'infiltration',
    durationDays: 5,
    risk: 'low',
    costTreasury: 250,
    description: 'Проверка правительственных линий связи, поимка иностранных шпионов и укрепление тыла.',
    potentialRewards: [
      '+15% стабильности государства',
      'Захват вражеского агента и допрос с пристрастием',
      'Защита собственных агентов за рубежом'
    ]
  },
  {
    id: 'steal_blueprints',
    name: 'Кража секретных чертежей вооружения',
    specialty: 'infiltration',
    durationDays: 10,
    risk: 'medium',
    costTreasury: 450,
    description: 'Проникнуть в КБ противника и скопировать формуляры брони или оптических прицелов.',
    potentialRewards: ['+120 очков R&D к текущему исследованию', 'Раскрытие уязвимости брони врага']
  },
  {
    id: 'sabotage_depot',
    name: 'Подрыв узлового склада ГСМ и снарядов',
    specialty: 'sabotage',
    durationDays: 7,
    risk: 'high',
    costTreasury: 350,
    description: 'Минирование железнодорожного депо и цистерн с топливом в тылу вражеского фронта.',
    potentialRewards: ['Лишение врага снабжения (статус Encircled)', '-30% боеспособности дивизий противника']
  },
  {
    id: 'intercept_cables',
    name: 'Подключение к полевому телефонному кабелю',
    specialty: 'signals',
    durationDays: 5,
    risk: 'low',
    costTreasury: 200,
    description: 'Перехват приказов ставки противника и шифрованных радиограмм.',
    potentialRewards: ['+1 улика к скрытым сценариям', 'Точные данные о расположении вражеских ДОТов']
  },
  {
    id: 'bribe_general',
    name: 'Тайная вербовка высшего офицера',
    specialty: 'assassination',
    durationDays: 14,
    risk: 'deadly',
    costTreasury: 900,
    description: 'Подкуп или шантаж командующего сектором для организации саботажа обороны.',
    potentialRewards: ['Вражеская дивизия сдастся без боя', '+25% контроля провинции']
  },
  {
    id: 'spread_panic',
    name: 'Распространение листовок и панических слухов',
    specialty: 'propaganda',
    durationDays: 6,
    risk: 'low',
    costTreasury: 150,
    description: 'Вброс дезинформации о неминуемом окружении и эпидемии в рядах противника.',
    potentialRewards: ['+20% усталости от войны у врага', 'Рост восстания в тылу врага']
  }
];

export const RANDOM_CRISES_POOL: Omit<ActiveCrisisModal, 'id'>[] = [
  {
    title: 'ИНЦИДЕНТ НА ПОГРАНИЧНОЙ ЗАСТАВЕ «ЧЁРНЫЙ МОСТ»',
    stamp: 'CLASSIFIED // FLASH',
    origin: 'Донесение коменданта сектора Корсак',
    severity: 'critical',
    description: 'Неопознанный разведотряд с автоматическими винтовками и без знаков различия атаковал пограничный пост Доминиона, убив 12 пограничников. Разведка подозревает провокацию Норланда либо провокацию мятежных офицеров.',
    options: [
      {
        id: 'opt_retaliate',
        text: 'Нанести массированный артиллерийский удар по приграничным фортам Норланда',
        costDesc: '-400 снарядов, +10% напряженности войны',
        consequenceDesc: 'Повысит боевой дух армии, но спровоцирует мобилизацию противника через 8 дней.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Ответная мобилизация Норланда',
          daysDelay: 8,
          description: 'Норланд перебросил к границе 2 свежие танковые дивизии.',
          severity: 'warning',
          effect: {
            frontlineShiftProvinceId: 'falkenburg',
            frontlineShiftDelta: -15,
            factionLoyaltyDelta: 10
          }
        }
      },
      {
        id: 'opt_coverup',
        text: 'Засекретить инцидент, отправить агентов «Фантом» для тайной ликвидации диверсантов',
        costDesc: '-250 рейхсмарок, риск провала 20%',
        consequenceDesc: 'Сохранит международное перемирие, раскроет следы тайной организации «Black Sun».',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Раскрытие базы Black Sun',
          daysDelay: 5,
          description: 'Агенты захватили полевой дневник офицера ордена «Чёрное Солнце».',
          severity: 'triumph',
          effect: {
            secretScenarioId: 'black_sun',
            secretScenarioClueDelta: 1,
            stabilityDelta: 5
          }
        }
      },
      {
        id: 'opt_propaganda',
        text: 'Опубликовать фотографии в «Штальбургских Ведомостях» как акт агрессии',
        costDesc: '-100 рейхсмарок (печать газеты)',
        consequenceDesc: '+15% к патриотизму и стабильности, +2000 добровольцев в резерв.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Волна добровольцев на фронт',
          daysDelay: 4,
          description: 'На призывные пункты прибыло 2400 новобранцев из провинции Ворн.',
          severity: 'triumph',
          effect: {
            stabilityDelta: 8,
            factionLoyaltyDelta: 5
          }
        }
      }
    ]
  },
  {
    title: 'АВАРИЯ НА УГОЛЬНОЙ ШАХТЕ ИМЕНИ ФОН ШТАЛЯ',
    stamp: 'DOMESTIC CRISIS // URGENT',
    category: 'economy',
    origin: 'Рапорт губернатора Остенмарка',
    severity: 'high',
    description: 'Взрыв метана завалил 400 горняков на ключевом горизонте. Профсоюзы требуют немедленной остановки шахты для спасения людей и выплаты компенсаций, но заводы рискуют остаться без угля для бронепоездов.',
    options: [
      {
        id: 'opt_rescue_all',
        text: 'Бросить все силы МЧС и армии на спасение, выплатить щедрые пособия',
        costDesc: '-600 рейхсмарок, -80 угля/день на неделю',
        consequenceDesc: 'Лояльность рабочих взлетит до максимума, но производство танков замедлится.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Благодарность профсоюзов Остенмарка',
          daysDelay: 7,
          description: 'Горняки установили рекорд добычи после ликвидации завала.',
          severity: 'triumph',
          effect: {
            factionId: 'labor',
            factionLoyaltyDelta: 25,
            stabilityDelta: 10
          }
        }
      },
      {
        id: 'opt_force_work',
        text: 'Ввести комендантский час, принудить смену продолжать добычу на верхних ярусах',
        costDesc: '-25% лояльности рабочих, риск бунта',
        consequenceDesc: 'Сохранит поставки стали для фронта, но вызовет ярость подполья.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Забастовочный комитет Остенмарка',
          daysDelay: 10,
          description: 'Подпольные листовки призывают к саботажу военных эшелонов.',
          severity: 'critical',
          effect: {
            factionId: 'labor',
            factionLoyaltyDelta: -30,
            stabilityDelta: -12
          }
        }
      }
    ]
  },
  {
    title: 'ДЕЗЕРТИРСТВО В ТРАНСПОРТНОМ ДИВИЗИОНЕ',
    stamp: 'MILITARY DISCIPLINE // EYES ONLY',
    category: 'war',
    origin: 'Донесение полевого трибунала 1-й армии',
    severity: 'medium',
    description: 'Эшелон с редкими металлами и дизельным топливом был перенаправлен на заброшенную ветку в Корсаке. Начальник эшелона и 40 солдат перешли на сторону сепаратистов.',
    options: [
      {
        id: 'opt_hunt_down',
        text: 'Выслать карательный отряд бронеавтомобилей и провести показательный трибунал',
        costDesc: '-150 топлива, +15% паранойи офицеров',
        consequenceDesc: 'Груз будет возвращен, но укрепит дисциплину страхом.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Возврат стратегического груза',
          daysDelay: 3,
          description: 'Эшелон с вольфрамом возвращен на заводские пути.',
          severity: 'triumph',
          effect: {
            oilDelta: 20,
            stabilityDelta: -2
          }
        }
      },
      {
        id: 'opt_negotiate',
        text: 'Пообещать амнистию в обмен на выдачу координаторов повстанцев',
        costDesc: '-300 рейхсмарок',
        consequenceDesc: 'Позволит раскрыть сеть снабжения врага без лишнего кровопролития.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Вскрыта явка резидентуры «Фантом»',
          daysDelay: 6,
          description: 'Сдавшийся офицер указал на тайный склад оружия в лесах Корсака.',
          severity: 'triumph',
          effect: {
            secretScenarioId: 'phantom',
            secretScenarioClueDelta: 1,
            factionLoyaltyDelta: 5
          }
        }
      }
    ]
  },
  {
    title: 'ТЕХНОЛОГИЧЕСКИЙ ПРОРЫВ: ПРОЕКТ "ИКАР"',
    stamp: 'SCIENCE & TECH // OPPORTUNITY',
    origin: 'Научный отдел КБ №7',
    severity: 'opportunity',
    category: 'science',
    description: 'Группа молодых инженеров предлагает рискованный проект нового двигателя. Это не кризис, но требует вложений. Успех может дать нам стратегическое преимущество в воздухе.',
    options: [
      {
        id: 'opt_fund_icarus',
        text: 'Профинансировать проект в полном объёме',
        costDesc: '-500 рейхсмарок',
        consequenceDesc: 'Возможное открытие новых технологий или пустая трата средств.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Испытания двигателя "Икар"',
          daysDelay: 8,
          description: 'Новый двигатель превзошел все ожидания. Авиация получила +20% к эффективности.',
          severity: 'triumph',
          effect: {
            militaryReadinessDelta: 15,
            stabilityDelta: 5
          }
        }
      },
      {
        id: 'opt_reject_icarus',
        text: 'Отказать в финансировании, направить ресурсы на текущие нужды фронта',
        costDesc: '+200 стали',
        consequenceDesc: 'Стабильное производство танков, но упущена научная возможность.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Утечка мозгов',
          daysDelay: 15,
          description: 'Разочарованные инженеры тайно покинули страну, передав чертежи противнику.',
          severity: 'warning',
          effect: {
            militaryReadinessDelta: -10,
            stabilityDelta: -5
          }
        }
      }
    ]
  },
  {
    title: 'ПРАЗДНИК УРОЖАЯ В ВОРНЕ',
    stamp: 'SOCIETY // PEACETIME',
    origin: 'Отчет Министерства Внутренних Дел',
    severity: 'event',
    category: 'peacetime',
    description: 'В сельскохозяйственной провинции Ворн собран рекордный урожай. Местный губернатор предлагает организовать масштабный фестиваль для поднятия духа нации.',
    options: [
      {
        id: 'opt_festival',
        text: 'Организовать грандиозный праздник с речью Главнокомандующего',
        costDesc: '-100 рейхсмарок',
        consequenceDesc: 'Значительный рост патриотизма и стабильности, снижение усталости от войны.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Воодушевление масс',
          daysDelay: 2,
          description: 'Кадры с фестиваля облетели всю страну. Народ верит в победу.',
          severity: 'triumph',
          effect: {
            stabilityDelta: 12,
            warWearinessDelta: -8
          }
        }
      },
      {
        id: 'opt_requisition',
        text: 'Никаких праздников. Весь излишек реквизировать для нужд армии',
        costDesc: '+500 продовольствия (условно конвертируется в казну/ресурсы)',
        consequenceDesc: 'Армия будет сыта, но крестьяне могут затаить обиду.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Продовольственные бунты',
          daysDelay: 12,
          description: 'Агрессивная реквизиция привела к стычкам крестьян с жандармерией.',
          severity: 'critical',
          effect: {
            stabilityDelta: -15,
            factionId: 'labor',
            factionLoyaltyDelta: -20
          }
        }
      }
    ]
  },
  {
    title: 'ТАЙНОЕ ПРЕДЛОЖЕНИЕ ПОСЛА ОСТЕНМАРКА',
    stamp: 'DIPLOMACY // CLASSIFIED',
    origin: 'Министерство Иностранных Дел',
    severity: 'opportunity',
    category: 'diplomacy',
    description: 'Посол нейтрального государства тайно предложил поставки дефицитных медикаментов в обмен на чертежи наших новых танков.',
    options: [
      {
        id: 'opt_accept_deal',
        text: 'Согласиться. Медикаменты спасут тысячи солдат',
        costDesc: '- Секретность технологий',
        consequenceDesc: 'Снижение усталости от войны, но противник может узнать наши слабости.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Медикаменты доставлены',
          daysDelay: 5,
          description: 'Госпитали переполнены спасенными солдатами. Усталость от войны падает.',
          severity: 'triumph',
          effect: {
            warWearinessDelta: -15,
            stabilityDelta: 5
          }
        }
      },
      {
        id: 'opt_refuse_deal',
        text: 'Отказаться. Чертежи — государственная тайна',
        costDesc: 'Сохранение секретности',
        consequenceDesc: 'Солдатский ропот из-за нехватки бинтов, но технологии в безопасности.',
        instantEffect: () => {},
        deferredEffect: {
          title: 'Эпидемия в лазаретах',
          daysDelay: 7,
          description: 'Из-за нехватки медикаментов смертность в госпиталях возросла.',
          severity: 'warning',
          effect: {
            warWearinessDelta: 10,
            militaryReadinessDelta: -5
          }
        }
      }
    ]
  }
];
