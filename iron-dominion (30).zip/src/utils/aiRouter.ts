import { generateWithGemini } from "./geminiAI";

export interface AIRequest {
  prompt: string;
  systemInstruction?: string;
  urgency?: 'low' | 'medium' | 'high' | 'critical';
  isKeyMoment?: boolean;
}

export async function routeAIRequest(request: AIRequest) {
  return await generateWithGemini(request.prompt, request.systemInstruction);
}

