import React, { useState } from 'react';
import { RefreshCw, Target, Shield, Activity, Fingerprint, Brain, User, AlertTriangle } from 'lucide-react';

const ranks = ["Генерал-лейтенант", "Генерал-майор", "Фельдмаршал", "Полковник", "Бригадный генерал"];
const firstNames = ["Клаус", "Эрих", "Иоганн", "Вильгельм", "Альберт", "Густав", "Генрих", "Карл"];
const lastNames = ["фон Берг", "Шталь", "Крюгер", "Мюллер", "Риттер", "Вайс", "Шварц", "Фогель"];

const positiveTraits = [
  "Гений танковых прорывов",
  "Мастер логистики",
  "Вдохновляющий оратор",
  "Символ нации",
  "Неутомимый",
  "Тактик старой школы"
];

const negativeTraits = [
  "Тайный морфинист",
  "Ненавидит диктатора",
  "Страдает от ПТСР",
  "Хронический алкоголизм",
  "Излишне амбициозен",
  "Игнорирует приказы Генштаба"
];

const quotes = [
  "Солдаты — это уголь в топке победы. Подбрасывайте больше.",
  "Я выиграю эту войну, если эти идиоты в штабе мне не помешают.",
  "Наступление должно развиваться быстрее, чем враг успевает пугаться.",
  "Честь? Честь оставим историкам. Нам нужна территория.",
  "Логистика решает, кто умрёт с полным желудком, а кто с пустым."
];

export default function CommanderGenerator() {
  const [commander, setCommander] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generate = () => {
    setIsGenerating(true);
    setCommander(null);

    setTimeout(() => {
      const rank = ranks[Math.floor(Math.random() * ranks.length)];
      const first = firstNames[Math.floor(Math.random() * firstNames.length)];
      const last = lastNames[Math.floor(Math.random() * lastNames.length)];
      
      const pTrait = positiveTraits[Math.floor(Math.random() * positiveTraits.length)];
      const nTrait = negativeTraits[Math.floor(Math.random() * negativeTraits.length)];
      
      const q = quotes[Math.floor(Math.random() * quotes.length)];

      setCommander({
        name: `${rank} ${first} ${last}`,
        age: Math.floor(Math.random() * 30) + 35,
        stats: {
          offense: Math.floor(Math.random() * 6) + 5, // 5-10
          defense: Math.floor(Math.random() * 7) + 3, // 3-9
          logistics: Math.floor(Math.random() * 8) + 2, // 2-9
          loyalty: Math.floor(Math.random() * 10) + 1, // 1-10
        },
        traits: [
          { name: pTrait, type: 'positive' },
          { name: nTrait, type: 'negative' }
        ],
        quote: q,
        id: Math.random().toString(36).substr(2, 9).toUpperCase()
      });
      setIsGenerating(false);
    }, 800);
  };

  return (
    <div className="w-full flex flex-col items-center">
      <button 
        onClick={generate}
        disabled={isGenerating}
        className="mb-8 flex items-center gap-3 border-2 border-ink bg-paper px-6 py-3 font-mono text-sm uppercase tracking-widest text-ink hover:bg-ink hover:text-paper-light transition-colors disabled:opacity-50 disabled:cursor-not-allowed group shadow-[4px_4px_0_var(--color-ink)] active:shadow-none active:translate-x-1 active:translate-y-1"
      >
        <RefreshCw className={`w-4 h-4 ${isGenerating ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}`} />
        {isGenerating ? 'Извлечение данных...' : 'Запросить досье из архива'}
      </button>

      {isGenerating && (
        <div className="w-full max-w-2xl border-2 border-ink/20 border-dashed p-12 flex flex-col items-center justify-center text-ink/40 font-mono">
          <Fingerprint className="w-12 h-12 animate-pulse mb-4 opacity-50" />
          <div className="uppercase tracking-widest">Поиск по базе данных контрразведки...</div>
        </div>
      )}

      {commander && !isGenerating && (
        <div className="w-full max-w-2xl border-2 border-ink bg-paper-light p-6 md:p-8 relative animate-in fade-in zoom-in-95 duration-500 drop-shadow-md">
          {/* Decorative corners */}
          <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-ink/40" />
          <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-ink/40" />
          <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-ink/40" />
          <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-ink/40" />

          {/* Stamp */}
          <div className="absolute top-4 right-8 transform rotate-12 border-4 border-stamp text-stamp px-3 py-1 font-mono text-xl font-bold tracking-widest opacity-80 mix-blend-multiply pointer-events-none z-10">
            CONFIDENTIAL
          </div>

          <div className="flex flex-col md:flex-row gap-8">
            {/* Left Col: Photo & Basics */}
            <div className="flex flex-col items-center gap-4 w-full md:w-48 shrink-0">
              <div className="w-full aspect-[3/4] border-2 border-ink flex items-center justify-center bg-paper relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjgiPgo8cmVjdCB3aWR0aD0iOCIgaGVpZ2h0PSI4IiBmaWxsPSIjZWFkZGNmIj48L3JlY3Q+CjxwYXRoIGQ9Ik0wIDBMOCA4Wk04IDBMMCA4WiIgc3Ryb2tlPSIjMjIyMiIgc3Ryb2tlLXdpZHRoPSIxIiBzdHJva2Utb3BhY2l0eT0iMC4xIj48L3BhdGg+Cjwvc3ZnPg==')] opacity-50" />
                <User className="w-24 h-24 text-ink/20" />
                <div className="absolute bottom-0 left-0 w-full bg-ink text-paper-light text-center font-mono text-xs py-1">
                  ID: {commander.id}
                </div>
              </div>
              
              <div className="w-full text-center font-mono text-sm border-y border-ink/20 py-2">
                <div className="text-ink/60 text-[10px] uppercase">Возраст</div>
                <div className="font-bold">{commander.age} лет</div>
              </div>
            </div>

            {/* Right Col: Details */}
            <div className="flex-1 flex flex-col">
              <div className="border-b-2 border-ink pb-4 mb-4 pr-8">
                <h3 className="font-serif text-3xl font-bold leading-tight uppercase text-ink">
                  {commander.name.split(' ').slice(1).join(' ')}
                </h3>
                <div className="font-mono text-sm tracking-widest text-ink-light uppercase mt-1">
                  {commander.name.split(' ')[0]}
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-x-6 gap-y-4 mb-6">
                <StatBar icon={Target} label="Наступление" value={commander.stats.offense} />
                <StatBar icon={Shield} label="Оборона" value={commander.stats.defense} />
                <StatBar icon={Brain} label="Логистика" value={commander.stats.logistics} />
                <StatBar icon={Activity} label="Лояльность" value={commander.stats.loyalty} color={commander.stats.loyalty < 4 ? 'bg-blood' : 'bg-ink'} />
              </div>

              {/* Traits */}
              <div className="mb-6 flex-1">
                <div className="font-mono text-[10px] uppercase text-ink/50 mb-2">Психологический профиль</div>
                <div className="flex flex-wrap gap-2">
                  {commander.traits.map((trait: any, i: number) => (
                    <div 
                      key={i} 
                      className={`font-mono text-xs px-2 py-1 border flex items-center gap-1.5
                        ${trait.type === 'positive' ? 'border-ink/30 bg-ink/5 text-ink' : 'border-blood/50 bg-blood/10 text-blood'}`}
                    >
                      {trait.type === 'negative' && <AlertTriangle className="w-3 h-3" />}
                      {trait.name}
                    </div>
                  ))}
                </div>
              </div>

              {/* Quote */}
              <div className="bg-paper p-3 border-l-4 border-ink/30 relative">
                <div className="absolute -top-3 -left-2 text-4xl text-ink/20 font-serif">"</div>
                <p className="font-serif italic text-ink-light leading-relaxed pl-2 relative z-10 text-sm">
                  {commander.quote}
                </p>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatBar({ icon: Icon, label, value, color = "bg-ink" }: any) {
  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center justify-between font-mono text-[10px] uppercase text-ink/70">
        <span className="flex items-center gap-1.5"><Icon className="w-3 h-3" /> {label}</span>
        <span className="font-bold text-ink">{value}/10</span>
      </div>
      <div className="w-full h-1.5 bg-ink/10 flex">
        {[...Array(10)].map((_, i) => (
          <div 
            key={i} 
            className={`flex-1 border-r border-paper-light last:border-0 ${i < value ? color : 'bg-transparent'}`} 
          />
        ))}
      </div>
    </div>
  );
}
