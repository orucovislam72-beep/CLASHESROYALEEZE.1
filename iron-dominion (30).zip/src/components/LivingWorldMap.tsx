import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { Activity, Users, Flame, Database, ShieldAlert, Sparkles, AlertCircle } from 'lucide-react';

export interface RegionFeature {
  type: "Feature";
  id: string;
  properties: {
    name: string;
    pop: string;
    needs: string[];
    memory: string;
    unrest: number;
    loyalty: "Высокая" | "Средняя" | "Низкая" | "Враждебная";
  };
  geometry: {
    type: "Polygon";
    coordinates: number[][][];
  };
}

const initialGeoData: { type: "FeatureCollection"; features: RegionFeature[] } = {
  type: "FeatureCollection",
  features: [
    {
      type: "Feature",
      id: "ostenmark",
      properties: { name: "Остенмарк", pop: "4.2M", needs: ["Уголь", "Машинерия"], memory: "Кровавое подавление шахтёрских бунтов (1923).", unrest: 78, loyalty: "Низкая" },
      geometry: { type: "Polygon", coordinates: [[[10, 20], [30, 10], [45, 25], [40, 45], [15, 50], [10, 20]]] }
    },
    {
      type: "Feature",
      id: "vorn",
      properties: { name: "Ворн", pop: "1.8M", needs: ["Зерно", "Древесина"], memory: "Абсолютная лояльность. Центр пропаганды.", unrest: 15, loyalty: "Высокая" },
      geometry: { type: "Polygon", coordinates: [[[30, 10], [70, 5], [85, 20], [75, 40], [45, 25], [30, 10]]] }
    },
    {
      type: "Feature",
      id: "korsak",
      properties: { name: "Корсак", pop: "2.1M", needs: ["Оружие", "Медикаменты"], memory: "Партизанская война продолжается в лесах.", unrest: 92, loyalty: "Враждебная" },
      geometry: { type: "Polygon", coordinates: [[[75, 40], [95, 35], [90, 70], [65, 60], [45, 25], [75, 40]]] }
    },
    {
      type: "Feature",
      id: "aethelgard",
      properties: { name: "Этельгард", pop: "6.5M", needs: ["Нефть", "Сталь"], memory: "Экономический коллапс разрушил веру в элиты.", unrest: 45, loyalty: "Средняя" },
      geometry: { type: "Polygon", coordinates: [[[15, 50], [40, 45], [65, 60], [50, 85], [20, 80], [15, 50]]] }
    }
  ]
};

const cities = [
  { name: "Штальбург", coords: [25, 30] },
  { name: "Ной-Ворн", coords: [60, 20] },
  { name: "Лесной Стан", coords: [80, 50] },
  { name: "Этель", coords: [35, 65] }
];

interface LivingWorldMapProps {
  onRegionClick?: (region: RegionFeature['properties']) => void;
  activeEventRegion?: string | null;
}

export default function LivingWorldMap({ onRegionClick, activeEventRegion }: LivingWorldMapProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [geoData, setGeoData] = useState(initialGeoData);
  const [selectedRegionId, setSelectedRegionId] = useState<string>("ostenmark");
  const [hovered, setHovered] = useState<RegionFeature['properties'] | null>(null);

  // Helper color based on unrest
  const getRegionFill = (unrest: number, isEventActive: boolean) => {
    if (isEventActive) return "url(#alertHatch)";
    if (unrest > 75) return "rgba(140, 38, 38, 0.18)";
    if (unrest > 40) return "rgba(217, 119, 6, 0.10)";
    return "rgba(16, 185, 129, 0.08)";
  };

  const getRegionStroke = (unrest: number, isEventActive: boolean) => {
    if (isEventActive) return "var(--color-blood)";
    if (unrest > 75) return "var(--color-blood)";
    if (unrest > 40) return "#b45309";
    return "#047857";
  };

  useEffect(() => {
    if (!svgRef.current || !wrapperRef.current) return;

    const { width, height } = wrapperRef.current.getBoundingClientRect();
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    // Definitions for map patterns & glow filters
    const defs = svg.append("defs");
    
    // Normal hatch pattern
    const pattern = defs.append("pattern")
      .attr("id", "diagonalHatch")
      .attr("patternUnits", "userSpaceOnUse")
      .attr("width", 8)
      .attr("height", 8);
    pattern.append("path")
      .attr("d", "M-2,2 l4,-4 M0,8 l8,-8 M6,10 l4,-4")
      .attr("stroke", "var(--color-blood)")
      .attr("stroke-width", 1.2)
      .attr("opacity", 0.6);

    // Active Alert Hatch Pattern (animated style)
    const alertPattern = defs.append("pattern")
      .attr("id", "alertHatch")
      .attr("patternUnits", "userSpaceOnUse")
      .attr("width", 6)
      .attr("height", 6);
    alertPattern.append("path")
      .attr("d", "M0,0 l6,6 M6,0 l-6,6")
      .attr("stroke", "var(--color-blood)")
      .attr("stroke-width", 1.5)
      .attr("opacity", 0.7);

    const projection = d3.geoIdentity()
      .reflectY(false)
      .fitSize([width, height], geoData as unknown as d3.GeoGeometryObjects);

    const pathGenerator = d3.geoPath().projection(projection);

    const mapGroup = svg.append("g");

    // Draw Regions with smooth D3 Transitions
    const paths = mapGroup.selectAll<SVGPathElement, RegionFeature>("path.province")
      .data(geoData.features, (d: any) => d?.id)
      .join(
        enter => enter.append("path")
          .attr("class", "province cursor-crosshair")
          .attr("d", (d: RegionFeature) => pathGenerator(d as any) || "")
          .attr("fill", (d: RegionFeature) => getRegionFill(d.properties.unrest, d.properties.name === activeEventRegion))
          .attr("stroke", (d: RegionFeature) => getRegionStroke(d.properties.unrest, d.properties.name === activeEventRegion))
          .attr("stroke-width", (d: RegionFeature) => d.properties.name === activeEventRegion ? 2.5 : 1.5)
          .attr("stroke-dasharray", (d: RegionFeature) => d.properties.name === activeEventRegion ? "none" : (d.properties.unrest > 70 ? "4 2" : "none"))
          .style("opacity", 0)
          .call(enter => enter.transition().duration(600).style("opacity", 1)),
        update => update.call(update => update.transition().duration(500)
          .attr("fill", (d: RegionFeature) => getRegionFill(d.properties.unrest, d.properties.name === activeEventRegion))
          .attr("stroke", (d: RegionFeature) => getRegionStroke(d.properties.unrest, d.properties.name === activeEventRegion))
          .attr("stroke-width", (d: RegionFeature) => d.properties.name === activeEventRegion ? 3 : 1.5)
        )
      );

    paths
      .on("mouseenter", function(event: any, d: RegionFeature) {
        d3.select(this)
          .transition()
          .duration(200)
          .attr("fill", "url(#diagonalHatch)")
          .attr("stroke", "var(--color-blood)")
          .attr("stroke-width", 2.5);
        setHovered(d.properties);
      })
      .on("mouseleave", function(event: any, d: RegionFeature) {
        d3.select(this)
          .transition()
          .duration(300)
          .attr("fill", getRegionFill(d.properties.unrest, d.properties.name === activeEventRegion))
          .attr("stroke", getRegionStroke(d.properties.unrest, d.properties.name === activeEventRegion))
          .attr("stroke-width", d.properties.name === activeEventRegion ? 3 : 1.5);
        setHovered(null);
      })
      .on("click", function(event: any, d: RegionFeature) {
        setSelectedRegionId(d.id);
        if (onRegionClick) onRegionClick(d.properties);
      });

    // Draw Cities & Pulse
    cities.forEach(city => {
      const coords = projection(city.coords as [number, number]);
      if (!coords) return;

      // Pulse wave for cities in alert regions
      const isAlertCity = (city.name === "Штальбург" && activeEventRegion === "Остенмарк") ||
                          (city.name === "Лесной Стан" && activeEventRegion === "Корсак");

      if (isAlertCity) {
        mapGroup.append("circle")
          .attr("cx", coords[0])
          .attr("cy", coords[1])
          .attr("r", 8)
          .attr("fill", "none")
          .attr("stroke", "var(--color-blood)")
          .attr("stroke-width", 1.5)
          .style("opacity", 0.8)
          .transition()
          .duration(1200)
          .ease(d3.easeLinear)
          .attr("r", 22)
          .style("opacity", 0);
      }

      mapGroup.append("circle")
        .attr("cx", coords[0])
        .attr("cy", coords[1])
        .attr("r", isAlertCity ? 5 : 4)
        .attr("fill", isAlertCity ? "var(--color-blood)" : "var(--color-ink)")
        .attr("stroke", "var(--color-paper)")
        .attr("stroke-width", 1);

      mapGroup.append("text")
        .attr("x", coords[0] + 8)
        .attr("y", coords[1] + 4)
        .text(city.name)
        .attr("font-family", "var(--font-mono)")
        .attr("font-size", "11px")
        .attr("fill", isAlertCity ? "var(--color-blood)" : "var(--color-ink)")
        .attr("font-weight", "bold");
    });

  }, [geoData, activeEventRegion]);

  // Handle manual player interventions (e.g. Quell unrest / Boost propaganda)
  const handleModifyLoyalty = (regionId: string, unrestDelta: number) => {
    setGeoData(prev => ({
      ...prev,
      features: prev.features.map(f => {
        if (f.id === regionId) {
          const newUnrest = Math.max(5, Math.min(98, f.properties.unrest + unrestDelta));
          let newLoyalty: RegionFeature['properties']['loyalty'] = "Средняя";
          if (newUnrest <= 25) newLoyalty = "Высокая";
          else if (newUnrest <= 55) newLoyalty = "Средняя";
          else if (newUnrest <= 80) newLoyalty = "Низкая";
          else newLoyalty = "Враждебная";

          return {
            ...f,
            properties: {
              ...f.properties,
              unrest: newUnrest,
              loyalty: newLoyalty
            }
          };
        }
        return f;
      })
    }));
  };

  const currentDisplayRegion = hovered || geoData.features.find(f => f.id === selectedRegionId)?.properties || geoData.features[0].properties;
  const currentFeatureId = geoData.features.find(f => f.properties.name === currentDisplayRegion.name)?.id || "ostenmark";

  return (
    <div className="flex flex-col md:flex-row gap-6 w-full min-h-[350px] bg-paper/50 border border-ink/20 p-4 relative">
      
      {/* Top Banner with dynamic indicator */}
      <div className="absolute top-2 left-2 text-[10px] font-mono text-ink/60 uppercase flex items-center gap-2">
        <span>ТОПОГРАФИЧЕСКАЯ РАЗВЕДКА // D3 REALTIME MONITOR</span>
        {activeEventRegion && (
          <span className="bg-blood text-paper-light px-1.5 py-0.2 animate-pulse text-[9px] font-bold">
            ТРЕВОГА: {activeEventRegion}
          </span>
        )}
      </div>

      {/* Map SVG Area */}
      <div className="flex-1 min-h-[260px] md:min-h-[320px] relative mt-5 md:mt-0" ref={wrapperRef}>
        <svg ref={svgRef} className="w-full h-full drop-shadow-sm" />
      </div>

      {/* Dossier Side Panel */}
      <div className="w-full md:w-72 border-t md:border-t-0 md:border-l border-ink/20 pt-4 md:pt-0 md:pl-5 flex flex-col justify-between">
        <div className="animate-in fade-in slide-in-from-right-3 duration-200">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${currentDisplayRegion.name === activeEventRegion ? 'bg-blood animate-ping' : (currentDisplayRegion.unrest > 60 ? 'bg-blood' : 'bg-emerald-600')}`} />
              <span className="font-mono text-[11px] uppercase tracking-wider font-bold text-ink/80">
                {currentDisplayRegion.name === activeEventRegion ? 'АКТИВНЫЙ ИНЦИДЕНТ' : `ЛОЯЛЬНОСТЬ: ${currentDisplayRegion.loyalty}`}
              </span>
            </div>
            <span className="font-mono text-[10px] text-ink/40">ID: {currentFeatureId}</span>
          </div>

          <h4 className="font-serif font-bold text-2xl mb-3 text-ink uppercase border-b-2 border-ink pb-1 flex items-center justify-between">
            <span>{currentDisplayRegion.name}</span>
            {currentDisplayRegion.unrest > 70 && <ShieldAlert className="w-5 h-5 text-blood" />}
          </h4>
          
          <div className="space-y-3 font-mono text-sm text-ink-light">
            <div className="flex items-start gap-2.5">
              <Users className="w-4 h-4 mt-0.5 shrink-0" />
              <div>
                <div className="uppercase text-[9px] text-ink/50">Население</div>
                <div className="font-bold text-ink text-xs">{currentDisplayRegion.pop}</div>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Database className="w-4 h-4 mt-0.5 shrink-0" />
              <div>
                <div className="uppercase text-[9px] text-ink/50">Дефицит ресурсов</div>
                <div className="text-ink text-xs">{currentDisplayRegion.needs.join(', ')}</div>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <Flame className="w-4 h-4 mt-0.5 shrink-0 text-blood" />
              <div className="w-full">
                <div className="uppercase text-[9px] text-ink/50 flex justify-between">
                  <span>Уровень недовольства</span>
                  <span className={`font-bold ${currentDisplayRegion.unrest > 60 ? 'text-blood' : 'text-emerald-700'}`}>
                    {currentDisplayRegion.unrest}%
                  </span>
                </div>
                <div className="w-full h-1.5 bg-ink/10 mt-1">
                  <div 
                    className={`h-full transition-all duration-500 ${currentDisplayRegion.unrest > 60 ? 'bg-blood' : 'bg-emerald-600'}`}
                    style={{ width: `${currentDisplayRegion.unrest}%` }}
                  />
                </div>
              </div>
            </div>

            <div className="flex items-start gap-2.5 pt-2 border-t border-ink/10">
              <Activity className="w-4 h-4 mt-0.5 shrink-0" />
              <div>
                <div className="uppercase text-[9px] text-ink/50">Память региона</div>
                <div className="text-[11px] leading-snug mt-0.5 italic text-ink/90">
                  "{currentDisplayRegion.memory}"
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Strategic Orders for the Region */}
        <div className="mt-4 pt-3 border-t border-ink/15 flex flex-col gap-1.5">
          <div className="font-mono text-[9px] uppercase text-ink/50">Приказы Генштаба (D3 Simulation):</div>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              onClick={() => handleModifyLoyalty(currentFeatureId, -15)}
              className="px-2 py-1 bg-paper border border-ink/40 text-[10px] font-mono uppercase hover:bg-ink hover:text-paper-light transition-colors flex items-center justify-center gap-1"
              title="Отправить гуманитарный конвой / пропаганду"
            >
              <Sparkles className="w-3 h-3 text-emerald-600" />
              <span>Умиротворить (-15%)</span>
            </button>
            <button
              onClick={() => handleModifyLoyalty(currentFeatureId, +20)}
              className="px-2 py-1 bg-paper border border-blood/50 text-[10px] font-mono uppercase text-blood hover:bg-blood hover:text-paper-light transition-colors flex items-center justify-center gap-1"
              title="Реквизировать продовольствие / ввести комендантский час"
            >
              <AlertCircle className="w-3 h-3" />
              <span>Реквизиция (+20%)</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
