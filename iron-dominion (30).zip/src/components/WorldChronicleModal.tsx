import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  FileText, X, Search, Filter, Download, Copy, Check,
  Swords, ShieldAlert, Coins, Eye, Sparkles, BookOpen,
  Calendar, Layers, ArrowUpRight, GitFork, Clock, AlertTriangle,
  HelpCircle, ShieldCheck, ChevronRight
} from 'lucide-react';
import { ChronicleEntry, GameState, CausalNode } from '../utils/gameState';
import { gameStore } from '../utils/gameStore';
import { audioEngine } from '../utils/audioEngine';

interface WorldChronicleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function WorldChronicleModal({ isOpen, onClose }: WorldChronicleModalProps) {
  const [state, setState] = useState<GameState>(gameStore.getState());
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'chronicle' | 'causal_tree'>('chronicle');
  const [selectedCausalNodeId, setSelectedCausalNodeId] = useState<string | null>(null);

  React.useEffect(() => {
    return gameStore.subscribe(setState);
  }, []);

  if (!isOpen) return null;

  const filteredEntries = state.chronicle.filter(entry => {
    const matchesFilter = selectedFilter === 'all' || entry.category === selectedFilter;
    const matchesSearch = searchQuery === '' || 
      entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.timestamp.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getCategoryIcon = (category: ChronicleEntry['category']) => {
    switch (category) {
      case 'war': return <Swords className="w-3.5 h-3.5 text-red-500" />;
      case 'politics': return <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />;
      case 'economy': return <Coins className="w-3.5 h-3.5 text-yellow-600" />;
      case 'espionage': return <Eye className="w-3.5 h-3.5 text-blue-500" />;
      case 'secret': return <Sparkles className="w-3.5 h-3.5 text-purple-500" />;
      case 'tech': return <BookOpen className="w-3.5 h-3.5 text-emerald-600" />;
      default: return <FileText className="w-3.5 h-3.5 text-paper-dark" />;
    }
  };

  const handleCopyChronicle = () => {
    const textReport = state.chronicle.map(e => 
      `[${e.timestamp}] [${e.category.toUpperCase()}] ${e.title}\n${e.details}\n${e.badge ? `(ШТАМП: ${e.badge})\n` : ''}----------------------------------------`
    ).join('\n');

    navigator.clipboard.writeText(`АРХИВ ХРОНИКИ КАМПАНИИ IRON DOMINION\nВсего дней: ${state.totalDaysElapsed}\nПотери коалиции: ${state.warSummary.alliedCasualties} чел. | Потери врага: ${state.warSummary.enemyCasualties} чел.\n\n${textReport}`);
    setCopied(true);
    audioEngine.playStamp();
    setTimeout(() => setCopied(false), 3000);
  };

  const causalNodes = state.causalGraph || [];
  const selectedNode = causalNodes.find(n => n.id === selectedCausalNodeId) || causalNodes[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-ink/80 backdrop-blur-xs font-serif">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ duration: 0.25 }}
        className="w-full max-w-5xl max-h-[92vh] bg-[#f2ebd9] text-ink border-4 border-ink shadow-2xl flex flex-col relative overflow-hidden"
      >
        {/* Top Classified Archival Header */}
        <div className="bg-ink text-paper-light p-3 sm:p-4 flex items-center justify-between border-b-2 border-blood">
          <div className="flex items-center gap-3">
            <FileText className="w-5 h-5 text-amber-300" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-mono tracking-widest text-amber-300 font-bold">
                  ГОСУДАРСТВЕННЫЙ АРХИВ // СИМУЛЯЦИЯ «МИР ПОМНИТ»
                </span>
                <span className="px-1.5 py-0.5 bg-blood text-paper-light text-[9px] font-mono uppercase font-bold">
                  CAUSALITY ENGINE
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-bold font-serif tracking-tight text-paper-light">
                Журнал Истории Мира & Древо Причинно-Следственных Связей
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyChronicle}
              className="px-2.5 py-1 bg-paper/20 hover:bg-paper/30 text-paper-light text-xs font-mono flex items-center gap-1.5 border border-paper/30 transition-all"
              title="Скопировать текстовую хронику кампании в буфер обмена"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-300" />}
              <span className="hidden sm:inline">{copied ? 'Скопировано!' : 'Экспорт текста'}</span>
            </button>

            <button
              onClick={() => {
                audioEngine.playClick('switch');
                onClose();
              }}
              className="p-1.5 bg-paper/10 hover:bg-paper/20 text-paper-light border border-paper/30 transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* View Mode Tabs Ribbon */}
        <div className="bg-[#e8dfc8] border-b border-ink/20 p-2 sm:px-4 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                audioEngine.playClick('switch');
                setViewMode('chronicle');
              }}
              className={`px-3 py-1 text-xs font-bold uppercase flex items-center gap-1.5 border transition-all ${
                viewMode === 'chronicle'
                  ? 'bg-ink text-paper-light border-ink'
                  : 'bg-paper/40 hover:bg-paper/70 text-ink border-ink/20'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Летопись Событий ({state.chronicle.length})</span>
            </button>

            <button
              onClick={() => {
                audioEngine.playClick('switch');
                setViewMode('causal_tree');
              }}
              className={`px-3 py-1 text-xs font-bold uppercase flex items-center gap-1.5 border transition-all ${
                viewMode === 'causal_tree'
                  ? 'bg-ink text-paper-light border-ink'
                  : 'bg-paper/40 hover:bg-paper/70 text-ink border-ink/20'
              }`}
            >
              <GitFork className="w-3.5 h-3.5" />
              <span>Древо Причин и Следствий ({causalNodes.length})</span>
            </button>
          </div>

          <div className="flex items-center gap-4 text-ink/80 text-[11px]">
            <div>Дней: <strong className="text-ink">{state.totalDaysElapsed}</strong></div>
            <div>Потери коалиции: <strong className="text-red-700">{state.warSummary.alliedCasualties}</strong></div>
            <div>Потери врага: <strong className="text-emerald-800">{state.warSummary.enemyCasualties}</strong></div>
          </div>
        </div>

        {/* View 1: Standard Chronicle Ledger */}
        {viewMode === 'chronicle' && (
          <>
            {/* Filter & Search Bar */}
            <div className="p-3 bg-[#ebe2ce] border-b border-ink/15 flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-1 text-xs font-mono">
                {[
                  { id: 'all', label: 'Все записи' },
                  { id: 'war', label: 'Война' },
                  { id: 'politics', label: 'Политика' },
                  { id: 'economy', label: 'Экономика' },
                  { id: 'espionage', label: 'Шпионаж' },
                  { id: 'secret', label: 'Секретно' },
                  { id: 'tech', label: 'НИОКР' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      audioEngine.playClick('switch');
                      setSelectedFilter(tab.id);
                    }}
                    className={`px-2.5 py-1 border text-[11px] font-bold uppercase transition-all ${
                      selectedFilter === tab.id
                        ? 'bg-ink text-paper-light border-ink shadow-xs'
                        : 'bg-paper/40 hover:bg-paper/70 text-ink border-ink/20'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="relative flex items-center min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-ink/50 absolute left-2.5 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Поиск по хронике..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1 bg-white/70 border border-ink/30 text-xs font-mono text-ink placeholder:text-ink/40 focus:outline-none focus:border-blood"
                />
              </div>
            </div>

            {/* Chronicle Timeline Ledger Entries */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 font-serif">
              {filteredEntries.length === 0 ? (
                <div className="text-center py-12 text-ink/50 italic">
                  Нет записей, соответствующих выбранным критериям поиска.
                </div>
              ) : (
                filteredEntries.map((entry, idx) => (
                  <motion.div
                    key={entry.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: idx * 0.03 }}
                    className="relative pl-6 sm:pl-8 border-l-2 border-ink/30 hover:border-blood transition-all group"
                  >
                    <div className="absolute -left-[9px] top-1.5 w-4 h-4 rounded-full bg-[#f2ebd9] border-2 border-ink group-hover:border-blood group-hover:bg-blood flex items-center justify-center transition-all">
                      <div className="w-1.5 h-1.5 rounded-full bg-ink group-hover:bg-paper-light" />
                    </div>

                    <div className="bg-[#faf5e8] p-3.5 sm:p-4 border border-ink/20 shadow-xs group-hover:shadow-md transition-all">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                        <div className="flex items-center gap-2">
                          <div className="p-1 bg-ink/5 border border-ink/10 rounded-none">
                            {getCategoryIcon(entry.category)}
                          </div>
                          <span className="font-mono text-xs font-bold text-blood tracking-wider">
                            {entry.timestamp}
                          </span>
                          <span className="font-mono text-[10px] text-ink/50">
                            // ДЕНЬ {entry.dayCount}
                          </span>
                        </div>

                        {entry.badge && (
                          <span 
                            className="px-2 py-0.5 text-[9px] font-mono uppercase font-bold border"
                            style={{ 
                              borderColor: entry.impactColor || '#1f2937', 
                              color: entry.impactColor || '#1f2937',
                              backgroundColor: 'rgba(0,0,0,0.03)'
                            }}
                          >
                            {entry.badge}
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-bold text-ink mb-1 group-hover:text-blood transition-colors">
                        {entry.title}
                      </h3>

                      <p className="text-sm leading-relaxed text-ink/85 italic font-serif">
                        {entry.details}
                      </p>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </>
        )}

        {/* View 2: Causality Graph & Ripple Network Visualizer */}
        {viewMode === 'causal_tree' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-5 font-mono">
            
            {/* Left: Causal Nodes List (6 cols) */}
            <div className="lg:col-span-6 space-y-3">
              <div className="border-b border-ink/20 pb-2 flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-blood tracking-wider">
                  ЦЕПОЧКИ РЕШЕНИЙ И ПОСЛЕДСТВИЙ ({causalNodes.length})
                </span>
                <span className="text-[10px] text-ink/60">
                  СИМУЛЯЦИЯ «МИР ПОМНИТ»
                </span>
              </div>

              {causalNodes.length === 0 ? (
                <div className="p-6 text-center text-ink/50 italic font-serif">
                  Пока не совершено ключевых действий с долгосрочным эхом.
                </div>
              ) : (
                causalNodes.map((node) => {
                  const isSelected = selectedNode?.id === node.id;
                  return (
                    <div
                      key={node.id}
                      onClick={() => {
                        audioEngine.playClick('switch');
                        setSelectedCausalNodeId(node.id);
                      }}
                      className={`p-3.5 border-2 cursor-pointer transition-all ${
                        isSelected 
                          ? 'bg-[#faf3e3] border-blood shadow-md' 
                          : 'bg-[#faf5e8]/80 hover:bg-[#faf5e8] border-ink/20'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1.5">
                        <div className="flex items-center gap-2">
                          <GitFork className="w-3.5 h-3.5 text-blood shrink-0" />
                          <span className="text-xs font-bold text-ink truncate max-w-[200px]">
                            {node.originAction}
                          </span>
                        </div>

                        {node.status === 'pending' ? (
                          <span className="px-1.5 py-0.5 bg-amber-200 text-amber-900 border border-amber-500 text-[9px] font-bold flex items-center gap-1">
                            <Clock className="w-2.5 h-2.5" /> {node.daysRemaining} дн. до срабатывания
                          </span>
                        ) : node.status === 'triggered' ? (
                          <span className="px-1.5 py-0.5 bg-red-200 text-red-900 border border-red-500 text-[9px] font-bold flex items-center gap-1">
                            <AlertTriangle className="w-2.5 h-2.5" /> СРАБОТАЛО
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 bg-emerald-200 text-emerald-900 border border-emerald-500 text-[9px] font-bold flex items-center gap-1">
                            <ShieldCheck className="w-2.5 h-2.5" /> УРЕГУЛИРОВАНО
                          </span>
                        )}
                      </div>

                      <div className="text-[11px] text-ink/70 font-serif line-clamp-2 mb-2">
                        {node.forecastHint || 'Эхо принятого решения зреет в кулуарах европейской дипломатии.'}
                      </div>

                      <div className="flex items-center justify-between text-[10px] text-ink/50 pt-1 border-t border-ink/10">
                        <span>Начало: День {node.originDay}</span>
                        <span>Триггер: День {node.triggerDay}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Right: Detailed Node Inspector (6 cols) */}
            <div className="lg:col-span-6 bg-[#faf5e8] border-2 border-ink/30 p-4 sm:p-5 flex flex-col justify-between">
              {selectedNode ? (
                <div className="space-y-4">
                  <div className="border-b border-ink/20 pb-2">
                    <div className="flex items-center gap-2 text-[10px] text-blood uppercase font-bold mb-1">
                      <span>ДОСЬЕ ПРИЧИННО-СЛЕДСТВЕННОГО УЗЛА</span>
                      <span>// ID: {selectedNode.id}</span>
                    </div>
                    <h3 className="text-base font-bold font-serif text-ink">
                      {selectedNode.originAction}
                    </h3>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-ink/10">
                      <span className="text-ink/60">Дата принятия решения:</span>
                      <strong className="text-ink">День {selectedNode.originDay}</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-ink/10">
                      <span className="text-ink/60">Срок проявления последствий:</span>
                      <strong className="text-blood">День {selectedNode.triggerDay} ({selectedNode.daysRemaining > 0 ? `Осталось ${selectedNode.daysRemaining} дн.` : 'Истек'})</strong>
                    </div>
                    <div className="flex justify-between py-1 border-b border-ink/10">
                      <span className="text-ink/60">Степень влияния на мир:</span>
                      <span className="font-bold uppercase text-amber-800">{selectedNode.severity}</span>
                    </div>
                    {selectedNode.decisionChoiceTaken && (
                      <div className="py-1 border-b border-ink/10">
                        <span className="text-ink/60 block mb-0.5">Принятая резолюция игрока:</span>
                        <div className="p-2 bg-paper/30 border border-ink/15 italic font-serif text-ink">
                          «{selectedNode.decisionChoiceTaken}»
                        </div>
                      </div>
                    )}
                    {selectedNode.resultingEventTitle && (
                      <div className="py-1 border-b border-ink/10">
                        <span className="text-ink/60 block mb-0.5">Порожденное мировое событие:</span>
                        <div className="p-2 bg-red-100 border border-red-300 font-bold text-red-900">
                          {selectedNode.resultingEventTitle}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Known vs Hidden Effects */}
                  <div className="space-y-2 pt-2">
                    <span className="text-xs font-bold uppercase text-ink/80 block">
                      Известные последствия для державы:
                    </span>
                    <div className="space-y-1">
                      {selectedNode.knownEffects.map((eff, i) => (
                        <div key={i} className="text-xs text-ink/85 flex items-start gap-1.5 font-serif">
                          <span className="text-emerald-700 font-bold">✓</span>
                          <span>{eff}</span>
                        </div>
                      ))}
                    </div>

                    {selectedNode.forecastHint && (
                      <div className="mt-3 p-2.5 bg-amber-50 border border-amber-300 text-xs text-amber-900 font-serif">
                        <div className="font-bold font-mono text-[10px] uppercase text-amber-800 mb-0.5 flex items-center gap-1">
                          <Eye className="w-3 h-3" /> Прогноз аналитиков ставки:
                        </div>
                        {selectedNode.forecastHint}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-ink/50 italic font-serif">
                  Выберите причинно-следственный узел слева для просмотра подробного досье.
                </div>
              )}

              <div className="pt-3 border-t border-ink/15 text-[10px] text-ink/50 flex justify-between">
                <span>АРХИВ «IRON DOMINION»</span>
                <span>STATUS: DYNAMIC CAUSAL FLOW</span>
              </div>
            </div>

          </div>
        )}

        {/* Footer */}
        <div className="bg-[#e4dcbf] border-t border-ink/20 p-2.5 px-4 flex items-center justify-between text-xs font-mono text-ink/70">
          <span>Всего записей в архиве: {state.chronicle.length}</span>
          <span className="uppercase text-[10px]">ШТАБНОЙ ФОРМУЛЯР РЕГИСТРАЦИИ СОБЫТИЙ</span>
        </div>
      </motion.div>
    </div>
  );
}
