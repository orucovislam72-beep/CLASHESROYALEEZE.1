import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { History, GitBranch, Calendar, AlertCircle, ArrowRight, CheckCircle, ShieldCheck, Flame, Compass, Sparkles, RefreshCw } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';
import { gameStore } from '../utils/gameStore';

interface TimelineCrisis {
  year: number;
  title: string;
  era: string;
  situation: string;
  branches: {
    id: string;
    choiceText: string;
    historicalOutcome: string;
    impactTags: string[];
  }[];
}

const crisisHistory: TimelineCrisis[] = [
  {
    year: 1923,
    era: 'Эпоха Распада и Репараций',
    title: 'Рурский кризис и гиперинфляция Штальбурга',
    situation: 'Франко-бельгийские войска занимают угольные копи в ответ на задержку поставок. Валюта обесценивается в миллионы раз.',
    branches: [
      {
        id: 'c1_strike',
        choiceText: 'Объявить пассивное сопротивление и всеобщую забастовку шахтеров',
        historicalOutcome: 'Экономика рухнула, но национальное единство укрепилось. Возникло мощное антиреваншистское подполье.',
        impactTags: ['+30% Патриотизм', '-50% Заводы', 'Рождение Сопротивления']
      },
      {
        id: 'c1_secret_pact',
        choiceText: 'Заключить тайную сделку с Базельским банковским картелем',
        historicalOutcome: 'Франки стабилизировали марку, но государство попало в финансовую кабалу к теневым синдикатам.',
        impactTags: ['Финансовая стабильность', '+40% Теневое влияние', 'Секретные долги']
      }
    ]
  },
  {
    year: 1931,
    era: 'Великая Депрессия и Перевооружение',
    title: 'Банкротство Creditanstalt и военный меморандум',
    situation: 'Крупнейший банк Центральной Европы рухнул. Генеральный штаб предлагает национализировать сталелитейные концерны.',
    branches: [
      {
        id: 'c2_militarize',
        choiceText: 'Полная национализация заводов и запуск скрытого перевооружения',
        historicalOutcome: 'Безработица ликвидирована за 18 месяцев. Сформированы первые 10 танковых дивизий вне рамок договоров.',
        impactTags: ['+80% Армия', 'Дипломатический скандал', 'Дефицит зерна']
      },
      {
        id: 'c2_free_trade',
        choiceText: 'Опереться на экспорт дизельных технологий нейтральным странам',
        historicalOutcome: 'Армия осталась компактной, но страна накопила колоссальный золотой резерв и патентное лидерство.',
        impactTags: ['+60% Бюджет', 'Низкая армия', 'Высокие технологии']
      }
    ]
  },
  {
    year: 1936,
    era: 'Пограничные Войны и Эскалация',
    title: 'Мятеж генералов в Корсаке и ремилитаризация границы',
    situation: 'В провинции Корсак вспыхнула гражданская война. Западные державы угрожают морской блокадой при вводе войск.',
    branches: [
      {
        id: 'c3_intervention',
        choiceText: 'Нанести упреждающий удар бронепоездами и аннексировать Корсак',
        historicalOutcome: 'Корсак взят за 72 часа. Запад объявляет торговое эмбарго, подталкивая страну к автаркии.',
        impactTags: ['Новые территории', 'Блокада портов', '+100% Уверенность армии']
      },
      {
        id: 'c3_proxy_war',
        choiceText: 'Вести тайную войну через наёмников и поставку чертежей повстанцам',
        historicalOutcome: 'Официального повода для войны нет. Провинция расколота на партизанские анклавы.',
        impactTags: ['Сохранение мира', 'Хаос на границе', 'Тайные агенты']
      }
    ]
  },
  {
    year: 1939,
    era: 'Тотальная Мировая Война',
    title: 'Операция «Буря Стали» и активация проекта «Колосс»',
    situation: 'Ультиматум истёк. Армады дизельных шагоходов и бомбардировщиков выстроились вдоль демаркационной линии.',
    branches: [
      {
        id: 'c4_blitz',
        choiceText: 'Тотальный танковый блицкриг на столицу врага без объявления войны',
        historicalOutcome: 'Быстрая победа на Западном ТВД, но затяжная партизанская война на оккупированных восточных равнинах.',
        impactTags: ['Триумф в столице', 'Партизанский фронт', 'Истощение нефти']
      },
      {
        id: 'c4_colossus',
        choiceText: 'Полигонная демонстрация сверхоружия «Колосс-IX» для принуждения к капитуляции',
        historicalOutcome: 'Враг ошеломлён мощью шагохода и подписал мирный договор. Наступает эпоха Дизельной Холодной Войны.',
        impactTags: ['Мир на условиях Штальбурга', 'Дизельная Холодная Война', 'Гонка Мега-Оружия']
      }
    ]
  }
];

export default function CrisisTimeline() {
  const [selectedCrisisIndex, setSelectedCrisisIndex] = useState<number>(0);
  const [chosenDecisions, setChosenDecisions] = useState<Record<number, string>>({
    0: 'c1_strike',
    1: 'c2_militarize',
    2: 'c3_intervention',
    3: 'c4_colossus'
  });

  const currentCrisis = crisisHistory[selectedCrisisIndex];

  const handleSelectDecision = (crisisIdx: number, branchId: string) => {
    setChosenDecisions(prev => ({ ...prev, [crisisIdx]: branchId }));
    audioEngine.playMorseBeep(true);
  };

  return (
    <div className="w-full bg-paper/90 border-2 border-ink p-4 md:p-6 font-sans text-ink relative shadow-[4px_4px_0_var(--color-ink)]">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-ink text-paper-light flex items-center justify-center border border-ink">
            <GitBranch className="w-6 h-6 text-blood" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-xl md:text-2xl uppercase tracking-tight text-ink">
              Хроника Развилок // Альтернативная История 1920–1945
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Интерактивное дерево ключевых исторических решений и геополитических последствий
            </span>
          </div>
        </div>

        {/* Current Year Badge & Randomizer */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              gameStore.randomizeScenario();
            }}
            className="flex items-center gap-2 bg-ink/10 hover:bg-ink hover:text-paper-light px-3 py-1 font-mono text-[10px] font-bold border border-ink transition-all group"
            title="Перезапустить симуляцию с рандомными начальными условиями"
          >
            <RefreshCw className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-500" />
            РАНДОМИЗИРОВАТЬ СТАРТ
          </button>
          
          <div className="bg-blood text-paper-light px-3 py-1 font-mono text-xs font-bold border border-ink">
            ГОД: {currentCrisis.year}
          </div>
        </div>
      </div>

      {/* Timeline Stepper Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6 font-mono text-xs">
        {crisisHistory.map((c, idx) => {
          const isSelected = idx === selectedCrisisIndex;
          const isPassed = chosenDecisions[idx] !== undefined;

          return (
            <button
              key={c.year}
              onClick={() => { setSelectedCrisisIndex(idx); audioEngine.playMorseBeep(false); }}
              className={`p-2.5 text-left border transition-all flex flex-col justify-between ${
                isSelected
                  ? 'bg-ink text-paper-light border-blood shadow-md'
                  : isPassed
                  ? 'bg-paper-light hover:bg-paper-dark/30 border-ink/20'
                  : 'bg-paper/50 opacity-60 border-dashed border-ink/30'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-amber-500">{c.year} г.</span>
                {isPassed && <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />}
              </div>
              <span className="font-serif font-bold text-[10px] sm:text-[11px] leading-tight truncate mt-1">
                {c.title}
              </span>
            </button>
          );
        })}
      </div>

      {/* Main Crisis Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Crisis Context (5 Cols) */}
        <div className="lg:col-span-5 bg-paper-light border-2 border-ink p-4 md:p-5 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between border-b border-ink/20 pb-2 mb-3 font-mono text-[10px] text-ink/60 uppercase">
              <span>{currentCrisis.era}</span>
              <span>АРХИВНЫЙ ДОКУМЕНТ</span>
            </div>

            <h4 className="font-serif font-bold text-xl md:text-2xl text-ink uppercase mb-2">
              {currentCrisis.title}
            </h4>

            <p className="font-mono text-xs text-ink/80 leading-relaxed mb-4">
              {currentCrisis.situation}
            </p>
          </div>

          <div className="bg-ink/5 p-3 border border-ink/15 font-mono text-[10px] text-ink/70">
            <span className="font-bold text-ink uppercase block mb-1">Историческая справка:</span>
            Каждое решение навсегда меняет расстановку сил, открывая уникальные военные доктрины, секретные прототипы или восстания в провинциях.
          </div>
        </div>

        {/* Right: Branching Options (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col gap-3">
          <span className="font-mono text-[10px] uppercase font-bold text-ink/60 block">
            Исторические варианты действий верховного командования:
          </span>

          <div className="space-y-3">
            {currentCrisis.branches.map((branch) => {
              const isSelected = chosenDecisions[selectedCrisisIndex] === branch.id;

              return (
                <div
                  key={branch.id}
                  onClick={() => handleSelectDecision(selectedCrisisIndex, branch.id)}
                  className={`p-4 border-2 cursor-pointer transition-all flex flex-col gap-2 relative ${
                    isSelected
                      ? 'bg-ink text-paper-light border-blood shadow-lg'
                      : 'bg-paper-light hover:bg-paper-dark/30 border-ink/20'
                  }`}
                >
                  {isSelected && <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-blood" />}

                  <div className="flex items-start justify-between gap-3">
                    <span className="font-serif font-bold text-sm sm:text-base leading-snug">
                      {branch.choiceText}
                    </span>
                    <span className={`font-mono text-[9px] px-2 py-0.5 uppercase font-bold shrink-0 ${
                      isSelected ? 'bg-blood text-paper-light' : 'bg-ink/10 text-ink'
                    }`}>
                      {isSelected ? 'ВЫБРАННЫЙ ПУТЬ' : 'ВЫБРАТЬ'}
                    </span>
                  </div>

                  <p className="font-mono text-xs opacity-85 leading-relaxed">
                    {branch.historicalOutcome}
                  </p>

                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {branch.impactTags.map((tag, tagIdx) => (
                      <span
                        key={tagIdx}
                        className={`font-mono text-[9px] px-2 py-0.5 border ${
                          isSelected
                            ? 'border-amber-400/40 text-amber-300 bg-amber-950/40'
                            : 'border-ink/20 text-ink/70 bg-ink/5'
                        }`}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
}
