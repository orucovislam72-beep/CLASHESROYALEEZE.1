import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Coins, Train, AlertTriangle, ShieldCheck, Flame, Zap, Compass, ArrowRight, RefreshCw, Layers } from 'lucide-react';

interface SupplyRoute {
  id: string;
  name: string;
  cargo: 'Уголь' | 'Нефть' | 'Сталь' | 'Снаряды';
  origin: string;
  destination: string;
  status: 'active' | 'severed' | 'congested';
  trainsEnRoute: number;
  fuelReservesDays: number;
  vulnerability: number; // 0 to 100%
}

const initialRoutes: SupplyRoute[] = [
  {
    id: 'route-coal',
    name: 'Магистраль Остенмарк — Штальбург',
    cargo: 'Уголь',
    origin: 'Шахты Остенмарка',
    destination: 'Сталелитейный узел Штальбург',
    status: 'active',
    trainsEnRoute: 4,
    fuelReservesDays: 7.5,
    vulnerability: 42
  },
  {
    id: 'route-fuel',
    name: 'Северная Нефтяная Ветка',
    cargo: 'Нефть',
    origin: 'Промыслы Этельгарда',
    destination: '1-я Танковая Армия (Фронт)',
    status: 'active',
    trainsEnRoute: 3,
    fuelReservesDays: 3.0,
    vulnerability: 85
  },
  {
    id: 'route-ammo',
    name: 'Восточный Арсенальный Экспресс',
    cargo: 'Снаряды',
    origin: 'Заводы Ной-Ворна',
    destination: 'Укрепрайон «Линия Кайзера»',
    status: 'active',
    trainsEnRoute: 2,
    fuelReservesDays: 5.2,
    vulnerability: 20
  }
];

export default function LogisticsNetwork() {
  const [routes, setRoutes] = useState<SupplyRoute[]>(initialRoutes);
  const [log, setLog] = useState<string[]>([]);
  const [simulationTick, setSimulationTick] = useState<number>(0);

  // Train animation ticker
  useEffect(() => {
    const timer = setInterval(() => {
      setSimulationTick(prev => prev + 1);
    }, 1500);
    return () => clearInterval(timer);
  }, []);

  const handleSeverRoute = (id: string) => {
    setRoutes(prev => prev.map(r => {
      if (r.id === id) {
        const newStatus = r.status === 'severed' ? 'active' : 'severed';
        const msg = newStatus === 'severed'
          ? `[ДИВЕРСИЯ] Рельсы на ветке «${r.name}» подорваны! Поставки ${r.cargo} прекращены. Фронт обесточен!`
          : `[РЕМОНТ] Железнодорожный батальон восстановил мост на линии «${r.name}». Эшелоны запущены.`;
        setLog(prevLog => [msg, ...prevLog.slice(0, 5)]);
        return {
          ...r,
          status: newStatus,
          fuelReservesDays: newStatus === 'severed' ? 0.8 : 4.5
        };
      }
      return r;
    }));
  };

  const handleReinforceRoute = (id: string) => {
    setRoutes(prev => prev.map(r => {
      if (r.id === id) {
        setLog(prevLog => [`[ОХРАНА] Бронепоезд отправлен на патрулирование линии «${r.name}». Уязвимость снижена.`, ...prevLog.slice(0, 5)]);
        return {
          ...r,
          vulnerability: Math.max(10, r.vulnerability - 25),
          trainsEnRoute: r.trainsEnRoute + 1
        };
      }
      return r;
    }));
  };

  return (
    <div className="w-full bg-paper/60 border border-ink/20 p-4 md:p-6 relative font-sans text-ink">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-2">
        <div className="flex items-center gap-2.5">
          <Coins className="w-5 h-5 text-blood" />
          <div>
            <h3 className="font-serif font-bold text-xl uppercase tracking-tight text-ink">
              Физическая Логистика и Снабжение Фронта
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Ресурсы перемещаются реальными составами. Без топлива танки встают за 3 дня.
            </span>
          </div>
        </div>
        <div className="font-mono text-xs bg-ink text-paper-light px-3 py-1.5 flex items-center gap-2">
          <Train className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
          <span>ЭШЕЛОНЫ В ПУТИ: <strong className="text-amber-300">9 СОСТАВОВ</strong></span>
        </div>
      </div>

      {/* Routes Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-5">
        {routes.map(route => {
          const isSevered = route.status === 'severed';
          return (
            <div
              key={route.id}
              className={`p-4 border transition-all relative flex flex-col justify-between ${
                isSevered
                  ? 'bg-blood/10 border-blood shadow-sm'
                  : 'bg-paper-light border-ink/20 hover:border-ink/50'
              }`}
            >
              <div>
                <div className="flex items-center justify-between border-b border-ink/15 pb-2 mb-2">
                  <span className={`font-mono text-[9px] uppercase font-bold px-1.5 py-0.5 border ${
                    isSevered ? 'bg-blood text-paper-light border-blood' : 'bg-ink/10 text-ink border-ink/20'
                  }`}>
                    {isSevered ? 'ЛИНИЯ ПЕРЕРЕЗАНА' : 'ШТАТНЫЙ ТРАФИК'}
                  </span>
                  <span className="font-mono text-[10px] text-ink/50 font-bold">
                    {route.cargo}
                  </span>
                </div>

                <h4 className="font-serif font-bold text-base mb-1 text-ink">
                  {route.name}
                </h4>

                <div className="font-mono text-xs text-ink/70 space-y-1 my-3">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] uppercase text-ink/40">Откуда:</span>
                    <span className="text-ink font-medium">{route.origin}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] uppercase text-ink/40">Куда:</span>
                    <span className="text-ink font-medium">{route.destination}</span>
                  </div>
                </div>

                {/* Animated Train Track simulation */}
                <div className="w-full bg-ink/10 h-6 my-2 relative overflow-hidden border border-ink/20 flex items-center px-1">
                  {/* Railway ties */}
                  <div className="absolute inset-0 flex justify-between px-1 opacity-20 pointer-events-none">
                    {[...Array(16)].map((_, i) => (
                      <div key={i} className="w-[2px] h-full bg-ink" />
                    ))}
                  </div>

                  {/* Animated train wagon */}
                  {!isSevered ? (
                    <motion.div
                      animate={{ x: [(simulationTick * 35) % 180, (simulationTick * 35 + 40) % 180] }}
                      transition={{ duration: 1.5, ease: "linear" }}
                      className="relative z-10 flex items-center gap-1 bg-ink text-paper-light px-1.5 py-0.5 font-mono text-[9px] font-bold"
                    >
                      <Train className="w-2.5 h-2.5 text-amber-300" />
                      <span>{route.cargo}</span>
                    </motion.div>
                  ) : (
                    <div className="relative z-10 flex items-center gap-1 text-blood font-mono text-[10px] font-bold mx-auto">
                      <Flame className="w-3.5 h-3.5 animate-bounce" />
                      <span>ВЗРЫВ ПОЛОТНА</span>
                    </div>
                  )}
                </div>

                {/* Fuel gauge / Tank reserve */}
                <div className="mt-3 font-mono text-xs">
                  <div className="flex justify-between text-[10px] uppercase mb-0.5">
                    <span>Автономия фронтовых танков:</span>
                    <span className={`font-bold ${route.fuelReservesDays <= 1 ? 'text-blood animate-pulse' : 'text-emerald-700'}`}>
                      {route.fuelReservesDays.toFixed(1)} Дней
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-ink/10">
                    <div
                      className={`h-full transition-all duration-500 ${
                        route.fuelReservesDays <= 1 ? 'bg-blood' : 'bg-emerald-600'
                      }`}
                      style={{ width: `${Math.min(100, (route.fuelReservesDays / 7.5) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-ink/15 grid grid-cols-2 gap-2">
                <button
                  onClick={() => handleSeverRoute(route.id)}
                  className={`px-2 py-1 font-mono text-[10px] uppercase font-bold transition-all border ${
                    isSevered
                      ? 'bg-ink text-paper-light border-ink hover:bg-emerald-700'
                      : 'bg-paper text-blood border-blood/50 hover:bg-blood hover:text-paper-light'
                  }`}
                >
                  {isSevered ? 'Починить путь' : 'Взорвать мост'}
                </button>

                <button
                  onClick={() => handleReinforceRoute(route.id)}
                  className="px-2 py-1 bg-paper border border-ink/40 font-mono text-[10px] uppercase hover:bg-ink hover:text-paper-light transition-all flex items-center justify-center gap-1"
                >
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  <span>Бронепоезд</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Live Log Terminal */}
      <div className="bg-ink text-paper-light p-3 font-mono text-xs border border-ink">
        <div className="text-[10px] uppercase tracking-wider text-paper/60 border-b border-paper/20 pb-1 mb-2 flex justify-between">
          <span>Хроника железнодорожного министерства // Dispatch Feed</span>
          <span className="text-amber-400">STATUS: REALTIME</span>
        </div>
        <div className="space-y-1 max-h-24 overflow-y-auto">
          {log.length === 0 ? (
            <div className="text-paper/40 italic">Все железнодорожные узлы функционируют штатно. Составы с углем и нефтью следуют по расписанию.</div>
          ) : (
            log.map((item, index) => (
              <div key={index} className="text-[11px] leading-snug">
                <span className="text-blood mr-1.5">●</span>
                <span>{item}</span>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
}
