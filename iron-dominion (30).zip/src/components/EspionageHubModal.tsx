import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Eye, X, ShieldAlert, Crosshair, Clock, AlertTriangle, 
  MapPin, CheckCircle, ChevronRight, Sparkles, Coins,
  Radio, Award, UserCheck, Flame, Plane, ShieldCheck, UserX,
  FileSearch, Compass, Zap, Cpu, Search, Database, RefreshCw
} from 'lucide-react';
import { GameState, SpyAgent, SPY_MISSION_TYPES, SpyMissionType } from '../utils/gameState';
import { gameStore } from '../utils/gameStore';
import { audioEngine } from '../utils/audioEngine';
import { routeAIRequest } from '../utils/aiRouter';

interface EspionageHubModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function EspionageHubModal({ isOpen, onClose }: EspionageHubModalProps) {
  const [state, setState] = useState<GameState>(gameStore.getState());
  const [selectedAgentId, setSelectedAgentId] = useState<string>(state.agents[0]?.id || '');
  const [selectedLocation, setSelectedLocation] = useState<string>('Фалькенбург');
  const [selectedMissionId, setSelectedMissionId] = useState<string>(SPY_MISSION_TYPES[0].id);
  const [activeTab, setActiveTab] = useState<'agents' | 'aerial_recon'>('agents');
  
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  React.useEffect(() => {
    return gameStore.subscribe(setState);
  }, []);

  if (!isOpen) return null;

  const selectedAgent = state.agents.find(a => a.id === selectedAgentId) || state.agents[0];
  const selectedMission = SPY_MISSION_TYPES.find(m => m.id === selectedMissionId) || SPY_MISSION_TYPES[0];

  // Resolve target country intel
  const targetCountryId = selectedLocation === 'Норланд' ? 'norland' : selectedLocation === 'Фалькенбург' ? 'falkenburg' : 'ethelgard_republic';
  const targetCountry = state.countries.find(c => c.id === targetCountryId);
  const currentIntelCoverage = targetCountry?.intelCoverage || 30;

  const handleAIRecon = async () => {
    if (!targetCountry) return;
    setIsAiLoading(true);
    setAiReport(null);
    audioEngine.playTuningSweep();

    try {
      const prompt = `Проведи стратегический анализ страны: ${targetCountry.name}. 
      Код: ${targetCountry.code}. 
      Отношения: ${targetCountry.relations}.
      Напряженность: ${targetCountry.tension}%.
      Покрытие разведки: ${targetCountry.intelCoverage}%.
      Дивизий на границе: ${targetCountry.mobilizationDivisions}.
      Описание: ${targetCountry.description}.
      
      Оцени риски прямого столкновения, слабые места в их обороне и дай рекомендации для шпионской сети.
      Ответ дай в формате JSON: { "analysis": "текст", "riskAssessment": "текст", "priorityMission": "название" }`;

      const result = await routeAIRequest({
        prompt,
        urgency: 'medium',
        isKeyMoment: false
      });

      setAiReport(result.analysis + "\n\nОЦЕНКА РИСКОВ: " + result.riskAssessment + "\nРЕКОМЕНДУЕМАЯ МИССИЯ: " + result.priorityMission);
    } catch (error) {
      console.error("AI Recon failed:", error);
      setAiReport("Ошибка при дешифровке данных разведки.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleDispatch = () => {
    if (!selectedAgent || selectedAgent.status === 'on_mission') return;
    if (state.resources.treasury < selectedMission.costTreasury) return;

    gameStore.dispatchAgentMission(selectedAgent.id, selectedMission.id, selectedLocation);
  };

  const handleAerialRecon = (countryId: string) => {
    gameStore.launchAerialRecon(countryId);
  };

  const getRiskBadge = (risk: SpyMissionType['risk']) => {
    switch (risk) {
      case 'low': return <span className="px-1.5 py-0.5 bg-emerald-900/50 text-emerald-300 border border-emerald-500 text-[9px] font-mono">НИЗКИЙ РИСК</span>;
      case 'medium': return <span className="px-1.5 py-0.5 bg-amber-900/50 text-amber-300 border border-amber-500 text-[9px] font-mono">СРЕДНИЙ РИСК</span>;
      case 'high': return <span className="px-1.5 py-0.5 bg-red-900/50 text-red-300 border border-red-500 text-[9px] font-mono">ВЫСОКИЙ РИСК</span>;
      case 'deadly': return <span className="px-1.5 py-0.5 bg-purple-900/50 text-purple-300 border border-purple-500 text-[9px] font-mono animate-pulse">СМЕРТЕЛЬНЫЙ РИСК</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-ink/85 backdrop-blur-xs font-mono">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        transition={{ duration: 0.25 }}
        className="w-full max-w-5xl max-h-[92vh] bg-ink text-paper-light border-4 border-blood shadow-2xl flex flex-col relative overflow-hidden"
      >
        {/* Header */}
        <div className="bg-blood text-paper-light p-3 sm:p-4 flex items-center justify-between border-b-2 border-amber-300">
          <div className="flex items-center gap-3">
            <Eye className="w-6 h-6 text-amber-300 animate-pulse" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-widest text-amber-300 font-bold">
                  IV УПРАВЛЕНИЕ РАЗВЕДКИ // SPY NETWORK & RECON
                </span>
                <span className="px-1.5 py-0.5 bg-ink text-amber-300 text-[9px] font-mono font-bold">
                  TOP SECRET // EYES ONLY
                </span>
              </div>
              <h2 className="text-base sm:text-xl font-bold tracking-tight">
                Шпионская Сеть, Агентурные Операции & Авиаразведка
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                audioEngine.playClick('switch');
                onClose();
              }}
              className="p-1.5 bg-ink/40 hover:bg-ink text-paper-light border border-amber-300/40 transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Switcher Ribbon */}
        <div className="bg-paper/10 border-b border-paper/20 px-4 py-2 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                audioEngine.playClick('switch');
                setActiveTab('agents');
              }}
              className={`px-3 py-1 text-xs uppercase font-bold flex items-center gap-1.5 border transition-all ${
                activeTab === 'agents'
                  ? 'bg-amber-300 text-ink border-amber-400'
                  : 'bg-paper/10 hover:bg-paper/20 text-paper-light border-paper/20'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Агентурная Сеть ({state.agents.length})</span>
            </button>

            <button
              onClick={() => {
                audioEngine.playClick('switch');
                setActiveTab('aerial_recon');
              }}
              className={`px-3 py-1 text-xs uppercase font-bold flex items-center gap-1.5 border transition-all ${
                activeTab === 'aerial_recon'
                  ? 'bg-amber-300 text-ink border-amber-400'
                  : 'bg-paper/10 hover:bg-paper/20 text-paper-light border-paper/20'
              }`}
            >
              <Plane className="w-3.5 h-3.5" />
              <span>Авиаразведка Люфтваффе</span>
            </button>
          </div>

          <div className="text-[11px] text-paper/70 font-mono hidden sm:flex items-center gap-3">
            <span>Казна: <strong className="text-amber-300">{state.resources.treasury} RM</strong></span>
            <span>Топливо ГСМ: <strong className="text-amber-300">{state.resources.oil} брл.</strong></span>
          </div>
        </div>

        {/* Tab 1: Agent Deployment & Roster */}
        {activeTab === 'agents' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* Left Column: Active Agents Roster (5 cols) */}
            <div className="lg:col-span-5 flex flex-col gap-3">
              {/* AI Strategic Analysis */}
              <div className="p-3 bg-paper/5 border border-paper/10 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-amber-300 font-bold uppercase">
                    <Cpu className="w-3.5 h-3.5 text-amber-500" />
                    <span>IV Управление: "Колосс" (AI)</span>
                  </div>
                  <button
                    onClick={handleAIRecon}
                    disabled={isAiLoading}
                    className="p-1 px-2 bg-paper/10 hover:bg-paper/20 border border-paper/20 text-[9px] text-paper-light uppercase transition-all flex items-center gap-1.5 disabled:opacity-50"
                  >
                    {isAiLoading ? <RefreshCw className="w-2.5 h-2.5 animate-spin" /> : <Search className="w-2.5 h-2.5" />}
                    Дешифровать ТВД
                  </button>
                </div>
                
                {aiReport ? (
                  <div className="p-2.5 bg-ink/50 border border-paper/10 text-[10px] font-sans leading-relaxed text-paper/80 animate-in fade-in slide-in-from-top-1">
                    <div className="text-amber-300/80 mb-1 flex items-center gap-1 font-bold text-[9px] uppercase tracking-tighter">
                      <Sparkles className="w-3 h-3" /> СВОДКА ГЕНШТАБА:
                    </div>
                    {aiReport}
                  </div>
                ) : (
                  <div className="p-2 border border-dashed border-paper/10 text-[9px] text-paper/40 italic text-center">
                    Разведданные не дешифрованы. Нажмите кнопку для анализа {selectedLocation}.
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between border-b border-paper/20 pb-2">
                <span className="text-xs font-bold uppercase text-amber-300 tracking-wider">
                  СПИСОК АКТИВНЫХ АГЕНТОВ ({state.agents.length})
                </span>
                <span className="text-[10px] text-paper/60">
                  РЕЙТИНГ НАДЁЖНОСТИ
                </span>
              </div>

              <div className="space-y-2.5">
                {state.agents.map(agent => (
                  <div
                    key={agent.id}
                    onClick={() => {
                      audioEngine.playClick('switch');
                      setSelectedAgentId(agent.id);
                    }}
                    className={`p-3 border transition-all cursor-pointer relative ${
                      selectedAgentId === agent.id
                        ? 'bg-paper/20 border-amber-300 shadow-md'
                        : 'bg-paper/5 hover:bg-paper/10 border-paper/20'
                    } ${agent.isTargetedByCounterIntel ? 'border-red-500 bg-red-950/20' : ''}`}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-amber-200">{agent.codename}</span>
                        <span className="text-[10px] text-paper/60">({agent.realName})</span>
                      </div>
                      {agent.isTargetedByCounterIntel ? (
                        <span className="px-1.5 py-0.5 bg-red-900 text-red-200 border border-red-500 text-[9px] font-bold animate-pulse flex items-center gap-1">
                          <AlertTriangle className="w-2.5 h-2.5" /> СЛЕЖКА!
                        </span>
                      ) : agent.status === 'on_mission' ? (
                        <span className="px-1.5 py-0.5 bg-cyan-900 text-cyan-300 border border-cyan-500 text-[9px] font-bold">
                          НА ЗАДАНИИ
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 bg-emerald-900 text-emerald-300 border border-emerald-500 text-[9px] font-bold">
                          ГОТОВ
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-xs text-paper/75 mb-2">
                      <span>Специализация: <strong className="text-paper-light">{agent.specialty.toUpperCase()}</strong></span>
                      <div className="flex items-center text-amber-300">
                        {'★'.repeat(agent.skill)}{'☆'.repeat(5 - agent.skill)}
                      </div>
                    </div>

                    <div className="text-[11px] text-paper/60 flex items-center justify-between">
                      <span>Локация: <span className="text-paper-light">{agent.assignedLocation}</span></span>
                      <span>Успешных миссий: <span className="text-emerald-400 font-bold">{agent.missionsCompleted}</span></span>
                    </div>

                    {/* Active mission progress bar if on mission */}
                    {agent.status === 'on_mission' && agent.currentMission && (
                      <div className="mt-2.5 pt-2 border-t border-paper/10">
                        <div className="flex items-center justify-between text-[10px] text-cyan-300 mb-1">
                          <span>{agent.currentMission.name}</span>
                          <span>Осталось {agent.currentMission.daysRemaining} дн.</span>
                        </div>
                        <div className="w-full bg-paper/20 h-1.5 overflow-hidden">
                          <div 
                            className="bg-cyan-400 h-full transition-all duration-300"
                            style={{ 
                              width: `${Math.round(((agent.currentMission.totalDays - agent.currentMission.daysRemaining) / agent.currentMission.totalDays) * 100)}%` 
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Counter-Intel Danger Panel if Selected Agent is under threat */}
              {selectedAgent?.isTargetedByCounterIntel && (
                <div className="p-3 bg-red-950/60 border-2 border-red-500 rounded-none mt-2 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-red-300">
                    <ShieldAlert className="w-4 h-4 text-red-400 animate-bounce" />
                    <span>ВНИМАНИЕ: АГЕНТ РАСКРЫТ КОНТРРАЗВЕДКОЙ!</span>
                  </div>
                  <p className="text-[11px] text-red-200/90 leading-tight">
                    Полиция противника окружает конспиративную квартиру. Необходим немедленный приказ ставки:
                  </p>
                  <div className="grid grid-cols-1 gap-1.5 pt-1">
                    <button
                      onClick={() => gameStore.recallAgent(selectedAgent.id)}
                      className="w-full p-1.5 bg-emerald-800 hover:bg-emerald-700 text-paper-light text-[10px] font-bold border border-emerald-400 flex items-center justify-center gap-1 transition-all"
                    >
                      <ShieldCheck className="w-3 h-3" />
                      ЭКСТРЕННАЯ ЭВАКУАЦИЯ В ШТАБ (100% УСПЕХ)
                    </button>
                    <button
                      onClick={() => gameStore.changeAgentIdentity(selectedAgent.id)}
                      disabled={state.resources.treasury < 150}
                      className="w-full p-1.5 bg-amber-800 hover:bg-amber-700 disabled:opacity-50 text-paper-light text-[10px] font-bold border border-amber-400 flex items-center justify-center gap-1 transition-all"
                    >
                      <Coins className="w-3 h-3" />
                      СМЕНА ЛЕГЕНДЫ И ПАСПОРТА (-150 RM)
                    </button>
                    <button
                      onClick={() => gameStore.sacrificeAgentContact(selectedAgent.id)}
                      className="w-full p-1.5 bg-red-900 hover:bg-red-800 text-paper-light text-[10px] font-bold border border-red-400 flex items-center justify-center gap-1 transition-all"
                    >
                      <UserX className="w-3 h-3" />
                      ПОДСТАВИТЬ СВЯЗНОГО (-8% СТАБИЛЬНОСТИ)
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Right Column: Mission Deployment Console (7 cols) */}
            <div className="lg:col-span-7 bg-paper/5 border border-paper/20 p-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between border-b border-paper/20 pb-2 mb-4">
                  <span className="text-xs font-bold uppercase text-amber-300 tracking-wider">
                    ПЛАНИРОВАНИЕ ОПЕРАТИВНОГО ЗАДАНИЯ
                  </span>
                  <span className="text-[10px] text-paper/60 font-mono">
                    ДИРЕКТИВА: {selectedAgent.codename}
                  </span>
                </div>

                {/* Step 1: Target Location */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] uppercase text-paper/70 font-bold block">
                      1. ЦЕЛЕВОЙ РЕГИОН / ТВД:
                    </label>
                    <span className="text-[10px] text-amber-300">
                      Разведпокрытие региона: {currentIntelCoverage}%
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {['Фалькенбург', 'Норланд', 'Корсак', 'Этельгард'].map(loc => (
                      <button
                        key={loc}
                        onClick={() => {
                          audioEngine.playClick('switch');
                          setSelectedLocation(loc);
                        }}
                        className={`p-2 border text-xs text-center transition-all ${
                          selectedLocation === loc
                            ? 'bg-amber-400 text-ink border-amber-300 font-bold'
                            : 'bg-paper/10 hover:bg-paper/20 text-paper-light border-paper/30'
                        }`}
                      >
                        <MapPin className="w-3 h-3 mx-auto mb-1 opacity-70" />
                        {loc}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Step 2: Mission Type */}
                <div className="mb-4">
                  <label className="text-[11px] uppercase text-paper/70 font-bold mb-1.5 block">
                    2. ВЫБОР СПЕЦОПЕРАЦИИ:
                  </label>
                  <div className="space-y-2">
                    {SPY_MISSION_TYPES.map(m => (
                      <div
                        key={m.id}
                        onClick={() => {
                          audioEngine.playClick('switch');
                          setSelectedMissionId(m.id);
                        }}
                        className={`p-2.5 border cursor-pointer transition-all ${
                          selectedMissionId === m.id
                            ? 'bg-paper/20 border-amber-300'
                            : 'bg-paper/5 hover:bg-paper/10 border-paper/15'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-1 mb-1">
                          <span className="text-xs font-bold text-paper-light">{m.name}</span>
                          <div className="flex items-center gap-2">
                            {getRiskBadge(m.risk)}
                            <span className="text-xs text-amber-300 font-bold flex items-center gap-1">
                              <Coins className="w-3 h-3" />
                              {m.costTreasury} RM
                            </span>
                          </div>
                        </div>

                        <p className="text-[11px] text-paper/70 leading-relaxed mb-1.5">
                          {m.description}
                        </p>

                        <div className="flex items-center justify-between text-[10px] text-paper/50">
                          <span>Срок: <strong className="text-paper-light">{m.durationDays} дней</strong></span>
                          <span className="text-emerald-400">Награда: {m.potentialRewards[0]}</span>
                        </div>

                        {/* Hidden Consequence Forecast Ribbon */}
                        {m.causesHiddenConsequence && (
                          <div className="mt-2 pt-1.5 border-t border-paper/10 text-[10px]">
                            {currentIntelCoverage >= m.causesHiddenConsequence.intelRequired ? (
                              <div className="text-amber-300/90 flex items-center gap-1.5">
                                <FileSearch className="w-3 h-3 text-amber-400 shrink-0" />
                                <span>ПРОГНОЗ РАЗВЕДКИ: {m.causesHiddenConsequence.forecast}</span>
                              </div>
                            ) : (
                              <div className="text-paper/40 flex items-center gap-1.5 italic">
                                <AlertTriangle className="w-3 h-3 opacity-60 shrink-0" />
                                <span>Скрытое последствие зашифровано (требуется {m.causesHiddenConsequence.intelRequired}% разведданных).</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Step 3: Dispatch Confirmation */}
              <div className="pt-4 border-t border-paper/20 mt-2">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <div className="text-xs text-paper/80">
                    Стоимость операции:{' '}
                    <span className={`font-bold ${state.resources.treasury >= selectedMission.costTreasury ? 'text-amber-300' : 'text-red-400'}`}>
                      {selectedMission.costTreasury} RM
                    </span>{' '}
                    (В казне: {state.resources.treasury} RM)
                  </div>

                  {selectedAgent.status === 'on_mission' && (
                    <span className="text-xs text-red-400 flex items-center gap-1 font-bold">
                      <AlertTriangle className="w-3.5 h-3.5" /> Агент уже занят заданием
                    </span>
                  )}
                </div>

                <button
                  onClick={handleDispatch}
                  disabled={selectedAgent.status === 'on_mission' || state.resources.treasury < selectedMission.costTreasury}
                  className="w-full py-3 bg-blood hover:bg-blood-hover disabled:opacity-40 disabled:pointer-events-none text-paper-light font-bold text-sm uppercase tracking-wider border-2 border-amber-300 shadow-md transition-all active:translate-y-0.5 flex items-center justify-center gap-2"
                >
                  <Crosshair className="w-4 h-4 text-amber-300" />
                  <span>ОТДАТЬ ПРИКАЗ: ОТПРАВИТЬ АГЕНТА {selectedAgent.codename}</span>
                </button>
              </div>
            </div>

          </div>
        )}

        {/* Tab 2: Aerial Reconnaissance Console */}
        {activeTab === 'aerial_recon' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            <div className="bg-paper/5 border border-paper/20 p-4">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-sm uppercase mb-2">
                <Plane className="w-4 h-4" />
                <span>Эскадрилья Дальней Разведки // Воздушная картография ТВД</span>
              </div>
              <p className="text-xs text-paper/80 leading-relaxed">
                Высотные фоторазведчики совершают полеты над территориями иностранных держав, вскрывая расположение оборонительных линий, складов боеприпасов и планы контрразведки.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {state.countries.map(c => (
                <div key={c.id} className="bg-paper/5 border border-paper/20 p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between border-b border-paper/20 pb-2 mb-3">
                      <span className="text-sm font-bold text-amber-200">{c.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 bg-paper/20 text-paper-light font-mono font-bold">
                        {c.code}
                      </span>
                    </div>

                    <div className="space-y-2 mb-4 text-xs font-mono">
                      <div className="flex justify-between text-paper/70">
                        <span>Разведпокрытие:</span>
                        <strong className="text-amber-300">{c.intelCoverage}%</strong>
                      </div>
                      <div className="w-full bg-paper/20 h-2 overflow-hidden">
                        <div 
                          className="bg-amber-400 h-full transition-all duration-300"
                          style={{ width: `${c.intelCoverage}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-paper/70">
                        <span>Напряженность границы:</span>
                        <span className={c.tension > 60 ? 'text-red-400 font-bold' : 'text-paper-light'}>
                          {c.tension}%
                        </span>
                      </div>
                      <div className="flex justify-between text-paper/70">
                        <span>Дивизий на границе:</span>
                        <span className="text-paper-light font-bold">{c.mobilizationDivisions} див.</span>
                      </div>
                    </div>

                    {/* Unlocked Intel Reports */}
                    <div className="space-y-1.5 mb-4">
                      <span className="text-[10px] uppercase font-bold text-amber-300/80">Разведданные:</span>
                      {c.knownIntelReports.map((rep, idx) => (
                        <div 
                          key={idx} 
                          className={`p-2 border text-[11px] ${
                            rep.unlocked 
                              ? 'bg-paper/10 border-amber-300/40 text-paper-light' 
                              : 'bg-paper/5 border-paper/10 text-paper/40 italic'
                          }`}
                        >
                          {rep.unlocked ? (
                            <span>{rep.headline}: {rep.report}</span>
                          ) : (
                            <span>[ЗАСЕКРЕЧЕНО // Требуется {rep.minIntel}% разведпокрытия]</span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => handleAerialRecon(c.id)}
                    disabled={state.resources.oil < 150 || state.resources.treasury < 80}
                    className="w-full py-2 bg-paper/20 hover:bg-amber-400 hover:text-ink disabled:opacity-40 text-paper-light text-xs font-bold uppercase tracking-wider border border-paper/30 transition-all flex items-center justify-center gap-1.5"
                  >
                    <Plane className="w-3.5 h-3.5" />
                    <span>НАПРАВИТЬ ВЫЛЕТ (-150 Нефти, -80 RM)</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="bg-ink/90 border-t border-paper/20 p-2.5 px-4 flex items-center justify-between text-xs text-paper/60">
          <span>Спецслужбы Доминиона контролируют 4 активных резидентуры</span>
          <span className="uppercase text-[10px]">ДИРЕКТИВА ГЛАВНОГО УПРАВЛЕНИЯ РАЗВЕДКИ</span>
        </div>
      </motion.div>
    </div>
  );
}
