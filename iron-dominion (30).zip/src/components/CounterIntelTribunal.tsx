import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, Eye, PhoneCall, AlertTriangle, CheckCircle, Scale, FileText, Skull, Lock, Unlock, Search, Users, Sparkles, Award, Landmark, Glasses, Briefcase, UserCheck } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';
import { gameStore } from '../utils/gameStore';

interface Suspect {
  id: string;
  name: string;
  role: string;
  iconType: 'general' | 'baron' | 'engineer';
  suspicionScore: number; // 0-100%
  allegation: string;
  evidence: string[];
  wiretapTranscript: string;
  status: 'under_investigation' | 'acquitted' | 'watched' | 'exiled' | 'executed';
  verdictDate?: string;
}

const initialSuspects: Suspect[] = [
  {
    id: 's1',
    name: 'Генерал-полковник Курт фон Блюхер',
    role: 'Командующий 3-й Ударной Армией',
    iconType: 'general',
    suspicionScore: 82,
    allegation: 'Тайный контакт с эмиссарами Базельского синдиката и отказ от штурма Корсака.',
    evidence: [
      'В сейфе обнаружен чек на 120,000 швейцарских франков.',
      'Перехвачена зашифрованная телеграмма с позывным «Омега-4».',
      'Отказ от выполнения прямого приказа Генерального Штаба от 14 октября.'
    ],
    wiretapTranscript: '«...Скажите в Базеле, что я не поведу людей на убой ради их сталелитейных котировок. Если чертежи "Колосса" попадут в печать — война закончится за три дня...»',
    status: 'under_investigation'
  },
  {
    id: 's2',
    name: 'Барон Отто Вейс',
    role: 'Заместитель министра тяжелой промышленности',
    iconType: 'baron',
    suspicionScore: 65,
    allegation: 'Искусственное занижение поставок легированной стали для затягивания перевооружения.',
    evidence: [
      'Неучтённые эшелоны с чугуном на пограничной станции Ворн.',
      'Слухи о владении долями в нейтральных швейцарских верфях.',
      'Частые ночные встречи с атташе иностранного посольства.'
    ],
    wiretapTranscript: '«...Сделайте задержку поставок на две недели. Сошлитесь на забастовку шахтеров. Цены на уголь должны подняться ещё на 18%...»',
    status: 'under_investigation'
  },
  {
    id: 's3',
    name: 'Профессор Эрих Райхерт',
    role: 'Главный инженер проекта «Колосс»',
    iconType: 'engineer',
    suspicionScore: 48,
    allegation: 'Подозрение в передаче чертежей дизель-электрического шасси вражеской разведке.',
    evidence: [
      'Пропажа трёх листов технической документации из закрытого КБ.',
      'Родственные связи в оккупированной провинции Остенмарк.',
      'Критика доктрины блицкрига на заседаниях военного совета.'
    ],
    wiretapTranscript: '«...Этот колосс слишком тяжел. Если они запустят реактор на полную мощность без буферной батареи — произойдет тепловой взрыв. Я обязан это исправить...»',
    status: 'under_investigation'
  }
];

export default function CounterIntelTribunal() {
  const [suspects, setSuspects] = useState<Suspect[]>(initialSuspects);
  const [selectedSuspectId, setSelectedSuspectId] = useState<string>('s1');
  const [paranoiaLevel, setParanoiaLevel] = useState<number>(68);
  const [officerLoyalty, setOfficerLoyalty] = useState<number>(75);
  const [enemyInfiltration, setEnemyInfiltration] = useState<number>(55);
  const [wiretapPlaying, setWiretapPlaying] = useState<boolean>(false);
  const [recentVerdictLog, setRecentVerdictLog] = useState<string | null>(null);

  const currentSuspect = suspects.find(s => s.id === selectedSuspectId) || suspects[0];

  const handlePlayWiretap = () => {
    setWiretapPlaying(true);
    audioEngine.playTuningSweep();
    audioEngine.playMorseBeep(true);

    if ('speechSynthesis' in window) {
      audioEngine.speakChapter(currentSuspect.wiretapTranscript, () => {
        setWiretapPlaying(false);
      });
    } else {
      setTimeout(() => setWiretapPlaying(false), 3000);
    }
  };

  const handleVerdict = (verdict: 'acquitted' | 'watched' | 'exiled' | 'executed') => {
    audioEngine.playMorseBeep(true);
    let log = '';

    setSuspects(prev => prev.map(s => {
      if (s.id === currentSuspect.id) {
        return { ...s, status: verdict, verdictDate: '15 Октября 1938' };
      }
      return s;
    }));

    if (verdict === 'acquitted') {
      setOfficerLoyalty(prev => Math.min(100, prev + 15));
      setParanoiaLevel(prev => Math.max(10, prev - 10));
      setEnemyInfiltration(prev => Math.min(100, prev + 10));
      log = `[ОПРАВДАНИЕ] ${currentSuspect.name} полностью реабилитирован. Лояльность штаба выросла.`;
      gameStore.executeTribunalVerdict(currentSuspect.name, 'acquit', currentSuspect.role);
    } else if (verdict === 'watched') {
      setParanoiaLevel(prev => Math.min(100, prev + 5));
      setEnemyInfiltration(prev => Math.max(0, prev - 15));
      log = `[СЛЕЖКА] За объектом ${currentSuspect.name} установлено круглосуточное наружное наблюдение.`;
      gameStore.executeTribunalVerdict(currentSuspect.name, 'imprison', currentSuspect.role);
    } else if (verdict === 'exiled') {
      setOfficerLoyalty(prev => Math.max(10, prev - 10));
      setEnemyInfiltration(prev => Math.max(0, prev - 25));
      setParanoiaLevel(prev => Math.min(100, prev + 10));
      log = `[ССЫЛКА] ${currentSuspect.name} отстранён от должности и сослан в дальний гарнизон.`;
      gameStore.executeTribunalVerdict(currentSuspect.name, 'exile', currentSuspect.role);
    } else if (verdict === 'executed') {
      setOfficerLoyalty(prev => Math.max(10, prev - 25));
      setParanoiaLevel(prev => Math.min(100, prev + 20));
      setEnemyInfiltration(prev => Math.max(0, prev - 40));
      log = `[ТРИБУНАЛ] Военный суд вынес высшую меру наказания для ${currentSuspect.name}. Сеть саботажа обезглавлена.`;
      gameStore.executeTribunalVerdict(currentSuspect.name, 'execute', currentSuspect.role);
    }

    setRecentVerdictLog(log);
  };

  return (
    <div className="w-full bg-paper/90 border-2 border-ink p-4 md:p-6 font-sans text-ink relative shadow-[4px_4px_0_var(--color-ink)]">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-ink text-paper-light flex items-center justify-center border border-ink">
            <ShieldAlert className="w-6 h-6 text-blood" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-xl md:text-2xl uppercase tracking-tight text-ink">
              Управление Контрразведки // Комитет Безопасности
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Прослушка телефонных линий, досье на высший генералитет и трибунал лояльности
            </span>
          </div>
        </div>

        {/* Paranoia Gauge */}
        <div className="flex items-center gap-2 bg-ink text-paper-light px-3 py-1.5 font-mono text-xs border border-ink">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          <span>ПАРАНОЙЯ СТАВКИ: <strong className="text-amber-300">{paranoiaLevel}%</strong></span>
        </div>
      </div>

      {/* Main Grid: Left Suspects List, Right Suspect Investigation Board */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Suspects Directory (4 Cols) */}
        <div className="lg:col-span-4 flex flex-col gap-3">
          
          {/* Security Balance Gauges */}
          <div className="bg-paper-light border border-ink/20 p-3 font-mono text-xs">
            <span className="text-[10px] uppercase font-bold text-ink/50 block border-b border-ink/15 pb-1 mb-2">
              Штабные Показатели Безопасности:
            </span>
            <div className="space-y-2 text-[10px]">
              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-ink/70">Лояльность офицерского корпуса:</span>
                  <span className="font-bold text-ink">{officerLoyalty}%</span>
                </div>
                <div className="w-full bg-ink/10 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-full transition-all" style={{ width: `${officerLoyalty}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-ink/70">Инфильтрация шпионов в штаб:</span>
                  <span className={`font-bold ${enemyInfiltration > 40 ? 'text-blood' : 'text-ink'}`}>{enemyInfiltration}%</span>
                </div>
                <div className="w-full bg-ink/10 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-blood h-full transition-all" style={{ width: `${enemyInfiltration}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Suspects Cards */}
          <span className="font-mono text-[10px] uppercase text-ink/50 block">
            Фигуранты расследований:
          </span>
          <div className="space-y-2">
            {suspects.map(s => {
              const isSelected = s.id === selectedSuspectId;
              return (
                <div
                  key={s.id}
                  onClick={() => { setSelectedSuspectId(s.id); audioEngine.playMorseBeep(false); }}
                  className={`p-3 border cursor-pointer transition-all flex items-center justify-between relative ${
                    isSelected
                      ? 'bg-ink text-paper-light border-blood shadow-md'
                      : 'bg-paper-light hover:bg-paper-dark/30 border-ink/20'
                  }`}
                >
                  {isSelected && <div className="absolute left-0 top-0 bottom-0 w-1 bg-blood" />}
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 flex items-center justify-center border ${
                      isSelected ? 'bg-paper/20 border-paper/40' : 'bg-ink/10 border-ink/30'
                    }`}>
                      {s.iconType === 'general' && <Award className={`w-4 h-4 ${isSelected ? 'text-amber-300' : 'text-blood'}`} />}
                      {s.iconType === 'baron' && <Landmark className={`w-4 h-4 ${isSelected ? 'text-amber-300' : 'text-amber-700'}`} />}
                      {s.iconType === 'engineer' && <Glasses className={`w-4 h-4 ${isSelected ? 'text-amber-300' : 'text-sky-700'}`} />}
                    </div>
                    <div className="flex flex-col">
                      <span className="font-serif font-bold text-xs sm:text-sm leading-tight">{s.name}</span>
                      <span className="font-mono text-[9px] opacity-70 truncate max-w-[150px]">{s.role}</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className={`font-mono text-xs font-bold ${s.suspicionScore > 70 ? 'text-blood' : 'text-amber-500'}`}>
                      {s.suspicionScore}%
                    </span>
                    <span className="font-mono text-[8px] uppercase opacity-60">
                      {s.status === 'under_investigation' ? 'СЛЕДСТВИЕ' : s.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Secret Investigation Dossier (8 Cols) */}
        <div className="lg:col-span-8 bg-paper-light border-2 border-ink p-5 md:p-6 shadow-md flex flex-col justify-between">
          
          <div>
            {/* Dossier Header */}
            <div className="flex items-center justify-between border-b border-ink/20 pb-2 mb-4 font-mono text-xs">
              <div className="flex items-center gap-2">
                <span className="bg-blood text-paper-light px-2 py-0.5 uppercase font-bold text-[10px]">
                  ДЕЛО № 88-Б // ГРИФ: ОСОБО ОПАСНО
                </span>
                <span className="text-ink/60">СТАТУС: {currentSuspect.status.toUpperCase()}</span>
              </div>
              <span className="text-[10px] text-ink/50">ВЕДОМСТВО БЕЗОПАСНОСТИ</span>
            </div>

            {/* Suspect Title & Allegation */}
            <div className="flex items-start gap-4 mb-4">
              <div className="w-16 h-16 bg-ink text-paper-light border-2 border-blood flex items-center justify-center shrink-0 shadow-inner">
                {currentSuspect.iconType === 'general' && <Award className="w-9 h-9 text-amber-300" />}
                {currentSuspect.iconType === 'baron' && <Landmark className="w-9 h-9 text-amber-300" />}
                {currentSuspect.iconType === 'engineer' && <Glasses className="w-9 h-9 text-amber-300" />}
              </div>
              <div>
                <h4 className="font-serif font-bold text-xl md:text-2xl uppercase text-ink">
                  {currentSuspect.name}
                </h4>
                <div className="font-mono text-xs text-blood font-bold uppercase mb-1">
                  {currentSuspect.role}
                </div>
                <p className="font-mono text-xs text-ink/80 leading-relaxed">
                  {currentSuspect.allegation}
                </p>
              </div>
            </div>

            {/* Evidence List */}
            <div className="bg-ink/5 p-3 border border-ink/20 font-mono text-xs mb-4">
              <span className="text-[10px] uppercase font-bold text-ink/60 block mb-2">
                Приобщённые улики и материалы слежки:
              </span>
              <ul className="space-y-1.5 text-[11px] text-ink/90">
                {currentSuspect.evidence.map((ev, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-blood font-bold shrink-0">►</span>
                    <span>{ev}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Wiretap Audio Intercept */}
            <div className="bg-ink text-paper-light p-3.5 border border-ink font-mono text-xs mb-4">
              <div className="flex items-center justify-between border-b border-paper/20 pb-1.5 mb-2">
                <span className="text-amber-300 font-bold uppercase text-[10px] flex items-center gap-1.5">
                  <PhoneCall className="w-3.5 h-3.5 text-blood animate-pulse" />
                  Перехват телефонного кабеля (Запись прослушки)
                </span>
                <button
                  onClick={handlePlayWiretap}
                  disabled={wiretapPlaying}
                  className="px-2 py-0.5 bg-blood text-paper-light text-[9px] uppercase font-bold hover:bg-amber-400 hover:text-ink transition-colors flex items-center gap-1"
                >
                  <Eye className="w-3 h-3" />
                  <span>{wiretapPlaying ? 'ПРОСЛУШИВАНИЕ...' : 'Воспроизвести запись'}</span>
                </button>
              </div>
              <p className="font-serif italic text-xs md:text-sm text-paper-light/95 leading-relaxed">
                {currentSuspect.wiretapTranscript}
              </p>
            </div>
          </div>

          {/* Verdict Actions */}
          <div className="border-t border-ink/20 pt-4">
            <span className="font-mono text-[10px] uppercase text-ink/50 block mb-2">
              Вынести решение верховного командования:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                onClick={() => handleVerdict('acquitted')}
                className="p-2 border border-emerald-700 bg-emerald-50 hover:bg-emerald-700 hover:text-paper-light transition-all font-mono text-[10px] uppercase font-bold text-emerald-900 flex flex-col items-center gap-1"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Оправдать</span>
              </button>

              <button
                onClick={() => handleVerdict('watched')}
                className="p-2 border border-amber-600 bg-amber-50 hover:bg-amber-600 hover:text-paper-light transition-all font-mono text-[10px] uppercase font-bold text-amber-900 flex flex-col items-center gap-1"
              >
                <Eye className="w-4 h-4" />
                <span>Надзор</span>
              </button>

              <button
                onClick={() => handleVerdict('exiled')}
                className="p-2 border border-ink bg-ink/5 hover:bg-ink hover:text-paper-light transition-all font-mono text-[10px] uppercase font-bold text-ink flex flex-col items-center gap-1"
              >
                <Scale className="w-4 h-4" />
                <span>Сослать</span>
              </button>

              <button
                onClick={() => handleVerdict('executed')}
                className="p-2 border border-blood bg-blood/10 hover:bg-blood hover:text-paper-light transition-all font-mono text-[10px] uppercase font-bold text-blood flex flex-col items-center gap-1"
              >
                <Skull className="w-4 h-4" />
                <span>Трибунал</span>
              </button>
            </div>

            {recentVerdictLog && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-3 p-2 bg-ink text-amber-300 font-mono text-[10px] border border-ink"
              >
                {recentVerdictLog}
              </motion.div>
            )}
          </div>

        </div>
      </div>

    </div>
  );
}
