import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, Pause, FastForward, Zap, Clock, ShieldAlert, 
  Flame, HardHat, Compass, FileText, Eye, Users, 
  Skull, Sparkles, AlertTriangle, ChevronRight, Activity,
  Coins, Database, Layers, HelpCircle
} from 'lucide-react';
import { GameState, formatDate, GameSpeed } from '../utils/gameState';
import { gameStore } from '../utils/gameStore';
import { audioEngine } from '../utils/audioEngine';

interface GrandStrategyHUDProps {
  onOpenChronicle: () => void;
  onOpenEspionage: () => void;
  onOpenSecretScenarios: () => void;
  onOpenPolitics: () => void;
}

export default function GrandStrategyHUD({
  onOpenChronicle,
  onOpenEspionage,
  onOpenSecretScenarios,
  onOpenPolitics
}: GrandStrategyHUDProps) {
  const [state, setState] = useState<GameState>(gameStore.getState());

  useEffect(() => {
    return gameStore.subscribe(setState);
  }, []);

  const res = state.resources;
  const dateStr = formatDate(state.currentDate);

  const formatDelta = (num: number) => {
    if (num > 0) return `+${num}`;
    return `${num}`;
  };

  const handleNextDay = () => {
    gameStore.executeOrderOfTheDay();
  };

  const handleTogglePause = () => {
    gameStore.togglePause();
  };

  const handleSetSpeed = (speed: GameSpeed) => {
    gameStore.setSpeed(speed);
  };

  // Check active pending consequences count
  const pendingCausalCount = (state.causalGraph || []).filter(n => n.status === 'pending').length;
  const pendingConsequencesCount = state.consequences.length;
  // Check active spy missions count
  const activeMissionsCount = state.agents.filter(a => a.status === 'on_mission').length;

  return (
    <div className="w-full bg-ink text-paper-light border-b-2 border-blood shadow-md select-none font-mono">
      {/* Top Main Bar */}
      <div className="max-w-7xl mx-auto px-2 sm:px-4 py-2 flex flex-wrap items-center justify-between gap-2.5">
        
        {/* TIME & SPEED CONTROLLER */}
        <div className="flex items-center gap-2 bg-paper/10 px-2.5 py-1.5 border border-paper/20 rounded-none">
          <Clock className="w-4 h-4 text-amber-300 animate-pulse" />
          <div className="flex flex-col">
            <span className="text-[10px] text-paper/60 uppercase tracking-widest leading-none">
              ДАТА КАМПАНИИ // ДЕНЬ {state.totalDaysElapsed}
            </span>
            <span className="text-xs sm:text-sm font-bold text-amber-200 tracking-wider">
              {dateStr}
            </span>
          </div>

          {/* Speed Buttons */}
          <div className="flex items-center gap-1 ml-2 pl-2 border-l border-paper/20">
            <button
              onClick={handleTogglePause}
              className={`p-1 text-xs border transition-all ${
                state.isPaused
                  ? 'bg-amber-400 text-ink border-amber-300 font-bold'
                  : 'bg-paper/10 hover:bg-paper/20 text-paper-light border-paper/30'
              }`}
              title={state.isPaused ? 'Возобновить симуляцию' : 'Пауза'}
            >
              {state.isPaused ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={() => handleSetSpeed(1)}
              className={`px-1.5 py-0.5 text-[10px] font-bold border transition-all ${
                !state.isPaused && state.gameSpeed === 1
                  ? 'bg-amber-400 text-ink border-amber-300'
                  : 'bg-paper/10 hover:bg-paper/20 text-paper-light border-paper/30'
              }`}
            >
              1X
            </button>

            <button
              onClick={() => handleSetSpeed(2)}
              className={`px-1.5 py-0.5 text-[10px] font-bold border transition-all ${
                !state.isPaused && state.gameSpeed === 2
                  ? 'bg-amber-400 text-ink border-amber-300'
                  : 'bg-paper/10 hover:bg-paper/20 text-paper-light border-paper/30'
              }`}
            >
              2X
            </button>

            <button
              onClick={() => handleSetSpeed(5)}
              className={`px-1.5 py-0.5 text-[10px] font-bold border transition-all ${
                !state.isPaused && state.gameSpeed === 5
                  ? 'bg-amber-400 text-ink border-amber-300'
                  : 'bg-paper/10 hover:bg-paper/20 text-paper-light border-paper/30'
              }`}
            >
              5X
            </button>

            {/* Step 1 Day Button */}
            <button
              onClick={handleNextDay}
              className="ml-1 px-2.5 py-1 bg-blood hover:bg-blood-hover text-paper-light text-[10px] font-bold uppercase tracking-wider border border-amber-300 shadow-xs transition-all active:translate-y-0.5"
              title="Перейти на следующий день (Приказ ставки)"
            >
              ХОД (+1 ДЕНЬ)
            </button>
          </div>
        </div>

        {/* 6-PILLAR RESOURCE RIBBON */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 text-[10px]">
          {/* Causality Pulse - The World Remembers */}
          <motion.div 
            className={`flex items-center gap-1 px-2 py-1 border ${pendingCausalCount > 0 ? 'bg-purple-900/30 border-purple-500/50 text-purple-200' : 'bg-paper/5 border-paper/15 text-paper/40'}`}
            animate={pendingCausalCount > 0 ? { opacity: [0.6, 1, 0.6] } : {}}
            transition={{ duration: 3, repeat: Infinity }}
            title={pendingCausalCount > 0 ? `КАУЗАЛЬНАЯ ТРЕВОГА: Обнаружено ${pendingCausalCount} назревающих последствий.` : 'Мировая тишина: Значимых последствий не обнаружено.'}
          >
            <Layers className={`w-3.5 h-3.5 ${pendingCausalCount > 0 ? 'text-purple-400' : 'text-paper/20'}`} />
            <div className="flex flex-col">
              <span className="text-[9px] leading-none uppercase tracking-tighter">КАУЗАЛЬНОСТЬ</span>
              <span className="font-bold text-[9px]">{pendingCausalCount > 0 ? 'АКТИВНА' : 'ЧИСТО'}</span>
            </div>
          </motion.div>

          {/* Oil */}
          <div className="flex items-center gap-1 px-2 py-1 bg-paper/5 border border-paper/15" title="Топливо для танков и авиации">
            <Flame className={`w-3 h-3 ${res.oil < 500 ? 'text-red-500 animate-pulse' : 'text-amber-400'}`} />
            <div className="flex flex-col">
              <span className="text-[9px] text-paper/60 leading-none">НЕФТЬ</span>
              <div className="flex items-baseline gap-1">
                <span className="font-bold">{res.oil.toLocaleString()}</span>
                <span className={`text-[8px] font-semibold ${res.oilDelta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {formatDelta(res.oilDelta)}
                </span>
              </div>
            </div>
          </div>

          {/* Steel */}
          <div className="flex items-center gap-1 px-2 py-1 bg-paper/5 border border-paper/15" title="Сталь для танков и орудий КБ №7">
            <HardHat className="w-3 h-3 text-slate-300" />
            <div className="flex flex-col">
              <span className="text-[9px] text-paper/60 leading-none">СТАЛЬ</span>
              <div className="flex items-baseline gap-1">
                <span className="font-bold">{res.steel.toLocaleString()}</span>
                <span className="text-[8px] font-semibold text-emerald-400">{formatDelta(res.steelDelta)}</span>
              </div>
            </div>
          </div>

          {/* Rare Earth */}
          <div className="flex items-center gap-1 px-2 py-1 bg-paper/5 border border-paper/15" title="Вольфрам и редкие металлы для электроники и проекта «Колосс»">
            <Database className="w-3 h-3 text-cyan-300" />
            <div className="flex flex-col">
              <span className="text-[9px] text-paper/60 leading-none">ВОЛЬФРАМ</span>
              <div className="flex items-baseline gap-1">
                <span className="font-bold">{res.rareEarth.toLocaleString()}</span>
                <span className="text-[8px] font-semibold text-emerald-400">{formatDelta(res.rareEarthDelta)}</span>
              </div>
            </div>
          </div>

          {/* Food */}
          <div className="flex items-center gap-1 px-2 py-1 bg-paper/5 border border-paper/15" title="Продовольствие для армии и городов">
            <Activity className={`w-3 h-3 ${res.food < 1000 ? 'text-red-500 animate-pulse' : 'text-yellow-400'}`} />
            <div className="flex flex-col">
              <span className="text-[9px] text-paper/60 leading-none">ЗЕРНО</span>
              <div className="flex items-baseline gap-1">
                <span className="font-bold">{res.food.toLocaleString()}</span>
                <span className={`text-[8px] font-semibold ${res.foodDelta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {formatDelta(res.foodDelta)}
                </span>
              </div>
            </div>
          </div>

          {/* Electricity */}
          <div className="flex items-center gap-1 px-2 py-1 bg-paper/5 border border-paper/15" title="Мощность электростанций">
            <Zap className="w-3 h-3 text-amber-300" />
            <div className="flex flex-col">
              <span className="text-[9px] text-paper/60 leading-none">ЭНЕРГИЯ</span>
              <div className="flex items-baseline gap-1">
                <span className="font-bold">{res.electricity} МВт</span>
              </div>
            </div>
          </div>

          {/* Treasury */}
          <div className="flex items-center gap-1 px-2 py-1 bg-paper/5 border border-paper/15" title="Казна и золотовалютный резерв">
            <Coins className={`w-3 h-3 ${res.treasury < 1000 ? 'text-red-500' : 'text-amber-300'}`} />
            <div className="flex flex-col">
              <span className="text-[9px] text-paper/60 leading-none">КАЗНА</span>
              <div className="flex items-baseline gap-1">
                <span className="font-bold">{res.treasury.toLocaleString()}</span>
                <span className={`text-[8px] font-semibold ${res.treasuryDelta >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {formatDelta(res.treasuryDelta)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* STRATEGIC DASHBOARD SHORTCUTS */}
        <div className="flex items-center gap-1.5">
          {/* Stability Gauge */}
          <button
            onClick={() => {
              audioEngine.playClick('switch');
              onOpenPolitics();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-paper/10 hover:bg-paper/20 border border-paper/30 transition-all"
            title="Внутренняя стабильность и элиты государства"
          >
            <ShieldAlert className={`w-3.5 h-3.5 ${state.stability < 40 ? 'text-red-400 animate-pulse' : 'text-amber-300'}`} />
            <div className="flex flex-col text-left">
              <span className="text-[8px] text-paper/60 uppercase">СТАБИЛЬНОСТЬ</span>
              <span className="text-xs font-bold text-amber-200">{state.stability}%</span>
            </div>
          </button>

          {/* Espionage Hub */}
          <button
            onClick={() => {
              audioEngine.playClick('switch');
              onOpenEspionage();
            }}
            className="relative flex items-center gap-1 px-2.5 py-1 bg-paper/10 hover:bg-paper/20 border border-paper/30 text-[10px] uppercase font-bold text-paper-light transition-all"
            title="Шпионская сеть и тайные агенты"
          >
            <Eye className="w-3.5 h-3.5 text-cyan-300" />
            <span className="hidden sm:inline">ШПИОНАЖ</span>
            {activeMissionsCount > 0 && (
              <span className="px-1 py-0.2 bg-cyan-600 text-paper-light text-[9px] rounded-full font-bold animate-pulse">
                {activeMissionsCount}
              </span>
            )}
          </button>

          {/* Secret Scenarios */}
          <button
            onClick={() => {
              audioEngine.playClick('switch');
              onOpenSecretScenarios();
            }}
            className="relative flex items-center gap-1 px-2.5 py-1 bg-blood hover:bg-blood-hover border border-amber-300 text-[10px] uppercase font-bold text-paper-light transition-all"
            title="5 Скрытых Мега-Сценариев: Colossus, Black Sun, Dead Hand, Phantom, Red Meridian"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden md:inline">ТАЙНЫЕ СЦЕНАРИИ</span>
          </button>

          {/* World Chronicle Journal */}
          <button
            onClick={() => {
              audioEngine.playClick('switch');
              onOpenChronicle();
            }}
            className="flex items-center gap-1 px-2.5 py-1 bg-amber-400 hover:bg-amber-300 text-ink border border-amber-200 text-[10px] uppercase font-bold transition-all shadow-xs"
            title="Хроника истории мира и журнал альтернативных событий"
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">ХРОНИКА МИРА</span>
          </button>

          {/* Tutorial / Help */}
          <button
            onClick={() => gameStore.resetTutorial()}
            className="flex items-center justify-center p-1 px-2 bg-paper/20 hover:bg-amber-500 hover:text-ink border border-paper/30 transition-all"
            title="Показать обучение"
          >
            <HelpCircle className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Ripple Consequence Alert ticker (if any impending event within 7 days) */}
      {pendingConsequencesCount > 0 && (
        <div className="bg-paper/5 border-t border-paper/10 px-4 py-1 flex items-center justify-between text-[10px] text-amber-200">
          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
            <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0" />
            <span className="text-paper/60 uppercase">ОТЛОЖЕННЫЕ ПОСЛЕДСТВИЯ В ОЧЕРЕДИ ({pendingConsequencesCount}):</span>
            <span className="font-mono text-paper-light italic">
              «{state.consequences[0]?.title}» (наступит через {state.consequences[0]?.daysLeft} дн.)
            </span>
          </div>
          <span className="text-[9px] text-paper/50 font-mono shrink-0 pl-2">
            ДЕЙСТВИЕ → СЛЕДСТВИЕ
          </span>
        </div>
      )}
    </div>
  );
}
