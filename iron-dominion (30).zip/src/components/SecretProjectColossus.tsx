import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Skull, Key, Lock, Unlock, Cpu, Eye, AlertTriangle, Sparkles, FileText, CheckCircle2, ChevronRight, ShieldAlert, Disc, Radio } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface SecretBlueprint {
  id: string;
  codename: string;
  classification: string;
  category: string;
  description: string;
  dimensions: string;
  powerSource: string;
  combatImpact: string;
  status: 'locked' | 'unlocked';
}

const blueprints: SecretBlueprint[] = [
  {
    id: 'colossus',
    codename: 'Сверхтяжёлый бронешагоход «Колосс-IX»',
    classification: 'ULTRA-BLACK // EYES ONLY',
    category: 'Тяжелое прорывное вооружение',
    description: 'Двуногий бронированный колосс высотой 18 метров. Оснащён спаренной 280-мм морской пушкой и дизель-электрическим генератором высокого давления. Разрабатывался в закрытой шахте Корсака.',
    dimensions: 'Высота: 18.4м | Масса: 420 тонн | Броня: 220мм гомогенная сталь',
    powerSource: 'Турбодизельный агрегат V16 + буферная батарея',
    combatImpact: 'Одиночный шагоход способен подавить гарнизон целой провинции без артподготовки.',
    status: 'unlocked'
  },
  {
    id: 'stratosphere',
    codename: 'Стратосферный планер возмездия «Фау-Ноль»',
    classification: 'COSMIC // OCCULT DIVISION',
    category: 'Оружие дальнего удара',
    description: 'Ракетный аппарат с жидкостным реактивным двигателем для полетов в мезосфере. Способен нести 5 тонн химического или сейсмического заряда на расстояние до 3500 км.',
    dimensions: 'Длина: 24м | Размах: 14м | Скорость: 4.2 Маха',
    powerSource: 'ЖРД на азотнокислом окислителе',
    combatImpact: 'Мгновенное уничтожение любого железнодорожного узла или ставки командования.',
    status: 'unlocked'
  },
  {
    id: 'mjolnir',
    codename: 'Сейсмический генератор резонанса «Мьёльнир»',
    classification: 'ANOMALOUS // PROJECT AURORA',
    category: 'Геофизическое оружие',
    description: 'Подземный вибрационный индуктор, использующий резонанс тектонических разломов. Способен вызывать искусственные землетрясения силой до 7.5 баллов под вражескими бункерами.',
    dimensions: 'Глубина шахты: 1200м | Диаметр излучателя: 12м',
    powerSource: 'Подземная гидроэлектростанция водопада Этель',
    combatImpact: 'Обрушение подземных командных центров и мостов целого сектора.',
    status: 'unlocked'
  }
];

interface EncryptedTelegram {
  id: string;
  sender: string;
  interceptDate: string;
  ciphertext: string;
  plaintext: string;
  keyWord: string;
  isDecrypted: boolean;
}

const initialTelegrams: EncryptedTelegram[] = [
  {
    id: 'tel-1',
    sender: 'Базельский Синдикат «Омега» -> Послу в Штальбурге',
    interceptDate: '1938-10-14 23:45',
    ciphertext: 'QXZ-889 // WKLV LV WR FRQILUP WKDW WKH VKLSPHQW RI KHDYB ZDWHU KDV OHIW WKH SRUW RI EDVHO.',
    plaintext: 'ПОДТВЕРЖДАЕМ: ЭШЕЛОН С ТЯЖЕЛОЙ ВОДОЙ И ЗОЛОТЫМИ СЛИТКАМИ ПОКИНУЛ ПОРТ БАЗЕЛЯ. ДИВЕРСИЯ В КОРСАКЕ ОПЛАЧЕНА.',
    keyWord: 'OMEGA',
    isDecrypted: false
  },
  {
    id: 'tel-2',
    sender: 'Бункер №4 -> Генеральному Штабу',
    interceptDate: '1938-11-02 03:12',
    ciphertext: 'VHFUHW-404 // JHQHUDO YRQ EOXFKHU KDV VHDOHG WKH DUFKLYHV. SURMHFW DXURUD LV DFWLYH.',
    plaintext: 'ГЕНЕРАЛ ФОН БЛЮХЕР ЗАБЛОКИРОВАЛ АРХИВЫ. ПРОЕКТ "АВРОРА" АКТИВИРОВАН. ШАГОХОД "КОЛОСС" ГОТОВ К ИСПЫТАНИЯМ.',
    keyWord: 'AURORA',
    isDecrypted: false
  }
];

export default function SecretProjectColossus() {
  const [selectedBlueprint, setSelectedBlueprint] = useState<SecretBlueprint>(blueprints[0]);
  const [telegrams, setTelegrams] = useState<EncryptedTelegram[]>(initialTelegrams);
  const [rotorKey, setRotorKey] = useState<number>(3);
  const [activeTab, setActiveTab] = useState<'blueprints' | 'decryption' | 'conspiracy'>('blueprints');
  const [classifiedRedactions, setClassifiedRedactions] = useState<{ [key: string]: boolean }>({
    'name1': false,
    'date1': false,
    'loc1': false,
    'sponsor1': false
  });
  const [isTestFiring, setIsTestFiring] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  const handleDecryptTelegram = (id: string) => {
    audioEngine.playMorseBeep(true);
    setTelegrams(prev => prev.map(t => {
      if (t.id === id) {
        return { ...t, isDecrypted: true };
      }
      return t;
    }));
  };

  const toggleRedaction = (key: string) => {
    audioEngine.playMorseBeep(false);
    setClassifiedRedactions(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleTestFire = () => {
    setIsTestFiring(true);
    audioEngine.playTuningSweep();
    audioEngine.playMorseBeep(true);

    setTimeout(() => {
      setIsTestFiring(false);
      setTestResult(`[ПОЛИГОННЫЕ ИСПЫТАНИЯ УСПЕШНЫ] ${selectedBlueprint.codename} произвёл расчётный залп. Сейсмодатчики зафиксировали отклонение 4.2 балла в радиусе 60 км.`);
    }, 2000);
  };

  return (
    <div className="w-full bg-paper/70 border-2 border-blood/60 p-4 md:p-6 relative font-sans text-ink shadow-[0_0_25px_rgba(139,0,0,0.15)]">
      
      {/* Top Easter Egg Banner */}
      <div className="bg-blood text-paper-light px-3 py-1.5 font-mono text-xs flex items-center justify-between uppercase tracking-wider mb-4 border border-blood">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-300 animate-spin-slow" />
          <span className="font-bold">ПАСХАЛКА // ЗАПРЕТНЫЙ РАЗДЕЛ ГЕНЕРАЛЬНОГО ШТАБА</span>
        </div>
        <span className="text-[10px] text-amber-300 font-bold">LEVEL 5 CLEARANCE // UNLOCKED</span>
      </div>

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-2">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-ink text-blood flex items-center justify-center border border-blood">
            <Skull className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-2xl uppercase tracking-tight text-ink">
              Проект «Колосс» // Запретные Архивы
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Секретные прототипы, дешифровка перехватов и тайная хроника войны
            </span>
          </div>
        </div>

        {/* Sub-tabs */}
        <div className="flex gap-1 bg-ink/10 p-1 border border-ink/20 font-mono text-xs">
          <button
            onClick={() => setActiveTab('blueprints')}
            className={`px-3 py-1 uppercase font-bold transition-all ${
              activeTab === 'blueprints'
                ? 'bg-ink text-paper-light shadow-sm'
                : 'text-ink/70 hover:text-ink hover:bg-ink/10'
            }`}
          >
            Чертежи «Колосса»
          </button>
          <button
            onClick={() => setActiveTab('decryption')}
            className={`px-3 py-1 uppercase font-bold transition-all ${
              activeTab === 'decryption'
                ? 'bg-blood text-paper-light shadow-sm'
                : 'text-ink/70 hover:text-ink hover:bg-ink/10'
            }`}
          >
            Дешифратор Энигма
          </button>
          <button
            onClick={() => setActiveTab('conspiracy')}
            className={`px-3 py-1 uppercase font-bold transition-all ${
              activeTab === 'conspiracy'
                ? 'bg-ink text-paper-light shadow-sm'
                : 'text-ink/70 hover:text-ink hover:bg-ink/10'
            }`}
          >
            Тайное Досье
          </button>
        </div>
      </div>

      {/* TAB 1: BLUEPRINTS */}
      {activeTab === 'blueprints' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Blueprint Selector */}
          <div className="lg:col-span-4 flex flex-col gap-2">
            <span className="font-mono text-[10px] uppercase text-ink/50 border-b border-ink/15 pb-1">
              Секретные сверхорудия:
            </span>
            {blueprints.map(bp => {
              const isSelected = bp.id === selectedBlueprint.id;
              return (
                <div
                  key={bp.id}
                  onClick={() => { setSelectedBlueprint(bp); setTestResult(null); }}
                  className={`p-3 border cursor-pointer transition-all relative flex flex-col gap-1 ${
                    isSelected
                      ? 'bg-ink text-paper-light border-blood shadow-md'
                      : 'bg-paper-light hover:bg-paper-dark/30 border-ink/20'
                  }`}
                >
                  {isSelected && <div className="absolute left-0 top-0 bottom-0 w-1 bg-blood" />}
                  <span className="font-serif font-bold text-sm leading-tight">{bp.codename}</span>
                  <span className={`font-mono text-[9px] uppercase ${isSelected ? 'text-amber-300' : 'text-blood'}`}>
                    {bp.classification}
                  </span>
                </div>
              );
            })}

            {/* Schematic Radar Graphic */}
            <div className="mt-4 p-3 bg-ink text-paper-light border border-ink/30 font-mono text-xs flex flex-col items-center">
              <div className="w-24 h-24 rounded-full border border-blood/60 relative flex items-center justify-center mb-2">
                <div className="absolute inset-0 border border-blood/20 rounded-full animate-ping" />
                <div className="w-16 h-16 rounded-full border border-dashed border-amber-400/40" />
                <div className="w-1 h-1 bg-blood rounded-full" />
                <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-blood/30" />
                <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-blood/30" />
              </div>
              <span className="text-[10px] text-amber-300 uppercase">СЕКТОР: ШАХТА КОРСАК</span>
              <span className="text-[9px] text-paper/50">ТЕЛЕМЕТРИЯ: В НОРМЕ</span>
            </div>
          </div>

          {/* Right: Detailed Blueprint View */}
          <div className="lg:col-span-8 border-2 border-dashed border-ink/30 bg-paper-light p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-ink/15 pb-2 mb-3">
                <span className="font-mono text-[10px] text-stamp border border-stamp px-1.5 uppercase font-bold">
                  SCHEMATIC // {selectedBlueprint.classification}
                </span>
                <span className="font-mono text-[10px] text-ink/50">DOC_ID: #COL-1939-X</span>
              </div>

              <h4 className="font-serif font-bold text-2xl uppercase mb-2 text-ink">
                {selectedBlueprint.codename}
              </h4>
              <p className="font-mono text-xs text-ink-light leading-relaxed mb-4">
                {selectedBlueprint.description}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-xs mb-4">
                <div className="bg-ink/5 p-2.5 border border-ink/15">
                  <span className="text-[10px] uppercase text-ink/50 block mb-0.5">Габариты и ТТХ:</span>
                  <span className="text-ink font-bold">{selectedBlueprint.dimensions}</span>
                </div>
                <div className="bg-ink/5 p-2.5 border border-ink/15">
                  <span className="text-[10px] uppercase text-ink/50 block mb-0.5">Силовая установка:</span>
                  <span className="text-ink font-bold">{selectedBlueprint.powerSource}</span>
                </div>
              </div>

              <div className="bg-blood/10 border-l-4 border-blood p-3 font-mono text-xs text-ink">
                <span className="font-bold text-blood block mb-0.5">ВЛИЯНИЕ НА СТРАТЕГИЧЕСКИЙ БАЛАНС:</span>
                <span>{selectedBlueprint.combatImpact}</span>
              </div>
            </div>

            {/* Test Fire Action */}
            <div className="mt-5 pt-3 border-t border-ink/15">
              {testResult && (
                <div className="mb-3 p-2.5 bg-ink text-amber-300 font-mono text-xs border border-amber-500/50 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{testResult}</span>
                </div>
              )}

              <button
                onClick={handleTestFire}
                disabled={isTestFiring}
                className="w-full py-2.5 bg-blood text-paper-light font-mono text-xs uppercase font-bold hover:bg-ink transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isTestFiring ? (
                  <>
                    <Radio className="w-4 h-4 animate-spin text-amber-300" />
                    <span>ИДЁТ ЗАПУСК РЕАКТОРА...</span>
                  </>
                ) : (
                  <>
                    <Cpu className="w-4 h-4 text-amber-300" />
                    <span>Провести полигонные испытания прототипа</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ENIGMA DECRYPTION */}
      {activeTab === 'decryption' && (
        <div className="space-y-4">
          <div className="bg-ink/5 p-3 border border-ink/20 font-mono text-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <span className="font-bold text-ink uppercase">Штабной Дешифратор «Энигма-1934»</span>
              <p className="text-[11px] text-ink/70">Расшифруйте перехваченные радиодепеши теневого синдиката</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-ink/60 uppercase">Смещение ротора:</span>
              <button
                onClick={() => setRotorKey(prev => (prev % 10) + 1)}
                className="px-2 py-1 bg-ink text-amber-300 font-mono font-bold text-xs border border-ink hover:bg-blood"
              >
                РОТОР #{rotorKey} (КЛИК)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {telegrams.map(tel => (
              <div key={tel.id} className="p-4 border-2 border-ink/30 bg-paper-light flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-ink/15 pb-2 mb-2 font-mono text-[10px]">
                    <span className="text-blood font-bold uppercase">{tel.sender}</span>
                    <span className="text-ink/50">{tel.interceptDate}</span>
                  </div>

                  <div className="font-mono text-xs mb-3">
                    <span className="text-[10px] uppercase text-ink/40 block mb-1">Шифротекст (ВЧ перехват):</span>
                    <div className="p-2 bg-ink/10 font-mono text-[11px] break-all border border-ink/10 text-ink/80">
                      {tel.ciphertext}
                    </div>
                  </div>

                  {tel.isDecrypted ? (
                    <motion.div
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-3 bg-emerald-950/20 border border-emerald-600 font-mono text-xs text-emerald-900"
                    >
                      <div className="flex items-center gap-1.5 text-emerald-700 font-bold mb-1">
                        <Unlock className="w-3.5 h-3.5" />
                        <span>РАСШИФРОВАННЫЙ ТЕКСТ:</span>
                      </div>
                      <p className="leading-snug text-[11px] font-sans font-medium">{tel.plaintext}</p>
                    </motion.div>
                  ) : (
                    <div className="p-3 bg-ink/5 border border-dashed border-ink/20 font-mono text-[11px] text-ink/40 italic flex items-center justify-center gap-2">
                      <Lock className="w-3.5 h-3.5 text-blood" />
                      <span>Шифрование военного класса. Требуется дешифровка.</span>
                    </div>
                  )}
                </div>

                {!tel.isDecrypted && (
                  <button
                    onClick={() => handleDecryptTelegram(tel.id)}
                    className="mt-4 w-full py-2 bg-ink text-paper-light font-mono text-xs uppercase font-bold hover:bg-blood transition-colors flex items-center justify-center gap-2"
                  >
                    <Key className="w-3.5 h-3.5 text-amber-300" />
                    <span>Применить дешифратор</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: CONSPIRACY DOSSIER WITH REDACTIONS */}
      {activeTab === 'conspiracy' && (
        <div className="border border-ink/20 bg-paper-light p-5 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-ink/15 pb-2 mb-4">
            <span className="text-blood font-bold uppercase text-sm">ХРОНИКА ЗАГОВОРА // ДОКЛАД РАЗВЕДКИ «ОМЕГА»</span>
            <span className="text-[10px] text-ink/50">КЛИКАЙТЕ ПО ЧЁРНЫМ МАРКЕРАМ ДЛЯ РАССЕКРЕЧИВАНИЯ</span>
          </div>

          <div className="space-y-4 leading-relaxed font-serif text-sm md:text-base text-ink">
            <p>
              В ночь на{' '}
              <span
                onClick={() => toggleRedaction('date1')}
                className={`cursor-pointer px-1.5 py-0.5 font-mono text-xs font-bold transition-all ${
                  classifiedRedactions['date1']
                    ? 'bg-amber-200 text-ink border border-amber-400'
                    : 'bg-ink text-ink hover:bg-ink/80 select-none'
                }`}
                title="Кликните чтобы рассекретить"
              >
                {classifiedRedactions['date1'] ? '14 ОКТЯБРЯ 1938 ГОДА' : '████████████'}
              </span>
              , командующий 3-й армией генерал{' '}
              <span
                onClick={() => toggleRedaction('name1')}
                className={`cursor-pointer px-1.5 py-0.5 font-mono text-xs font-bold transition-all ${
                  classifiedRedactions['name1']
                    ? 'bg-amber-200 text-ink border border-amber-400'
                    : 'bg-ink text-ink hover:bg-ink/80 select-none'
                }`}
                title="Кликните чтобы рассекретить"
              >
                {classifiedRedactions['name1'] ? 'ФОН БЛЮХЕР' : '██████████'}
              </span>{' '}
              отказался выполнять приказ о бомбардировке города Корсак.
            </p>

            <p>
              По данным контрразведки, он обнаружил в сейфе правительственной дачи документы, доказывающие, что поставки сырья для военной промышленности финансируются через{' '}
              <span
                onClick={() => toggleRedaction('sponsor1')}
                className={`cursor-pointer px-1.5 py-0.5 font-mono text-xs font-bold transition-all ${
                  classifiedRedactions['sponsor1']
                    ? 'bg-blood text-paper-light border border-blood'
                    : 'bg-ink text-ink hover:bg-ink/80 select-none'
                }`}
                title="Кликните чтобы рассекретить"
              >
                {classifiedRedactions['sponsor1'] ? 'МЕЖДУНАРОДНЫЙ БАНКИРСКИЙ КАРТЕЛЬ БАЗЕЛЯ' : '████████████████████████████████'}
              </span>
              , получающий сверхприбыли от затягивания войны на восточном фронте.
            </p>

            <p>
              Генерал скрылся в секретном исследовательском комплексе в{' '}
              <span
                onClick={() => toggleRedaction('loc1')}
                className={`cursor-pointer px-1.5 py-0.5 font-mono text-xs font-bold transition-all ${
                  classifiedRedactions['loc1']
                    ? 'bg-emerald-200 text-emerald-900 border border-emerald-500'
                    : 'bg-ink text-ink hover:bg-ink/80 select-none'
                }`}
                title="Кликните чтобы рассекретить"
              >
                {classifiedRedactions['loc1'] ? 'ШАХТЕ №9 КОРСАКСКОГО КРЯЖА' : '██████████████████'}
              </span>
              , где завершил сборку первого прототипа «Колосс-IX».
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-ink/15 flex items-center justify-between font-mono text-[10px] text-ink/60">
            <span>СТАТУС АРХИВА: ЧАСТИЧНО РАССЕКРЕЧЕНО ПОЛЬЗОВАТЕЛЕМ</span>
            <span className="text-blood font-bold">IRON DOMINION ARCHIVE</span>
          </div>
        </div>
      )}

    </div>
  );
}
