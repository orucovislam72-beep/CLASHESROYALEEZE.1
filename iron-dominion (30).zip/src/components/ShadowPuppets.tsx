import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Eye, DollarSign, Key, ShieldAlert, Cpu, Network, Flame, CheckCircle, Skull, Sparkles } from 'lucide-react';

interface PuppetNode {
  id: string;
  name: string;
  role: string;
  nation: string;
  controlLevel: number; // 0 to 100%
  status: 'puppet' | 'compromised' | 'resisting';
  secretAsset: string;
  costToInfluence: number;
}

const initialNodes: PuppetNode[] = [
  {
    id: 'bank-syndicate',
    name: 'Швейцарский Банкирский Картель',
    role: 'Финансовый монополист',
    nation: 'Международный',
    controlLevel: 85,
    status: 'puppet',
    secretAsset: 'Держит долговые расписки премьер-министра Остена',
    costToInfluence: 50
  },
  {
    id: 'rail-union',
    name: 'Всеобщий Профсоюз Железнодорожников',
    role: 'Транспортный саботаж',
    nation: 'Остенская Империя',
    controlLevel: 60,
    status: 'compromised',
    secretAsset: 'Готов парализовать военные эшелоны по кодовому слову',
    costToInfluence: 35
  },
  {
    id: 'war-minister',
    name: 'Генерал-квартирмейстер фон Краузе',
    role: 'Военное ведомство',
    nation: 'Северная Конфедерация',
    controlLevel: 30,
    status: 'resisting',
    secretAsset: 'Хранит в сейфе списки тайных агентов разведки',
    costToInfluence: 80
  },
  {
    id: 'press-trust',
    name: 'Газетный Синдикат «Голос Нации»',
    role: 'Пропаганда и дезинформация',
    nation: 'Атлантический Союз',
    controlLevel: 75,
    status: 'puppet',
    secretAsset: 'Формирует панику на биржах перед наступлением',
    costToInfluence: 45
  }
];

export default function ShadowPuppets() {
  const [nodes, setNodes] = useState<PuppetNode[]>(initialNodes);
  const [shadowInfluence, setShadowInfluence] = useState<number>(240);
  const [selectedNodeId, setSelectedNodeId] = useState<string>('bank-syndicate');
  const [log, setLog] = useState<string[]>([
    'Теневой орден контролирует 3 ключевых института власти.',
    'Швейцарский картель готов профинансировать переворот.'
  ]);

  const selectedNode = nodes.find(n => n.id === selectedNodeId) || nodes[0];

  const handlePullStrings = (nodeId: string, actionType: 'blackmail' | 'bribe' | 'trigger') => {
    const node = nodes.find(n => n.id === nodeId);
    if (!node || shadowInfluence < node.costToInfluence) return;

    setShadowInfluence(prev => prev - node.costToInfluence);

    let logMessage = '';
    let controlDelta = 15;

    if (actionType === 'trigger') {
      logMessage = `[ПРИКАЗ ИЗ ТЕНИ] Активирован скрытый протокол в организации «${node.name}»! Осуществлён масштабный саботаж.`;
      controlDelta = 25;
    } else if (actionType === 'blackmail') {
      logMessage = `[ШАНТАЖ] Переданы неопровержимые улики руководству «${node.name}». Контроль усилен.`;
      controlDelta = 20;
    } else {
      logMessage = `[ПОДКУП] Золотые сертификаты доставлены эмиссарам «${node.name}». Лояльность ячейки выросла.`;
      controlDelta = 15;
    }

    setNodes(prev => prev.map(n => {
      if (n.id === nodeId) {
        const newCtrl = Math.min(100, n.controlLevel + controlDelta);
        return {
          ...n,
          controlLevel: newCtrl,
          status: newCtrl >= 75 ? 'puppet' : newCtrl >= 45 ? 'compromised' : 'resisting'
        };
      }
      return n;
    }));

    setLog(prev => [logMessage, ...prev.slice(0, 5)]);
  };

  return (
    <div className="w-full bg-paper/60 border border-ink/20 p-4 md:p-6 relative font-sans text-ink">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-2">
        <div className="flex items-center gap-2.5">
          <Eye className="w-5 h-5 text-blood" />
          <div>
            <h3 className="font-serif font-bold text-xl uppercase tracking-tight text-ink">
              Теневой Кабинет // Орден Марионеток
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Дёргайте за нити правительств, банков и синдикатов без объявления войны
            </span>
          </div>
        </div>
        <div className="font-mono text-xs bg-ink text-paper-light px-3 py-1.5 flex items-center gap-2">
          <Key className="w-3.5 h-3.5 text-amber-400" />
          <span>ТЕНЕВОЙ КАПИТАЛ: <strong className="text-amber-300">{shadowInfluence} ОЧКОВ ВЛИЯНИЯ</strong></span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Puppet Nodes List */}
        <div className="lg:col-span-6 flex flex-col gap-3">
          <div className="font-mono text-[10px] uppercase text-ink/60 border-b border-ink/15 pb-1 flex justify-between">
            <span>Агентурные ячейки & Институты</span>
            <span>Уровень контроля</span>
          </div>

          <div className="space-y-2">
            {nodes.map(node => {
              const isSelected = node.id === selectedNodeId;
              return (
                <div
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className={`p-3.5 border cursor-pointer transition-all relative flex flex-col gap-1.5 ${
                    isSelected
                      ? 'bg-ink text-paper-light border-ink shadow-md'
                      : 'bg-paper hover:bg-paper-dark/30 border-ink/20'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-blood" />
                  )}

                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-serif font-bold text-sm">{node.name}</span>
                      <span className={`block font-mono text-[10px] ${isSelected ? 'text-paper-light/70' : 'text-ink/60'}`}>
                        {node.role} • {node.nation}
                      </span>
                    </div>

                    <div className="flex flex-col items-end">
                      <span className={`font-mono text-[10px] uppercase font-bold px-1.5 py-0.2 border ${
                        node.status === 'puppet' ? 'bg-emerald-900/30 text-emerald-600 border-emerald-700/50' :
                        node.status === 'compromised' ? 'bg-amber-900/20 text-amber-600 border-amber-600/40' :
                        'bg-blood/20 text-blood border-blood/50'
                      }`}>
                        {node.status === 'puppet' ? 'МАРИОНЕТКА' : node.status === 'compromised' ? 'ЗАВЕРБОВАН' : 'СОПРОТИВЛЕНИЕ'}
                      </span>
                      <span className="font-mono text-xs font-bold mt-1">{node.controlLevel}%</span>
                    </div>
                  </div>

                  <div className="w-full h-1 bg-ink/20 mt-1">
                    <div
                      className={`h-full transition-all duration-300 ${
                        node.controlLevel >= 75 ? 'bg-emerald-500' :
                        node.controlLevel >= 45 ? 'bg-amber-500' : 'bg-blood'
                      }`}
                      style={{ width: `${node.controlLevel}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-2 flex items-center justify-between bg-ink/5 p-2 border border-ink/15 font-mono text-xs">
            <span className="text-[11px] text-ink/70">Собрать дивиденды с теневых операций:</span>
            <button
              onClick={() => setShadowInfluence(prev => prev + 60)}
              className="px-2 py-1 bg-paper border border-ink text-[10px] uppercase font-bold hover:bg-ink hover:text-paper-light transition-colors"
            >
              +60 Влияния
            </button>
          </div>
        </div>

        {/* Right: Puppet Master Control Deck */}
        <div className="lg:col-span-6 border border-ink/30 bg-paper-light p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-ink/15 pb-2 mb-3">
              <span className="font-mono text-[10px] text-stamp border border-stamp px-1.5 uppercase font-bold">
                TOP SECRET DOSSIER // PUPPET NODE
              </span>
              <span className="font-mono text-[10px] text-ink/50">NODE ID: #{selectedNode.id}</span>
            </div>

            <h4 className="font-serif font-bold text-xl uppercase mb-1 text-ink">
              {selectedNode.name}
            </h4>
            <div className="font-mono text-xs text-ink/70 mb-3">
              {selectedNode.role} // Государство: {selectedNode.nation}
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="bg-ink/5 p-2.5 border border-ink/15">
                <span className="text-[10px] uppercase text-ink/50 block mb-1">Скрытый компрометирующий актив:</span>
                <span className="text-blood font-medium">"{selectedNode.secretAsset}"</span>
              </div>

              <div>
                <div className="flex justify-between text-[10px] uppercase mb-0.5">
                  <span>Степень контроля марионетки:</span>
                  <span className="font-bold text-ink">{selectedNode.controlLevel}%</span>
                </div>
                <div className="w-full h-2 bg-ink/15">
                  <div
                    className={`h-full transition-all duration-300 ${
                      selectedNode.controlLevel >= 75 ? 'bg-emerald-600' :
                      selectedNode.controlLevel >= 45 ? 'bg-amber-600' : 'bg-blood'
                    }`}
                    style={{ width: `${selectedNode.controlLevel}%` }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Action Operations */}
          <div className="mt-4 pt-3 border-t border-ink/20">
            <span className="font-mono text-[10px] uppercase tracking-wider text-ink/60 block mb-2">
              Оперативные приказы из тени (Расход: {selectedNode.costToInfluence} очков):
            </span>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => handlePullStrings(selectedNode.id, 'bribe')}
                disabled={shadowInfluence < selectedNode.costToInfluence}
                className="px-2 py-2 bg-paper border border-ink/40 font-mono text-[10px] uppercase hover:bg-ink hover:text-paper-light transition-all flex flex-col items-center gap-1 disabled:opacity-40"
              >
                <DollarSign className="w-3.5 h-3.5 text-amber-600" />
                <span>Подкуп</span>
              </button>

              <button
                onClick={() => handlePullStrings(selectedNode.id, 'blackmail')}
                disabled={shadowInfluence < selectedNode.costToInfluence}
                className="px-2 py-2 bg-paper border border-ink/40 font-mono text-[10px] uppercase hover:bg-ink hover:text-paper-light transition-all flex flex-col items-center gap-1 disabled:opacity-40"
              >
                <Key className="w-3.5 h-3.5 text-blood" />
                <span>Шантаж</span>
              </button>

              <button
                onClick={() => handlePullStrings(selectedNode.id, 'trigger')}
                disabled={shadowInfluence < selectedNode.costToInfluence}
                className="px-2 py-2 bg-blood text-paper-light border border-blood font-mono text-[10px] uppercase font-bold hover:bg-ink hover:border-ink transition-all flex flex-col items-center gap-1 disabled:opacity-40"
              >
                <Flame className="w-3.5 h-3.5 text-amber-300" />
                <span>Саботаж</span>
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* Secret Orders Feed */}
      <div className="mt-4 bg-ink text-paper-light p-3 font-mono text-xs border border-ink">
        <div className="text-[10px] uppercase tracking-wider text-paper/60 border-b border-paper/20 pb-1 mb-2 flex justify-between">
          <span>Шифровки Тайной Ложи // Global Conspiracy Wire</span>
          <span className="text-amber-400">EYES ONLY</span>
        </div>
        <div className="space-y-1 max-h-20 overflow-y-auto">
          {log.map((entry, idx) => (
            <div key={idx} className="text-[11px] leading-snug">
              <span className="text-amber-400 mr-1.5">◆</span>
              <span>{entry}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
