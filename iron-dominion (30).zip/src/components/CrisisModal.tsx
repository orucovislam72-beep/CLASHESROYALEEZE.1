import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, ShieldAlert, ArrowRight, Clock, Skull, Check, Cpu, Sparkles } from 'lucide-react';
import { ActiveCrisisModal } from '../utils/gameState';
import { gameStore } from '../utils/gameStore';
import { audioEngine } from '../utils/audioEngine';
import { routeAIRequest } from '../utils/aiRouter';

interface CrisisModalProps {
  crisis: ActiveCrisisModal | null;
}

export default function CrisisModal({ crisis }: CrisisModalProps) {
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  if (!crisis) return null;

  const handleSelectOption = (optionId: string) => {
    gameStore.resolveCrisis(optionId);
  };

  const getAiAdvice = async () => {
    setIsAiLoading(true);
    setAiAdvice(null);
    audioEngine.playTuningSweep();

    try {
      const prompt = `СРОЧНАЯ КРИЗИСНАЯ СИТУАЦИЯ: ${crisis.title}.
      Описание: ${crisis.description}.
      Степень угрозы: ${crisis.severity}.
      
      Доступные варианты действий:
      ${crisis.options.map((o, i) => `${i + 1}. ${o.text}`).join('\n')}
      
      Как эксперт-стратег, проанализируй ситуацию и посоветуй лучший выбор. Учти долгосрочные последствия.
      Ответ дай в формате JSON: { "advice": "текст совета", "bestOptionIndex": номер_варианта }`;

      const result = await routeAIRequest({
        prompt,
        urgency: 'critical', 
        isKeyMoment: true
      });

      setAiAdvice(result.advice);
    } catch (error) {
      console.error("Crisis AI failed:", error);
      setAiAdvice("Связь с аналитическим отделом прервана.");
    } finally {
      setIsAiLoading(false);
    }
  };

    const isOpportunity = crisis.severity === 'opportunity' || crisis.category === 'science';
  const isEvent = crisis.severity === 'event' || crisis.category === 'peacetime';
  
  const themeBg = isOpportunity ? 'bg-emerald-500/10' : (isEvent ? 'bg-sky-500/10' : 'bg-blood/10');
  const themeBgSolid = isOpportunity ? 'bg-emerald-500' : (isEvent ? 'bg-sky-500' : 'bg-blood');
  const themeBorder = isOpportunity ? 'border-emerald-500/30' : (isEvent ? 'border-sky-500/30' : 'border-blood/30');
  const themeText = isOpportunity ? 'text-emerald-400' : (isEvent ? 'text-sky-400' : 'text-blood');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-xs font-mono">
      <motion.div
        initial={{ opacity: 0, scale: 0.94, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 20 }}
        transition={{ duration: 0.3 }}
        className={`w-full max-w-2xl bg-[#1c1815] text-paper-light border-4 ${themeBorder} shadow-2xl flex flex-col relative overflow-hidden`}
      >
        {/* Urgent Header */}
        <div className={`${themeBgSolid} text-paper-light p-3 sm:p-4 flex items-center justify-between border-b-2 border-amber-300`}>
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-amber-300 animate-pulse" />
            <div>
              <span className="text-xs uppercase tracking-widest text-amber-300 font-bold block">
                {crisis.stamp}
              </span>
              <h2 className="text-base sm:text-lg font-bold tracking-tight">
                {crisis.title}
              </h2>
            </div>
          </div>

          <span className="px-2 py-0.5 bg-ink text-amber-300 text-[10px] font-bold border border-amber-400">
            СТАВКА ВГК
          </span>
        </div>

        {/* Origin Report */}
        <div className="bg-paper/10 border-b border-paper/15 p-2.5 px-4 text-xs text-amber-200 flex items-center justify-between">
          <span>Источник: <strong>{crisis.origin}</strong></span>
          <span className="text-[10px] text-paper/60 uppercase">ТРЕБУЕТСЯ РЕЗОЛЮЦИЯ</span>
        </div>

        {/* Narrative Description */}
        <div className="p-4 sm:p-6 font-serif text-sm sm:text-base text-paper-light/95 leading-relaxed bg-[#25201c] border-b border-paper/15">
          <p className="italic">
            «{crisis.description}»
          </p>

          {/* AI Strategic Advisory */}
          <div className="mt-4 p-3 bg-ink/40 border border-amber-500/20 rounded-sm font-mono">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-[10px] uppercase text-amber-300/60 font-bold flex items-center gap-1.5">
                <Cpu className="w-3 h-3 text-amber-500" /> АНАЛИТИКА: GEMINI STRATEGIC ADVISOR
              </h4>
              {!aiAdvice && (
                <button 
                  onClick={getAiAdvice}
                  disabled={isAiLoading}
                  className="px-2 py-0.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-[9px] text-amber-200 uppercase transition-all disabled:opacity-50"
                >
                  {isAiLoading ? 'Просчет вариантов...' : 'Запросить анализ'}
                </button>
              )}
            </div>
            
            {aiAdvice ? (
              <div className="text-[11px] leading-relaxed text-paper/90 font-sans italic animate-in fade-in zoom-in-95">
                <Sparkles className="w-3 h-3 text-amber-400 inline mr-2" />
                {aiAdvice}
              </div>
            ) : (
              <div className="text-[9px] text-paper/30 italic">В критических ситуациях рекомендуется консультация с расширенным стратегическим ИИ.</div>
            )}
          </div>
        </div>

        {/* Strategic Directives Selection */}
        <div className="p-4 sm:p-6 space-y-3 bg-[#171412]">
          <div className="text-xs font-mono font-bold uppercase text-amber-300 tracking-wider mb-1">
            ВЫБЕРИТЕ ДИРЕКТИВУ ГЛАВНОКОМАНДУЮЩЕГО:
          </div>

          {crisis.options.map((opt, idx) => (
            <button
              key={opt.id}
              onClick={() => handleSelectOption(opt.id)}
              className="w-full p-3.5 bg-paper/10 hover:bg-paper/20 border-2 border-paper/30 hover:border-amber-300 text-left transition-all group flex flex-col gap-1.5 active:translate-y-0.5"
            >
              <div className="flex items-center justify-between text-xs sm:text-sm font-bold text-amber-200 group-hover:text-amber-100 font-serif">
                <span>{idx + 1}. {opt.text}</span>
                <ArrowRight className="w-4 h-4 text-amber-400 opacity-0 group-hover:opacity-100 transition-opacity shrink-0 ml-2" />
              </div>

              <div className="text-xs text-paper/80 font-mono">
                {opt.consequenceDesc}
              </div>

              <div className="flex items-center justify-between text-[11px] text-paper/60 font-mono pt-1 border-t border-paper/10">
                <span className="text-amber-300">{opt.costDesc}</span>
                {opt.deferredEffect && (
                  <span className="text-cyan-300 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    Последствие через {opt.deferredEffect.daysDelay} дн.
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="bg-ink p-2.5 px-4 flex items-center justify-between text-[11px] text-paper/50">
          <span>Решение вступает в силу немедленно и будет внесено в Хронику Мира.</span>
          <span className="uppercase text-[9px]">DIREKTIVE DER OBERSTEN HEERESLEITUNG</span>
        </div>
      </motion.div>
    </div>
  );
}
