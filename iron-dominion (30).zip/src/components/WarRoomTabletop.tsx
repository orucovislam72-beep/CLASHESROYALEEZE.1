import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Swords, Shield, CloudRain, CloudFog, Sun, Snowflake, Play, RotateCcw, AlertTriangle, ArrowRight, ShieldCheck, Flame, Compass, Crosshair, Flag, Users, Cpu, Volume2, Database, Sparkles, RefreshCw, Search } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';
import { gameStore } from '../utils/gameStore';
import { routeAIRequest } from '../utils/aiRouter';

export type WeatherType = 'clear' | 'mud' | 'fog' | 'winter';
export type DoctrinePlan = 'pincer' | 'barrage' | 'deep_strike' | 'defense';

interface DivisionUnit {
  id: string;
  name: string;
  type: 'armor' | 'infantry' | 'artillery' | 'air';
  strength: number; // 0-100%
  morale: number;   // 0-100%
  ammo: number;     // 0-100%
  x: number;        // grid coordinate
  y: number;
  targetX?: number;
  targetY?: number;
  status: 'ready' | 'advancing' | 'engaged' | 'retreated';
  kills: number;
}

interface EnemyDivision {
  id: string;
  name: string;
  type: 'armor' | 'infantry' | 'fort';
  strength: number;
  entrenchment: number; // 0-100%
  x: number;
  y: number;
  status: 'entrenched' | 'counter_attacking' | 'encircled' | 'destroyed';
}

const initialAlliedUnits: DivisionUnit[] = [
  {
    id: 'u1',
    name: '1-я Танковая Группа «Молот»',
    type: 'armor',
    strength: 95,
    morale: 90,
    ammo: 85,
    x: 20,
    y: 70,
    status: 'ready',
    kills: 0
  },
  {
    id: 'u2',
    name: '4-й Гвардейский Пехотный Корпус',
    type: 'infantry',
    strength: 100,
    morale: 85,
    ammo: 90,
    x: 45,
    y: 78,
    status: 'ready',
    kills: 0
  },
  {
    id: 'u3',
    name: '7-й Тяжёлый Гаубичный Полк',
    type: 'artillery',
    strength: 88,
    morale: 92,
    ammo: 95,
    x: 75,
    y: 82,
    status: 'ready',
    kills: 0
  }
];

const initialEnemyUnits: EnemyDivision[] = [
  {
    id: 'e1',
    name: '8-я Пехотная Дивизия «Зюйд»',
    type: 'infantry',
    strength: 85,
    entrenchment: 70,
    x: 35,
    y: 35,
    status: 'entrenched'
  },
  {
    id: 'e2',
    name: 'Укрепрайон «Линия Валленштейна»',
    type: 'fort',
    strength: 100,
    entrenchment: 95,
    x: 60,
    y: 25,
    status: 'entrenched'
  },
  {
    id: 'e3',
    name: 'Бронегруппа резерва Корсака',
    type: 'armor',
    strength: 80,
    entrenchment: 40,
    x: 78,
    y: 40,
    status: 'entrenched'
  }
];

export default function WarRoomTabletop() {
  const [allies, setAllies] = useState<DivisionUnit[]>(initialAlliedUnits);
  const [enemies, setEnemies] = useState<EnemyDivision[]>(initialEnemyUnits);
  const [weather, setWeather] = useState<WeatherType>('clear');
  const [plan, setPlan] = useState<DoctrinePlan>('pincer');
  const [selectedUnitId, setSelectedUnitId] = useState<string>('u1');
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [turn, setTurn] = useState<number>(1);
  const [battleLogs, setBattleLogs] = useState<string[]>([
    '[06:00] Генеральный Штаб развернул карту ТВД «Остенмаркский прорыв».',
    '[06:15] Разведка докладывает: вражеская линия обороны усилена бетонными ДОТами.',
    '[06:30] Выберите директиву наступления и отдайте приказ первой линии.'
  ]);
  const [aiStrategicAdvice, setAiStrategicAdvice] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const selectedUnit = allies.find(u => u.id === selectedUnitId) || allies[0];

  const getAIAdvice = async () => {
    setIsAiLoading(true);
    setAiStrategicAdvice(null);
    audioEngine.playTuningSweep();

    try {
      const prompt = `ГЕНЕРАЛЬНЫЙ ШТАБ: Оценка оперативной обстановки.
      Погода: ${weather}.
      Доктрина: ${plan}.
      Наши силы: ${allies.length} дивизий. Средняя прочность: ${Math.round(allies.reduce((a, b) => a + b.strength, 0) / allies.length)}%.
      Силы врага: ${enemies.length} укрепленных районов.
      
      Проанализируй шансы на успех операции и дай тактические рекомендации по текущей доктрине.
      Ответ дай в формате JSON: { "advice": "текст рекомендации", "successProbability": "X%", "threatAssessment": "текст" }`;

      const result = await routeAIRequest({
        prompt,
        urgency: 'medium',
        isKeyMoment: false
      });

      setAiStrategicAdvice(`ОТЧЕТ РАЗВЕДКИ: Шанс успеха ${result.successProbability}. ${result.advice}`);
    } catch (error) {
      console.error("War Room AI failed:", error);
      setAiStrategicAdvice("Ошибка связи с полевой разведкой.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSelectPlan = (newPlan: DoctrinePlan) => {
    setPlan(newPlan);
    audioEngine.playMorseBeep(false);
    let desc = '';
    if (newPlan === 'pincer') desc = 'Директива «Клещи»: фланговый охват танками с изоляцией укрепрайона.';
    if (newPlan === 'barrage') desc = 'Директива «Огневой Вал»: 4 часа артподготовки перед броском пехоты.';
    if (newPlan === 'deep_strike') desc = 'Директива «Глубокая Операция»: танковый клин прямо в тыловые склады врага.';
    if (newPlan === 'defense') desc = 'Директива «Подвижная Оборона»: заманивание врага под огонь гаубиц.';
    setBattleLogs(prev => [`[ПРИКАЗ] ${desc}`, ...prev.slice(0, 7)]);
  };

  const handleSelectWeather = (w: WeatherType) => {
    setWeather(w);
    audioEngine.playTuningSweep();
  };

  const handleSimulateTurn = () => {
    setIsSimulating(true);
    audioEngine.setTheme('orchestral');
    audioEngine.playMorseBeep(true);

    const nextTurn = turn + 1;
    setTurn(nextTurn);

    // Call unified grand strategy simulation offensive
    gameStore.launchWarRoomOffensive('ostenmark', plan);

    setTimeout(() => {
      // Calculation of battle results based on weather & doctrine
      const weatherModifier = weather === 'mud' ? 0.6 : (weather === 'winter' ? 0.75 : 1.0);
      const isBarrage = plan === 'barrage';
      const isPincer = plan === 'pincer';

      // Update Enemies
      setEnemies(prev => prev.map(e => {
        let dmg = Math.floor((Math.random() * 25 + 15) * weatherModifier);
        if (isBarrage && e.type === 'fort') dmg += 25;
        if (isPincer && e.id === 'e1') dmg += 20;

        const newStrength = Math.max(0, e.strength - dmg);
        const newStatus = newStrength === 0 ? 'destroyed' : (isPincer && e.id === 'e1' ? 'encircled' : e.status);
        return {
          ...e,
          strength: newStrength,
          entrenchment: Math.max(0, e.entrenchment - Math.floor(dmg * 0.7)),
          status: newStatus
        };
      }));

      // Update Allies
      setAllies(prev => prev.map(u => {
        const ammoSpent = Math.floor(Math.random() * 15 + 10);
        const loss = Math.floor(Math.random() * 12 + (weather === 'mud' ? 8 : 4));
        const newAmmo = Math.max(10, u.ammo - ammoSpent);
        const newStrength = Math.max(20, u.strength - loss);
        const newMorale = Math.min(100, Math.max(30, u.morale + (isPincer ? 5 : -2)));

        return {
          ...u,
          ammo: newAmmo,
          strength: newStrength,
          morale: newMorale,
          status: newStrength < 35 ? 'retreated' : 'engaged',
          kills: u.kills + Math.floor(Math.random() * 8 + 4)
        };
      }));

      // Add log
      const logMessage = `[Ход ${nextTurn} // 08:30] Бой в разгаре. 1-я Танковая продвинулась на 14 км. Вражеская 8-я дивизия понесла тяжёлые потери. Списано: 350 барр. топлива, 400т снарядов. Запись внесена в Хронику.`;
      setBattleLogs(prev => [logMessage, ...prev.slice(0, 7)]);
      setIsSimulating(false);
    }, 1200);
  };

  const handleResetBattle = () => {
    setAllies(initialAlliedUnits);
    setEnemies(initialEnemyUnits);
    setTurn(1);
    setBattleLogs([
      '[ПЕРЕГРУППИРОВКА] Войска вернулись на исходные рубежи фронта.',
      '[06:00] Готовность к началу новой войсковой операции.'
    ]);
    audioEngine.playMorseBeep(false);
  };

  return (
    <div className="w-full bg-paper/90 border-2 border-ink p-4 md:p-6 font-sans text-ink relative shadow-[4px_4px_0_var(--color-ink)]">
      
      {/* Tabletop Top Header Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-4 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-ink text-paper-light flex items-center justify-center border border-ink">
            <Swords className="w-6 h-6 text-blood" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-xl md:text-2xl uppercase tracking-tight text-ink">
              Тактический Штабной Стол // ТВД «Остенмарк»
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Деревянные дивизионные маркеры, направления ударов и симуляция прорыва
            </span>
          </div>
        </div>

        {/* Turn Counter & Reset */}
        <div className="flex items-center gap-2">
          <div className="bg-ink text-paper-light px-3 py-1 font-mono text-xs font-bold border border-ink">
            ОПЕРАТИВНЫЙ ХОД #{turn}
          </div>
          <button
            onClick={handleResetBattle}
            className="p-1.5 border border-ink/40 bg-paper hover:bg-ink hover:text-paper-light transition-colors text-ink"
            title="Сбросить позиции войск"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Left Tactical Table, Right Operational Directives */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left: Interactive Canvas Map Table (8 Cols) */}
        <div className="lg:col-span-8 flex flex-col gap-3">
          
          {/* Tactical Tabletop Felt Canvas */}
          <div className="relative w-full aspect-[16/10] bg-[#3a4436] border-4 border-[#2b1d14] shadow-[inset_0_0_30px_rgba(0,0,0,0.6)] rounded-sm overflow-hidden select-none">
            
            {/* Topographic Map Grid Lines & Contours */}
            <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
              {/* Grid */}
              <defs>
                <pattern id="warGrid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#fff" strokeWidth="0.3" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#warGrid)" />
              {/* River Vorne */}
              <path d="M0,45 Q30,55 50,42 T100,50" fill="none" stroke="#6b9ebd" strokeWidth="2.5" />
              {/* Elevation 142 Hill contour */}
              <ellipse cx="60" cy="25" rx="14" ry="9" fill="none" stroke="#d4c59a" strokeWidth="0.8" strokeDasharray="1,1" />
              <ellipse cx="60" cy="25" rx="8" ry="5" fill="none" stroke="#d4c59a" strokeWidth="0.6" />
            </svg>

            {/* Weather Overlay Effect */}
            {weather === 'mud' && (
              <div className="absolute inset-0 bg-[#4a3525]/30 pointer-events-none flex items-center justify-center">
                <span className="font-mono text-xs uppercase text-amber-200/50 tracking-widest font-bold">ОСЕННЯЯ РАСПУТИЦА // СКОРОСТЬ БРОНЕТЕХНИКИ -50%</span>
              </div>
            )}
            {weather === 'fog' && (
              <div className="absolute inset-0 bg-slate-200/30 backdrop-blur-[1px] pointer-events-none flex items-center justify-center">
                <span className="font-mono text-xs uppercase text-slate-100/70 tracking-widest font-bold">ФРОНТОВОЙ ТУМАН // АВИАНАЛЁТЫ НЕДОСТУПНЫ</span>
              </div>
            )}
            {weather === 'winter' && (
              <div className="absolute inset-0 bg-blue-100/20 pointer-events-none flex items-center justify-center">
                <span className="font-mono text-xs uppercase text-blue-200/70 tracking-widest font-bold">СУРОВЫЙ БУРАН // ПОВЫШЕННЫЙ РАСХОД ПРИПАСОВ</span>
              </div>
            )}

            {/* Frontline Trench Marker (Фронтовая линия) */}
            <div className="absolute top-[48%] left-0 right-0 h-[2px] bg-blood/60 border-t border-dashed border-red-300 pointer-events-none">
              <span className="absolute -top-3 left-4 font-mono text-[8px] uppercase tracking-widest text-red-300 bg-black/60 px-1">
                ГЛАВНАЯ ЛИНИЯ СОПРИКОСНОВЕНИЯ
              </span>
            </div>

            {/* Doctrine Attack Arrow Vectors */}
            {plan === 'pincer' && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-10" viewBox="0 0 100 100">
                {/* Left Flank Hook */}
                <path d="M 25 65 Q 15 45 32 35" fill="none" stroke="#e63946" strokeWidth="2" strokeDasharray="3,1" markerEnd="url(#arrow)" />
                {/* Right Flank Hook */}
                <path d="M 75 75 Q 88 50 65 30" fill="none" stroke="#e63946" strokeWidth="2" strokeDasharray="3,1" />
                <circle cx="35" cy="35" r="8" fill="none" stroke="#e63946" strokeWidth="0.8" strokeDasharray="1,1" />
              </svg>
            )}

            {plan === 'barrage' && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-10" viewBox="0 0 100 100">
                <line x1="75" y1="80" x2="60" y2="28" stroke="#ffb703" strokeWidth="1.5" strokeDasharray="2,2" />
                <line x1="75" y1="80" x2="35" y2="36" stroke="#ffb703" strokeWidth="1.5" strokeDasharray="2,2" />
                <circle cx="60" cy="25" r="10" fill="none" stroke="#ffb703" strokeWidth="1.2" className="animate-ping" />
              </svg>
            )}

            {plan === 'deep_strike' && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-10" viewBox="0 0 100 100">
                <path d="M 25 65 L 50 15" fill="none" stroke="#e63946" strokeWidth="3" markerEnd="url(#arrow)" />
              </svg>
            )}

            {/* ENEMY WOODEN BLOCKS (Красные/Черные фишки) */}
            {enemies.map(enemy => (
              <motion.div
                key={enemy.id}
                style={{ top: `${enemy.y}%`, left: `${enemy.x}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 transition-all ${
                  enemy.status === 'destroyed' ? 'opacity-30 grayscale' : ''
                }`}
              >
                <div className="bg-[#1f1b18] text-[#e0cfb8] border-2 border-[#8b2626] p-1.5 shadow-[3px_4px_6px_rgba(0,0,0,0.6)] flex flex-col items-center min-w-[70px] sm:min-w-[90px] rounded-sm">
                  <div className="flex items-center gap-1 w-full justify-between border-b border-[#8b2626]/40 pb-0.5 mb-1 font-mono text-[8px]">
                    <span className="text-red-400 font-bold uppercase truncate">{enemy.type === 'fort' ? 'ДОТ' : 'ВРАГ'}</span>
                    <span className="text-amber-300">{enemy.strength}%</span>
                  </div>
                  <span className="font-serif font-bold text-[9px] sm:text-[10px] text-center leading-tight truncate max-w-[80px]">
                    {enemy.name}
                  </span>
                  {enemy.status === 'encircled' && (
                    <span className="font-mono text-[7px] bg-red-900 text-red-200 px-1 mt-0.5 uppercase font-bold animate-pulse">
                      В КОЛЬЦЕ
                    </span>
                  )}
                  {enemy.status === 'destroyed' && (
                    <span className="font-mono text-[7px] bg-black text-white px-1 mt-0.5 uppercase">
                      УНИЧТОЖЕН
                    </span>
                  )}
                </div>
              </motion.div>
            ))}

            {/* ALLIED WOODEN BLOCKS (Наши деревянные фишки) */}
            {allies.map(unit => {
              const isSelected = unit.id === selectedUnitId;
              return (
                <motion.div
                  key={unit.id}
                  onClick={() => { setSelectedUnitId(unit.id); audioEngine.playMorseBeep(false); }}
                  style={{ top: `${unit.y}%`, left: `${unit.x}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 cursor-pointer z-30 transition-transform ${
                    isSelected ? 'scale-110' : 'hover:scale-105'
                  }`}
                >
                  <div className={`p-1.5 shadow-[4px_6px_10px_rgba(0,0,0,0.7)] flex flex-col items-center min-w-[75px] sm:min-w-[100px] border-2 transition-all rounded-sm ${
                    isSelected 
                      ? 'bg-[#d8c5a4] text-ink border-blood ring-2 ring-amber-400' 
                      : 'bg-[#bfa780] text-ink border-[#5c4426]'
                  }`}>
                    {/* Wooden Grain simulation bar */}
                    <div className="flex items-center gap-1 w-full justify-between border-b border-ink/20 pb-0.5 mb-1 font-mono text-[8px]">
                      <span className="font-bold uppercase text-blood flex items-center gap-1">
                        {unit.type === 'armor' && <Shield className="w-2.5 h-2.5 text-blood fill-blood/30" />}
                        {unit.type === 'infantry' && <Users className="w-2.5 h-2.5 text-amber-900" />}
                        {unit.type === 'artillery' && <Crosshair className="w-2.5 h-2.5 text-red-800" />}
                        {unit.type === 'air' && <Compass className="w-2.5 h-2.5 text-sky-800" />}
                        <span>{unit.type === 'armor' ? 'ТАНК' : unit.type === 'infantry' ? 'ПЕХОТА' : unit.type === 'artillery' ? 'АРТИЛЛЕРИЯ' : 'АВИАЦИЯ'}</span>
                      </span>
                      <span className="font-bold text-ink">{unit.strength}%</span>
                    </div>
                    <span className="font-serif font-bold text-[9px] sm:text-[10px] text-center leading-tight truncate max-w-[90px]">
                      {unit.name}
                    </span>
                    {/* Small stats pips */}
                    <div className="flex gap-1 mt-1 w-full justify-between text-[7px] font-mono text-ink/70">
                      <span>БОЕЗАПАС: {unit.ammo}%</span>
                      <span>МОРАЛЬ: {unit.morale}%</span>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Tabletop Control Buttons: Weather & Execution */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Weather Selector */}
            <div className="bg-ink/5 p-2.5 border border-ink/20 font-mono text-xs flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-ink/60">Фронтовая погода:</span>
              <div className="flex gap-1">
                <button
                  onClick={() => handleSelectWeather('clear')}
                  className={`p-1.5 border transition-all ${weather === 'clear' ? 'bg-ink text-paper-light border-ink font-bold' : 'bg-paper hover:bg-ink/10'}`}
                  title="Ясно (Обычные условия)"
                >
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                </button>
                <button
                  onClick={() => handleSelectWeather('mud')}
                  className={`p-1.5 border transition-all ${weather === 'mud' ? 'bg-ink text-paper-light border-ink font-bold' : 'bg-paper hover:bg-ink/10'}`}
                  title="Распутица (Танки замедлены)"
                >
                  <CloudRain className="w-3.5 h-3.5 text-amber-700" />
                </button>
                <button
                  onClick={() => handleSelectWeather('fog')}
                  className={`p-1.5 border transition-all ${weather === 'fog' ? 'bg-ink text-paper-light border-ink font-bold' : 'bg-paper hover:bg-ink/10'}`}
                  title="Фронтовой туман (Скрытность)"
                >
                  <CloudFog className="w-3.5 h-3.5 text-slate-500" />
                </button>
                <button
                  onClick={() => handleSelectWeather('winter')}
                  className={`p-1.5 border transition-all ${weather === 'winter' ? 'bg-ink text-paper-light border-ink font-bold' : 'bg-paper hover:bg-ink/10'}`}
                  title="Зимний буран (Расход припасов x2)"
                >
                  <Snowflake className="w-3.5 h-3.5 text-blue-500" />
                </button>
              </div>
            </div>

            {/* Execute Turn Button */}
            <button
              onClick={handleSimulateTurn}
              disabled={isSimulating}
              className="w-full py-2.5 px-4 bg-blood text-paper-light font-mono text-xs uppercase font-bold hover:bg-ink transition-all flex items-center justify-center gap-2 shadow-[2px_2px_0_var(--color-ink)] active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-50"
            >
              {isSimulating ? (
                <>
                  <Crosshair className="w-4 h-4 animate-spin text-amber-300" />
                  <span>ИДЁТ СИМУЛЯЦИЯ АРТОБСТРЕЛА...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 text-amber-300 fill-amber-300" />
                  <span>Отдать приказ: Начать фазу наступления</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right: Operational Directives & Tactical Logs (4 Cols) */}
        <div className="lg:col-span-4 flex flex-col gap-3">
          
          {/* Doctrine Plan Selection */}
          <div className="bg-paper-light border border-ink/20 p-3 font-mono text-xs">
            <span className="text-[10px] uppercase font-bold text-ink/50 block border-b border-ink/15 pb-1 mb-2">
              Штабные Директивы Прорыва:
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { id: 'pincer', label: '«Клещи»', desc: 'Фланговый охват' },
                { id: 'barrage', label: '«Огневой Вал»', desc: 'Артподготовка' },
                { id: 'deep_strike', label: '«Глубокий Клин»', desc: 'Тыл врага' },
                { id: 'defense', label: '«Засада»', desc: 'Подвижный рубеж' }
              ].map(d => (
                <button
                  key={d.id}
                  onClick={() => handleSelectPlan(d.id as DoctrinePlan)}
                  className={`p-2 text-left border transition-all flex flex-col ${
                    plan === d.id
                      ? 'bg-ink text-paper-light border-blood shadow-sm'
                      : 'bg-paper hover:bg-ink/5 border-ink/15 text-ink'
                  }`}
                >
                  <span className="font-bold text-[11px] leading-tight">{d.label}</span>
                  <span className={`text-[8px] mt-0.5 ${plan === d.id ? 'text-amber-300' : 'text-ink/50'}`}>{d.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Selected Unit Dossier */}
          <div className="bg-paper-light border border-ink/20 p-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-ink/15 pb-1 mb-2">
              <span className="text-[10px] uppercase font-bold text-blood">Досье подразделения</span>
              <span className="text-[9px] text-ink/50">ID: #{selectedUnit.id.toUpperCase()}</span>
            </div>
            <div className="font-serif font-bold text-base text-ink mb-2">
              {selectedUnit.name}
            </div>
            <div className="space-y-1.5 text-[10px]">
              <div className="flex justify-between">
                <span className="text-ink/60">Боеспособность:</span>
                <span className="font-bold text-ink">{selectedUnit.strength}%</span>
              </div>
              <div className="w-full bg-ink/10 h-1.5 rounded-full overflow-hidden">
                <div className="bg-emerald-600 h-full" style={{ width: `${selectedUnit.strength}%` }} />
              </div>

              <div className="flex justify-between">
                <span className="text-ink/60">Боекомплект:</span>
                <span className="font-bold text-ink">{selectedUnit.ammo}%</span>
              </div>
              <div className="w-full bg-ink/10 h-1.5 rounded-full overflow-hidden">
                <div className="bg-amber-600 h-full" style={{ width: `${selectedUnit.ammo}%` }} />
              </div>

              <div className="flex justify-between">
                <span className="text-ink/60">Моральный дух:</span>
                <span className="font-bold text-ink">{selectedUnit.morale}%</span>
              </div>
              <div className="w-full bg-ink/10 h-1.5 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full" style={{ width: `${selectedUnit.morale}%` }} />
              </div>
            </div>
          </div>

          {/* AI Strategic Advisor */}
          <div className="bg-paper/10 border border-ink/10 p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <h4 className="text-[10px] uppercase text-ink/50 font-bold flex items-center gap-1.5">
                <Cpu className="w-3 h-3 text-blood" /> Стратегический ИИ
              </h4>
              <button 
                onClick={getAIAdvice}
                disabled={isAiLoading || isSimulating}
                className="p-1 px-2 bg-ink text-paper-light text-[9px] uppercase hover:bg-blood transition-all disabled:opacity-50 flex items-center gap-1.5"
              >
                {isAiLoading ? <RefreshCw className="w-2.5 h-2.5 animate-spin" /> : <Search className="w-2.5 h-2.5" />}
                Анализ ТВД
              </button>
            </div>
            
            {aiStrategicAdvice ? (
              <div className="p-2 bg-paper/50 border border-ink/5 text-[10px] font-sans leading-relaxed text-ink/80 italic animate-in fade-in zoom-in-95">
                <Sparkles className="w-3 h-3 text-blood inline mr-1" />
                {aiStrategicAdvice}
              </div>
            ) : (
              <div className="text-[9px] text-ink/30 italic">Рекомендуется провести анализ перед началом фазы наступления.</div>
            )}
          </div>

          {/* Battle Logs Stream */}
          <div className="bg-ink text-paper-light p-3 border border-ink font-mono text-xs flex-1 flex flex-col">
            <div className="flex items-center justify-between border-b border-paper/20 pb-1 mb-2">
              <span className="text-[10px] uppercase font-bold text-amber-300 flex items-center gap-1.5">
                <Compass className="w-3 h-3 text-blood" />
                Сводки телеграфа ставки
              </span>
              <span className="text-[9px] text-paper/40">LIVE</span>
            </div>
            <div className="space-y-1.5 overflow-y-auto max-h-[140px] text-[10px] text-paper-light/85 leading-snug">
              {battleLogs.map((log, idx) => (
                <div key={idx} className="border-l border-blood/60 pl-1.5 py-0.5">
                  {log}
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
