import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { gameStore } from '../utils/gameStore';
import { GameState } from '../utils/gameState';
import { ChevronRight, Target, Shield, AlertTriangle } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface Step {
  id: string;
  title: string;
  text: string;
  requireCondition?: (state: GameState, activeTabId: string) => boolean;
  onEnter?: () => void;
}

const STEPS: Step[] = [
  { 
    id: 'welcome', 
    title: 'ВХОДЯЩАЯ СВЯЗЬ', 
    text: 'Главнокомандующий, добро пожаловать в Ставку. Я — ваш личный адъютант. Позвольте кратко ввести вас в курс дела, пока ситуация на фронте стабильна.' 
  },
  { 
    id: 'resources', 
    title: 'СНАБЖЕНИЕ И СТАБИЛЬНОСТЬ', 
    text: 'В верхней панели отображаются жизненно важные показатели: Казна, Нефть, Сталь и Стабильность. Это кровь нашей военной машины. Внимательно следите за их приростом (зеленый) и убытком (красный). Упадет стабильность — начнется мятеж.' 
  },
  { 
    id: 'map', 
    title: 'СТРАТЕГИЧЕСКАЯ КАРТА', 
    text: 'Для начала, откройте вкладку «Карта Мира» в левом меню или снизу экрана, чтобы оценить линии фронта.',
    requireCondition: (state, activeTabId) => activeTabId === 'map',
    onEnter: () => audioEngine.playClick('toggle')
  },
  { 
    id: 'unpause', 
    title: 'КОНТРОЛЬ ВРЕМЕНИ', 
    text: 'Отлично. Сейчас время остановлено. Симуляция идёт только по вашему приказу. Нажмите кнопку Play (▶) в левом верхнем углу (рядом с датой), чтобы запустить время.',
    requireCondition: (state, activeTabId) => !state.isPaused && state.gameSpeed > 0
  },
  { 
    id: 'wait_crisis', 
    title: 'ОЖИДАНИЕ ДОКЛАДОВ', 
    text: 'Время пошло. Ситуация в стране напряженная, наши резервы на исходе. Ждем первых донесений с мест. Ожидайте...',
    requireCondition: (state, activeTabId) => state.activeCrisis !== null
  },
  { 
    id: 'make_decision', 
    title: 'КРИЗИСНОЕ УПРАВЛЕНИЕ', 
    text: 'Входящая шифровка! Это кризис. Внимательно прочтите варианты. Ваши решения не просто меняют цифры — они запускают сложные цепочки последствий. Сделайте выбор в открывшемся окне.',
    requireCondition: (state, activeTabId) => state.activeCrisis === null && state.totalDaysElapsed >= 3
  },
  { 
    id: 'consequences', 
    title: 'СИСТЕМА ПОСЛЕДСТВИЙ', 
    text: 'Решение принято. Обратите внимание: не все эффекты происходят сразу. Многие из них (отмечены синим таймером) сработают через несколько дней и будут записаны в Хронику. Иногда одно неверное решение может привести к краху через месяц.' 
  },
  { 
    id: 'done', 
    title: 'КОНЕЦ ИНСТРУКТАЖА', 
    text: 'Инструктаж окончен. Судьба Доминиона теперь полностью в ваших руках. Вы можете перепроходить сценарий в любых вариациях с помощью кнопки «Рандомизировать старт». Конец связи.' 
  }
];

export default function TutorialOverlay({ activeTabId }: { activeTabId?: string }) {
  const [gameState, setGameState] = useState(gameStore.getState());
  const [currentStepIdx, setCurrentStepIdx] = useState(0);

  useEffect(() => {
    return gameStore.subscribe(setGameState);
  }, []);

  useEffect(() => {
    // If the game is already in progress (days elapsed > 5) or tutorial is completed, close it immediately
    if (gameState.tutorialCompleted || gameState.totalDaysElapsed > 5) {
      if (!gameState.tutorialCompleted) gameStore.completeTutorial();
    }
  }, [gameState.tutorialCompleted, gameState.totalDaysElapsed]);

  const step = STEPS[currentStepIdx];

  useEffect(() => {
    if (!step) return;
    if (step.requireCondition) {
      const isMet = step.requireCondition(gameState, activeTabId || '');
      if (isMet) {
        handleNext();
      }
    }
  }, [gameState, activeTabId, step]);

  if (gameState.tutorialCompleted || !step) return null;

  const handleNext = () => {
    audioEngine.playStamp();
    if (currentStepIdx < STEPS.length - 1) {
      const nextStep = STEPS[currentStepIdx + 1];
      if (nextStep.onEnter) nextStep.onEnter();
      setCurrentStepIdx(prev => prev + 1);
    } else {
      gameStore.completeTutorial();
    }
  };

  const isAutoAdvance = !!step.requireCondition;

  return (
    <div className="fixed bottom-4 right-4 md:bottom-12 md:right-12 z-[100] w-full max-w-[360px] pointer-events-none font-mono">
      <AnimatePresence mode="wait">
        <motion.div
          key={step.id}
          initial={{ opacity: 0, x: 50, scale: 0.95 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: 20, scale: 0.95, filter: 'blur(4px)' }}
          className="bg-[#1c1815] border-2 border-amber-500 shadow-[0_10px_40px_rgba(245,158,11,0.2)] flex flex-col overflow-hidden pointer-events-auto relative"
        >
          {/* Header */}
          <div className="bg-amber-600/20 border-b border-amber-500/30 p-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-500 animate-pulse" />
              <span className="text-[10px] font-bold text-amber-200 tracking-widest uppercase">
                ИНСТРУКТОР СТАВКИ // ШАГ {currentStepIdx + 1}/{STEPS.length}
              </span>
            </div>
            {isAutoAdvance && (
              <span className="text-[9px] text-amber-500/60 uppercase animate-pulse">ОЖИДАНИЕ ДЕЙСТВИЯ...</span>
            )}
          </div>
          
          {/* Content */}
          <div className="p-4 flex flex-col gap-3 relative z-10">
            <h3 className="text-sm font-bold text-amber-100 uppercase tracking-tight">
              {step.title}
            </h3>
            <p className="text-xs leading-relaxed text-paper/90 font-serif italic">
              «{step.text}»
            </p>
          </div>

          {/* Action Area */}
          {!isAutoAdvance && (
            <div className="p-3 bg-ink flex items-center justify-end border-t border-amber-500/20">
              <button
                onClick={handleNext}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-ink text-[11px] font-bold transition-all shadow-[0_0_15px_rgba(245,158,11,0.3)] active:scale-95"
              >
                {currentStepIdx === STEPS.length - 1 ? 'ЗАВЕРШИТЬ' : 'ПОНЯТЬ И ПРИНЯТЬ'} <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Decorative Corner */}
          <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-amber-500/10 to-transparent pointer-events-none" />
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
