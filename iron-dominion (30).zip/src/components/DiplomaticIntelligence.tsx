import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, Shield, Send, AlertTriangle, Eye, Globe, MessageSquare, 
  Award, ArrowUpRight, TrendingDown, TrendingUp, RefreshCw, Zap,
  Plane, ShieldAlert, FileText, CheckCircle, Cpu, Sparkles
} from 'lucide-react';
import { GameState, CountryDiplomacyState } from '../utils/gameState';
import { gameStore } from '../utils/gameStore';
import { audioEngine } from '../utils/audioEngine';
import { routeAIRequest } from '../utils/aiRouter';

interface Leader {
  id: string;
  countryId: string;
  name: string;
  title: string;
  nation: string;
  personality: string;
  mood: 'distrustful' | 'friendly' | 'hostile' | 'scheming';
  relations: number; // -100 to +100
  coupRisk: number; // 0 to 100%
  secretGrievance: string;
  avatarSeed: string;
  generalStance: string;
}

interface DiplomaticLog {
  id: string;
  timestamp: string;
  leaderName: string;
  nation: string;
  headline: string;
  body: string;
  urgency: 'critical' | 'secret' | 'routine';
  impact: string;
}

const initialLeaders: Leader[] = [
  {
    id: 'falkenburg',
    countryId: 'falkenburg',
    name: 'Канцлер Франц Вагнер',
    title: 'Верховный Канцлер',
    nation: 'Остенская Империя (Фалькенбург)',
    personality: 'Параноидальный нарцисс, жаждет триумфа',
    mood: 'scheming',
    relations: 15,
    coupRisk: 62,
    secretGrievance: 'Помнит оскорбление на Женевском конгрессе 1928 года',
    avatarSeed: 'WAG',
    generalStance: 'Генерал фон Штерн тайно готовит хунту из-за нехватки танков.'
  },
  {
    id: 'norland',
    countryId: 'norland',
    name: 'Премьер Эвелин Крофт',
    title: 'Первый Лорд Адмиралтейства',
    nation: 'Королевство Норланд',
    personality: 'Холодный прагматик, торгует оружием со всеми',
    mood: 'distrustful',
    relations: -10,
    coupRisk: 28,
    secretGrievance: 'Подозревает нас в финансировании забастовок докеров',
    avatarSeed: 'CRF',
    generalStance: 'Парламент колеблется, но флот приведен в повышенную готовность.'
  },
  {
    id: 'ethelgard',
    countryId: 'ethelgard_republic',
    name: 'Маршал Радован Черни',
    title: 'Председатель Военного Совета',
    nation: 'Республика Этельгард',
    personality: 'Фанатичный милитарист старой закалки',
    mood: 'hostile',
    relations: -65,
    coupRisk: 84,
    secretGrievance: 'Личная кровная месть за гибель брата в кампании 1922 г.',
    avatarSeed: 'RAD',
    generalStance: 'Штабные офицеры открыто саботируют дипломатические ноты.'
  },
  {
    id: 'korsak',
    countryId: 'korsak',
    name: 'Князь Дамиан Морозов',
    title: 'Министр Имперской Безопасности',
    nation: 'Княжество Корсак',
    personality: 'Виртуоз теневого шантажа и дезинформации',
    mood: 'friendly',
    relations: 45,
    coupRisk: 41,
    secretGrievance: 'Ищет повод аннексировать приграничные нефтяные поля',
    avatarSeed: 'MOR',
    generalStance: 'Уверяет в вечной дружбе, одновременно перебрасывая эшелоны к границе.'
  }
];

const initialLogs: DiplomaticLog[] = [
  {
    id: 'log-1',
    timestamp: '14:20:00Z',
    leaderName: 'Маршал Радован Черни',
    nation: 'Республика Этельгард',
    headline: 'ТАЙНАЯ ДЕПЕША // УЛЬТИМАТУМ ГЕНЕРАЛИТЕТА',
    body: 'Штабные офицеры Радована отклонили мирный протокол. В бункере маршала замечены эмиссары радикальной военной ложи.',
    urgency: 'critical',
    impact: 'Риск военного переворота вырос до 84%'
  },
  {
    id: 'log-2',
    timestamp: '12:05:18Z',
    leaderName: 'Канцлер Франц Вагнер',
    nation: 'Остенская Империя (Фалькенбург)',
    headline: 'ПЕРЕХВАТ ШИФРОТЕЛЕГРАММЫ // ОПЕРАЦИЯ «ЗОЛОТОЙ КЛЮЧ»',
    body: 'Вагнер принял взятку в 2,000,000 рейхсмарок под видом закупки зерна. Однако его военный министр высказал открытое презрение.',
    urgency: 'secret',
    impact: 'Отношения с лидером +20, недовольство армии +15%'
  },
  {
    id: 'log-3',
    timestamp: '09:44:02Z',
    leaderName: 'Премьер Эвелин Крофт',
    nation: 'Королевство Норланд',
    headline: 'ЗАКРЫТОЕ ЗАСЕДАНИЕ КАБИНЕТА',
    body: 'Британский синдикат предложил негласное разделение сфер влияния в угольных бассейнах Остенмарка.',
    urgency: 'routine',
    impact: 'Нейтральный статус подтвержден до следующего квартала'
  }
];

export default function DiplomaticIntelligence() {
  const [gameState, setGameState] = useState<GameState>(gameStore.getState());
  const [leaders, setLeaders] = useState<Leader[]>(initialLeaders);
  const [selectedLeaderId, setSelectedLeaderId] = useState<string>('falkenburg');
  const [logs, setLogs] = useState<DiplomaticLog[]>(initialLogs);
  const [actionInProgress, setActionInProgress] = useState<string | null>(null);
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  useEffect(() => {
    return gameStore.subscribe(setGameState);
  }, []);

  const selectedLeader = leaders.find(l => l.id === selectedLeaderId) || leaders[0];
  const matchingCountry = gameState.countries.find(c => c.id === selectedLeader.countryId);

  const handleAIAnalysis = async () => {
    if (!selectedLeader) return;
    setIsAiLoading(true);
    setAiReport(null);
    audioEngine.playTuningSweep();

    try {
      const prompt = `Проведи глубокий психологический анализ лидера: ${selectedLeader.name}. 
      Нация: ${selectedLeader.nation}. 
      Личность: ${selectedLeader.personality}. 
      Текущее настроение: ${selectedLeader.mood}. 
      Отношения: ${selectedLeader.relations}.
      Тайная обида: ${selectedLeader.secretGrievance}.
      
      Опиши его вероятные следующие шаги, тайные страхи и как на него лучше всего надавить.
      Ответ дай в формате JSON: { "analysis": "текст", "recommendation": "текст", "threatLevel": "low|medium|high" }`;

      const result = await routeAIRequest({
        prompt,
        urgency: 'medium',
        isKeyMoment: false
      });

      setAiReport(result.analysis + "\n\nРЕКОМЕНДАЦИЯ: " + result.recommendation);
    } catch (error) {
      console.error("AI Analysis failed:", error);
      setAiReport("Ошибка при получении разведданных от ИИ.");
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleExecuteManeuver = (type: 'bribe' | 'blackmail' | 'pact' | 'provoke') => {
    if (gameState.resources.treasury < 100 && (type === 'bribe' || type === 'blackmail')) {
      alert('Недостаточно средств в казне (требуется от 100 RM)!');
      return;
    }

    setActionInProgress(type);
    audioEngine.playClick('switch');
    
    setTimeout(() => {
      let logTitle = '';
      let logBody = '';
      let impactText = '';
      let urgency: DiplomaticLog['urgency'] = 'secret';
      let relationsChange = 0;
      let coupChange = 0;

      const l = selectedLeader;

      if (type === 'bribe') {
        logTitle = `КОРРУПЦИОННЫЙ ТРАНШ // ${l.nation}`;
        logBody = `${l.name} лично принял секретные чеки швейцарского банка (-150 RM). Личные отношения улучшились, но генералы шепчутся о предательстве.`;
        impactText = `Отношения: +25 | Риск переворота: +12%`;
        urgency = 'secret';
        relationsChange = 25;
        coupChange = 12;

        gameStore.updateResources({ treasury: Math.max(0, gameState.resources.treasury - 150) });
        gameStore.addChronicleEntry({
          id: `dip_bribe_${Date.now()}`,
          timestamp: new Date().toISOString().substring(0, 10),
          dayCount: gameState.totalDaysElapsed,
          category: 'politics',
          title: `ПОДКУП ЛИДЕРА: ${l.name}`,
          details: `Переведен транш 150 RM в банк Цюриха. Отношения улучшены, но разведка сообщает о росте подозрительности штаба.`,
          badge: 'ДИПЛОМАТИЯ',
          impactColor: '#eab308'
        });

        // Schedule delayed reaction from generals
        gameStore.scheduleConsequence({
          id: `cq_bribe_generals_${Date.now()}`,
          title: `Генералы ${l.nation} обвиняют лидера во взяточничестве`,
          triggerDateDay: gameState.totalDaysElapsed + 7,
          daysLeft: 7,
          originAction: `Подкуп лидера ${l.name}`,
          description: `Военное крыло узнало о тайных платежах и выводит танковые части на учения.`,
          severity: 'warning',
          applied: false,
          effect: {
            countryId: l.countryId,
            countryTensionDelta: 15
          }
        }, {
          intelRequired: 50,
          forecastHint: 'В штабе противника участились ночные совещания и экстренные вызовы офицеров.'
        });

      } else if (type === 'blackmail') {
        logTitle = `ШАНТАЖ КОМПРОМАТОМ // ${l.nation}`;
        logBody = `Агенты передали досье на счета и любовницу ${l.name}. Лидер уступил в таможенном споре, но затаил ярость.`;
        impactText = `Уступки получены | Тайная обида углублена (-35 отношений)`;
        urgency = 'critical';
        relationsChange = -35;
        coupChange = -5;

        gameStore.updateResources({ treasury: Math.max(0, gameState.resources.treasury - 80) });
        gameStore.addChronicleEntry({
          id: `dip_blackmail_${Date.now()}`,
          timestamp: new Date().toISOString().substring(0, 10),
          dayCount: gameState.totalDaysElapsed,
          category: 'espionage',
          title: `ШАНТАЖ: ${l.name}`,
          details: `Вручены папки с компроматом IV управления. Лидер подчинился требованиям, но начал тайную подготовку реванша.`,
          badge: 'ШАНТАЖ',
          impactColor: '#9333ea'
        });

      } else if (type === 'pact') {
        logTitle = `ТАЙНЫЙ ПАКТ О НЕНАПАДЕНИИ // ${l.nation}`;
        logBody = `Подписан секретный протокол о ненападении. Напряженность на границе снижена на 15%.`;
        impactText = `Временный союз заключен | Напряженность -15%`;
        urgency = 'routine';
        relationsChange = 15;
        coupChange = -10;

        gameStore.addChronicleEntry({
          id: `dip_pact_${Date.now()}`,
          timestamp: new Date().toISOString().substring(0, 10),
          dayCount: gameState.totalDaysElapsed,
          category: 'politics',
          title: `СЕКРЕТНЫЙ ПАКТ С ${l.nation.toUpperCase()}`,
          details: `Подписано секретное приложение к договору о нейтралитете.`,
          badge: 'ПАКТ',
          impactColor: '#16a34a'
        });

      } else {
        logTitle = `ПРОВОКАЦИЯ НА ГРАНИЦЕ // ${l.nation}`;
        logBody = `Диверсионная группа сымитировала налет на пограничный форпост. ${l.name} объявил повышенную боеготовность.`;
        impactText = `Отношения: -50 | Напряженность +25%`;
        urgency = 'critical';
        relationsChange = -50;
        coupChange = 20;

        gameStore.scheduleConsequence({
          id: `cq_provoke_retaliate_${Date.now()}`,
          title: `Ответный артиллерийский налет на границе ${l.nation}`,
          triggerDateDay: gameState.totalDaysElapsed + 4,
          daysLeft: 4,
          originAction: `Провокация против ${l.name}`,
          description: `Артиллерия ${l.nation} нанесла превентивный удар по нашим передовым траншеям.`,
          severity: 'critical',
          applied: false,
          effect: {
            countryId: l.countryId,
            countryTensionDelta: 30,
            stabilityDelta: -4
          }
        }, {
          intelRequired: 40,
          forecastHint: 'Наблюдатели сообщают о расчехлении дальнобойных орудий в секторе границы.'
        });
      }

      const newLog: DiplomaticLog = {
        id: 'log-' + Date.now(),
        timestamp: new Date().toISOString().substring(11, 19) + 'Z',
        leaderName: l.name,
        nation: l.nation,
        headline: logTitle,
        body: logBody,
        urgency,
        impact: impactText
      };

      setLogs(prev => [newLog, ...prev.slice(0, 7)]);

      setLeaders(prev => prev.map(item => {
        if (item.id === l.id) {
          const newRel = Math.max(-100, Math.min(100, item.relations + relationsChange));
          const newCoup = Math.max(5, Math.min(99, item.coupRisk + coupChange));
          let newMood: Leader['mood'] = item.mood;
          if (newRel > 30) newMood = 'friendly';
          else if (newRel < -40) newMood = 'hostile';
          else if (newCoup > 60) newMood = 'scheming';
          else newMood = 'distrustful';

          return {
            ...item,
            relations: newRel,
            coupRisk: newCoup,
            mood: newMood
          };
        }
        return item;
      }));

      setActionInProgress(null);
      audioEngine.playStamp();
    }, 500);
  };

  const getMoodBadge = (mood: Leader['mood']) => {
    switch (mood) {
      case 'friendly':
        return <span className="bg-emerald-900/30 text-emerald-800 border border-emerald-700/40 px-2 py-0.5 text-[10px] uppercase font-bold font-mono">Лоялен</span>;
      case 'hostile':
        return <span className="bg-blood/20 text-blood border border-blood/50 px-2 py-0.5 text-[10px] uppercase font-bold font-mono">Враждебен</span>;
      case 'scheming':
        return <span className="bg-amber-900/20 text-amber-800 border border-amber-600/40 px-2 py-0.5 text-[10px] uppercase font-bold font-mono">Плетёт заговор</span>;
      default:
        return <span className="bg-ink/10 text-ink-light border border-ink/20 px-2 py-0.5 text-[10px] uppercase font-bold font-mono">Недоверие</span>;
    }
  };

  return (
    <div className="w-full bg-paper/60 border border-ink/20 p-4 md:p-6 relative font-sans text-ink">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-2">
        <div className="flex items-center gap-2.5">
          <Globe className="w-5 h-5 text-blood" />
          <div>
            <h3 className="font-serif font-bold text-xl uppercase tracking-tight text-ink">
              Дипломатический Разведузел // AI Intelligence
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Мониторинг психологических профилей, обид и переворотов
            </span>
          </div>
        </div>
        <div className="font-mono text-xs bg-ink/5 border border-ink/20 px-2.5 py-1 flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
          <span className="text-[11px] uppercase">СЕТЬ ИНФОРМАТОРОВ: АКТИВНА</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left 5 Cols: Leaders Carousel / Selection */}
        <div className="lg:col-span-5 flex flex-col gap-3">
          <div className="font-mono text-[10px] uppercase tracking-wider text-ink/60 border-b border-ink/15 pb-1 flex justify-between">
            <span>Иностранные правители</span>
            <span>Кликните для досье</span>
          </div>

          <div className="flex flex-col gap-2">
            {leaders.map((leader) => {
              const isSelected = leader.id === selectedLeaderId;
              const country = gameState.countries.find(c => c.id === leader.countryId);
              return (
                <button
                  key={leader.id}
                  onClick={() => {
                    audioEngine.playClick('switch');
                    setSelectedLeaderId(leader.id);
                  }}
                  className={`p-3 border text-left transition-all relative flex items-center justify-between ${
                    isSelected
                      ? 'bg-ink text-paper-light border-ink shadow-md'
                      : 'bg-paper hover:bg-paper-dark/30 border-ink/20 hover:border-ink/50'
                  }`}
                >
                  {isSelected && (
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-blood" />
                  )}
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2">
                      <span className="font-serif font-bold text-sm tracking-wide">
                        {leader.name}
                      </span>
                    </div>
                    <span className={`font-mono text-[11px] ${isSelected ? 'text-paper-light/70' : 'text-ink/60'}`}>
                      {leader.nation}
                    </span>
                  </div>

                  <div className="flex flex-col items-end gap-1">
                    {getMoodBadge(leader.mood)}
                    <span className={`font-mono text-[10px] ${isSelected ? 'text-paper-light/60' : 'text-ink/50'}`}>
                      Дивизий: <strong className="font-bold">{country?.mobilizationDivisions || 8}</strong> | Разведка: <strong>{country?.intelCoverage || 30}%</strong>
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected Leader Dossier Card */}
          <div className="border border-ink/30 bg-paper-light p-4 mt-2 relative">
            <div className="absolute top-2 right-2 font-mono text-[9px] text-stamp border border-stamp px-1.5 uppercase opacity-80">
              SECRET PSY-FILE
            </div>

            <div className="flex items-start gap-3 mb-3">
              <div className="w-10 h-10 border border-ink bg-ink/10 flex items-center justify-center font-mono font-bold text-xs uppercase text-ink shrink-0">
                {selectedLeader.avatarSeed}
              </div>
              <div>
                <h4 className="font-serif font-bold text-lg leading-tight uppercase text-ink">
                  {selectedLeader.name}
                </h4>
                <div className="font-mono text-xs text-ink/70">
                  {selectedLeader.title} • {selectedLeader.nation}
                </div>
              </div>
            </div>

            <div className="space-y-2 font-mono text-xs border-t border-ink/15 pt-2 text-ink-light">
              <div>
                <span className="text-[10px] uppercase text-ink/50 block">Психологический паттерн:</span>
                <span className="font-sans italic text-ink font-medium">{selectedLeader.personality}</span>
              </div>

              <div>
                <span className="text-[10px] uppercase text-ink/50 block">Тайная обида (Историческая память):</span>
                <span className="text-blood text-[11px] font-medium">"{selectedLeader.secretGrievance}"</span>
              </div>

              <div>
                <span className="text-[10px] uppercase text-ink/50 block">Опасность генералитета:</span>
                <span className="text-ink text-[11px]">{selectedLeader.generalStance}</span>
              </div>

              {/* Live Country Simulation Signals */}
              {matchingCountry && (
                <div className="p-2 bg-paper/40 border border-ink/15 space-y-1 my-1 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-ink/60">Напряженность на границе:</span>
                    <strong className={matchingCountry.tension > 60 ? 'text-red-700' : 'text-ink'}>{matchingCountry.tension}%</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-ink/60">Разведывательное покрытие:</span>
                    <strong className="text-amber-800">{matchingCountry.intelCoverage}%</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-ink/60">Дивизий на рубеже:</span>
                    <strong className="text-blood">{matchingCountry.mobilizationDivisions} дивизий</strong>
                  </div>
                </div>
              )}

              {/* AI Psychological Analysis Button */}
              <div className="mt-3">
                <button
                  onClick={handleAIAnalysis}
                  disabled={isAiLoading}
                  className="w-full py-2 bg-ink/10 hover:bg-ink hover:text-paper-light border border-ink/30 font-mono text-[10px] uppercase flex items-center justify-center gap-2 transition-all disabled:opacity-50"
                >
                  <Cpu className={`w-3.5 h-3.5 ${isAiLoading ? 'animate-spin' : ''}`} />
                  {isAiLoading ? 'Анализ нейропрофиля...' : 'Получить Психологический Портрет (AI)'}
                </button>
              </div>

              {aiReport && (
                <div className="mt-2 p-2 bg-amber-900/10 border border-amber-700/30 text-[10px] font-sans leading-relaxed text-ink/80 animate-in fade-in slide-in-from-top-1">
                  <div className="font-bold text-amber-800 uppercase mb-1 flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> Аналитическая справка IV управления:
                  </div>
                  {aiReport}
                </div>
              )}

              {/* Relations & Coup Gauges */}
              <div className="pt-2 border-t border-ink/10 flex flex-col gap-2">
                <div>
                  <div className="flex justify-between text-[10px] uppercase">
                    <span>Дипломатические отношения</span>
                    <span className={`font-bold ${selectedLeader.relations >= 0 ? 'text-emerald-700' : 'text-blood'}`}>
                      {selectedLeader.relations > 0 ? `+${selectedLeader.relations}` : selectedLeader.relations} / 100
                    </span>
                  </div>
                  <div className="w-full h-1.5 bg-ink/10 mt-0.5 relative">
                    <div
                      className={`h-full transition-all duration-300 ${selectedLeader.relations >= 0 ? 'bg-emerald-600' : 'bg-blood'}`}
                      style={{
                        width: `${Math.min(100, Math.abs(selectedLeader.relations))}%`
                      }}
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[10px] uppercase">
                    <span>Вероятность свержения генералами</span>
                    <span className="text-blood font-bold">{selectedLeader.coupRisk}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-ink/10 mt-0.5">
                    <div
                      className="h-full bg-blood transition-all duration-300"
                      style={{ width: `${selectedLeader.coupRisk}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Maneuvers Action Box */}
            <div className="mt-4 pt-3 border-t border-ink/20">
              <span className="font-mono text-[10px] uppercase tracking-wider text-ink/60 block mb-2">
                Секретные спецоперации против {selectedLeader.nation}:
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                <button
                  onClick={() => handleExecuteManeuver('bribe')}
                  disabled={actionInProgress !== null}
                  className="px-2.5 py-1.5 bg-paper border border-ink/40 font-mono text-[10px] uppercase hover:bg-ink hover:text-paper-light transition-all flex items-center justify-center gap-1 shadow-sm active:translate-y-0.5 disabled:opacity-50"
                  title="Подкупить лидера через подставные счета (-150 RM)"
                >
                  <Award className="w-3 h-3 text-amber-600" />
                  <span>Взятка (-150 RM)</span>
                </button>

                <button
                  onClick={() => handleExecuteManeuver('blackmail')}
                  disabled={actionInProgress !== null}
                  className="px-2.5 py-1.5 bg-paper border border-ink/40 font-mono text-[10px] uppercase hover:bg-ink hover:text-paper-light transition-all flex items-center justify-center gap-1 shadow-sm active:translate-y-0.5 disabled:opacity-50"
                  title="Слить компромат контрразведке (-80 RM)"
                >
                  <Eye className="w-3 h-3 text-blood" />
                  <span>Шантаж (-80 RM)</span>
                </button>

                <button
                  onClick={() => handleExecuteManeuver('pact')}
                  disabled={actionInProgress !== null}
                  className="px-2.5 py-1.5 bg-paper border border-ink/40 font-mono text-[10px] uppercase hover:bg-ink hover:text-paper-light transition-all flex items-center justify-center gap-1 shadow-sm active:translate-y-0.5 disabled:opacity-50"
                  title="Предложить тайный договор о ненападении"
                >
                  <Shield className="w-3 h-3 text-emerald-700" />
                  <span>Тайный пакт</span>
                </button>

                <button
                  onClick={() => handleExecuteManeuver('provoke')}
                  disabled={actionInProgress !== null}
                  className="px-2.5 py-1.5 bg-paper border border-blood/50 font-mono text-[10px] uppercase text-blood hover:bg-blood hover:text-paper-light transition-all flex items-center justify-center gap-1 shadow-sm active:translate-y-0.5 disabled:opacity-50"
                  title="Организовать провокацию под чужим флагом"
                >
                  <Zap className="w-3 h-3 text-amber-500" />
                  <span>Провокация</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right 7 Cols: Realtime Diplomatic Intercept Feed */}
        <div className="lg:col-span-7 flex flex-col justify-between">
          <div>
            <div className="font-mono text-[10px] uppercase tracking-wider text-ink/60 border-b border-ink/15 pb-1 mb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-blood" />
                Лента перехватов и дипломатических интриг
              </span>
              <span>LIVE WIRE</span>
            </div>

            <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
              <AnimatePresence initial={false}>
                {logs.map((log) => (
                  <motion.div
                    key={log.id}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.3 }}
                    className={`p-3.5 border font-mono text-xs relative ${
                      log.urgency === 'critical'
                        ? 'bg-blood/10 border-blood/60 text-ink'
                        : log.urgency === 'secret'
                        ? 'bg-amber-900/10 border-amber-700/40 text-ink'
                        : 'bg-paper-light/80 border-ink/20 text-ink-light'
                    }`}
                  >
                    <div className="flex items-center justify-between border-b border-ink/10 pb-1 mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className={`px-1.5 py-0.2 text-[9px] uppercase font-bold tracking-wider ${
                          log.urgency === 'critical' ? 'bg-blood text-paper-light' :
                          log.urgency === 'secret' ? 'bg-amber-800 text-paper-light' : 'bg-ink text-paper-light'
                        }`}>
                          {log.urgency === 'critical' ? 'ТРЕВОГА' : log.urgency === 'secret' ? 'СЕКРЕТНО' : 'ДЕПЕША'}
                        </span>
                        <span className="font-bold text-ink text-[11px]">{log.headline}</span>
                      </div>
                      <span className="text-[10px] opacity-60">{log.timestamp}</span>
                    </div>

                    <p className="font-sans text-xs leading-relaxed text-ink/90 mb-2">
                      {log.body}
                    </p>

                    <div className="flex items-center justify-between border-t border-ink/10 pt-1 text-[10px] text-ink/60">
                      <span>Фигурант: <strong className="text-ink">{log.leaderName}</strong> ({log.nation})</span>
                      <span className="font-bold text-blood">{log.impact}</span>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-ink/20 font-mono text-[10px] text-ink/60 flex items-center justify-between">
            <span>* Искусственный интеллект лидеров учитывает прошлые войны и заговоры своих генералов</span>
            <span className="uppercase text-blood font-bold flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              Альянсы непредсказуемы
            </span>
          </div>
        </div>

      </div>
    </div>
  );
}
