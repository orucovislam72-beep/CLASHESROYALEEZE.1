import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, X, ShieldAlert, AlertTriangle, Flame, 
  Coins, HardHat, Award, Skull, CheckCircle, ChevronRight,
  Sliders, FileText
} from 'lucide-react';
import { GameState, FactionState } from '../utils/gameState';
import { gameStore } from '../utils/gameStore';
import { audioEngine } from '../utils/audioEngine';

interface DomesticPoliticsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function DomesticPoliticsModal({ isOpen, onClose }: DomesticPoliticsModalProps) {
  const [state, setState] = useState<GameState>(gameStore.getState());
  const [selectedFactionId, setSelectedFactionId] = useState<string>(state.factions[0]?.id || 'military');

  React.useEffect(() => {
    return gameStore.subscribe(setState);
  }, []);

  if (!isOpen) return null;

  const selectedFaction = state.factions.find(f => f.id === selectedFactionId) || state.factions[0];

  // Emergency Decrees
  const handleIssueDecree = (decreeType: string) => {
    const s = gameStore.getState();
    const dateStamp = `${s.currentDate.day} АВГ ${s.currentDate.year}`;

    if (decreeType === 'bread_rations') {
      if (s.resources.treasury < 300 || s.resources.food < 400) return;
      s.resources.treasury -= 300;
      s.resources.food -= 400;
      s.stability = Math.min(100, s.stability + 10);
      s.factions = s.factions.map(f => f.id === 'labor' ? { ...f, loyalty: Math.min(100, f.loyalty + 18) } : f);
      
      gameStore.addChronicleEntry({
        id: `decree_bread_${Date.now()}`,
        timestamp: dateStamp,
        dayCount: s.totalDaysElapsed,
        category: 'politics',
        title: 'ДЕКРЕТ: ДОПОЛНИТЕЛЬНЫЕ ПАЙКИ ШАХТЕРАМ',
        details: 'Выделено 400т зерна для рабочих Остенмарка. Лояльность профсоюзов выросла на +18%.',
        badge: 'ДЕКРЕТ СТАВКИ',
        impactColor: '#059669'
      });
    } else if (decreeType === 'militarize_factories') {
      s.stability = Math.max(0, s.stability - 6);
      s.militaryReadiness = Math.min(100, s.militaryReadiness + 8);
      s.factions = s.factions.map(f => {
        if (f.id === 'military') return { ...f, loyalty: Math.min(100, f.loyalty + 12) };
        if (f.id === 'labor') return { ...f, loyalty: Math.max(0, f.loyalty - 14) };
        return f;
      });

      gameStore.addChronicleEntry({
        id: `decree_militarize_${Date.now()}`,
        timestamp: dateStamp,
        dayCount: s.totalDaysElapsed,
        category: 'politics',
        title: 'ДЕКРЕТ: МИЛИТАРИЗАЦИЯ ПРОМЫШЛЕННОСТИ',
        details: 'Заводы переведены на 12-часовой рабочий график под контролем офицеров военного ведомства.',
        badge: 'ВОЕННОЕ ПОЛОЖЕНИЕ',
        impactColor: '#dc2626'
      });
    } else if (decreeType === 'shadow_loan') {
      s.resources.treasury += 8000;
      s.factions = s.factions.map(f => f.id === 'shadow_elite' ? { ...f, influence: Math.min(100, f.influence + 20) } : f);
      gameStore.advanceSecretScenario('black_sun', 1);

      gameStore.addChronicleEntry({
        id: `decree_loan_${Date.now()}`,
        timestamp: dateStamp,
        dayCount: s.totalDaysElapsed,
        category: 'economy',
        title: 'СЕКРЕТНЫЙ КРЕДИТ БАЗЕЛЬСКОГО КАРТЕЛЯ',
        details: 'В казну поступило +8,000 рейхсмарок в обмен на секретные векселя и сырьевые квоты.',
        badge: 'ФИНАНСОВЫЙ ПАКТ',
        impactColor: '#7c3aed'
      });
    }

    audioEngine.playStamp();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-ink/85 backdrop-blur-xs font-mono">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        transition={{ duration: 0.25 }}
        className="w-full max-w-5xl max-h-[92vh] bg-ink text-paper-light border-4 border-amber-400 shadow-2xl flex flex-col relative overflow-hidden"
      >
        {/* Header */}
        <div className="bg-amber-500 text-ink p-3 sm:p-4 flex items-center justify-between border-b-2 border-blood">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-ink" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-widest text-ink/80 font-bold">
                  КАБИНЕТ ВНУТРЕННЕЙ ПОЛИТИКИ // FACTIONS & STABILITY
                </span>
                <span className="px-1.5 py-0.5 bg-blood text-paper-light text-[9px] font-mono font-bold">
                  CABINET OF MINISTERS
                </span>
              </div>
              <h2 className="text-base sm:text-xl font-bold tracking-tight">
                Баланс Элит, Профсоюзов и Стабильность Нации
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              audioEngine.playClick('switch');
              onClose();
            }}
            className="p-1.5 bg-ink/20 hover:bg-ink text-ink hover:text-paper-light border border-ink/40 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* National Stability Metrics */}
        <div className="bg-paper/10 border-b border-paper/20 p-3 px-4 sm:px-6 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-paper/70 font-bold">ОБЩАЯ СТАБИЛЬНОСТЬ:</span>
              <span className="text-amber-300 font-bold">{state.stability}%</span>
            </div>
            <div className="w-full bg-paper/20 h-2 overflow-hidden">
              <div 
                className={`h-full transition-all duration-300 ${state.stability > 60 ? 'bg-emerald-400' : state.stability > 30 ? 'bg-amber-400' : 'bg-red-500'}`}
                style={{ width: `${state.stability}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-paper/70 font-bold">УСТАЛОСТЬ ОТ ВОЙНЫ:</span>
              <span className="text-red-400 font-bold">{state.warWeariness}%</span>
            </div>
            <div className="w-full bg-paper/20 h-2 overflow-hidden">
              <div 
                className="bg-red-500 h-full transition-all duration-300"
                style={{ width: `${state.warWeariness}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-paper/70 font-bold">ГОТОВНОСТЬ АРМИИ:</span>
              <span className="text-cyan-300 font-bold">{state.militaryReadiness}%</span>
            </div>
            <div className="w-full bg-paper/20 h-2 overflow-hidden">
              <div 
                className="bg-cyan-400 h-full transition-all duration-300"
                style={{ width: `${state.militaryReadiness}%` }}
              />
            </div>
          </div>
        </div>

        {/* Content Layout */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-5">
          
          {/* Left Column: 4 Factions (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-2.5">
            <span className="text-xs font-bold uppercase text-amber-300 tracking-wider mb-1">
              КЛЮЧЕВЫЕ ФРАКЦИИ ВЛАСТИ
            </span>

            {state.factions.map(faction => (
              <div
                key={faction.id}
                onClick={() => {
                  audioEngine.playClick('switch');
                  setSelectedFactionId(faction.id);
                }}
                className={`p-3 border transition-all cursor-pointer ${
                  selectedFactionId === faction.id
                    ? 'bg-paper/20 border-amber-300 shadow-md'
                    : 'bg-paper/5 hover:bg-paper/10 border-paper/20'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-amber-200">{faction.name}</span>
                  <span className={`px-1.5 py-0.5 text-[9px] font-bold border ${
                    faction.loyalty > 65 
                      ? 'bg-emerald-950 text-emerald-300 border-emerald-500' 
                      : faction.loyalty > 35 
                      ? 'bg-amber-950 text-amber-300 border-amber-500' 
                      : 'bg-red-950 text-red-300 border-red-500 animate-pulse'
                  }`}>
                    {faction.loyalty > 65 ? 'ЛОЯЛЬНЫ' : faction.loyalty > 35 ? 'НЕЙТРАЛЬНЫ' : 'МЯТЕЖ'}
                  </span>
                </div>

                <div className="text-[10px] text-paper/60 mb-2">
                  Лидер: <strong className="text-paper-light">{faction.leader}</strong>
                </div>

                {/* Loyalty Bar */}
                <div className="space-y-1 mb-1 text-[10px]">
                  <div className="flex justify-between text-paper/70">
                    <span>Лояльность: <strong className="text-paper-light">{faction.loyalty}%</strong></span>
                    <span>Влияние: <strong className="text-amber-300">{faction.influence}%</strong></span>
                  </div>
                  <div className="w-full bg-paper/20 h-1.5 overflow-hidden">
                    <div 
                      className={`h-full ${faction.loyalty > 65 ? 'bg-emerald-400' : faction.loyalty > 35 ? 'bg-amber-400' : 'bg-red-500'}`}
                      style={{ width: `${faction.loyalty}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right Column: Selected Faction Dossier & Emergency Decrees (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-between gap-4">
            
            {/* Faction Dossier Card */}
            <div className="bg-paper/5 border border-paper/20 p-4">
              <div className="border-b border-paper/20 pb-2 mb-3">
                <span className="text-xs font-bold uppercase text-amber-300">
                  ДОСЬЕ ФРАКЦИИ: {selectedFaction.name}
                </span>
              </div>

              <p className="text-xs text-paper/80 italic font-serif mb-3">
                {selectedFaction.role}
              </p>

              <div className="space-y-2 text-xs">
                <div className="p-2 bg-emerald-950/40 border border-emerald-800/40 text-emerald-200">
                  <strong>Бонус лояльности (&gt;70%):</strong> {selectedFaction.perk}
                </div>
                <div className="p-2 bg-red-950/40 border border-red-800/40 text-red-200">
                  <strong>Угроза бунта (&lt;30%):</strong> {selectedFaction.threat}
                </div>
              </div>
            </div>

            {/* Emergency Decrees Panel */}
            <div className="bg-paper/5 border border-paper/20 p-4">
              <div className="border-b border-paper/20 pb-2 mb-3 flex items-center justify-between">
                <span className="text-xs font-bold uppercase text-amber-300">
                  ЧРЕЗВЫЧАЙНЫЕ ДЕКРЕТЫ СТАВКИ
                </span>
                <span className="text-[10px] text-paper/60">
                  ПРЯМОЕ ВМЕШАТЕЛЬСТВО
                </span>
              </div>

              <div className="space-y-2">
                {/* Decree 1 */}
                <button
                  onClick={() => handleIssueDecree('bread_rations')}
                  disabled={state.resources.treasury < 300 || state.resources.food < 400}
                  className="w-full p-2.5 bg-paper/10 hover:bg-paper/20 disabled:opacity-40 border border-paper/30 text-left transition-all"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-paper-light mb-1">
                    <span>1. Дополнительные хлебные пайки шахтерам Остенмарка</span>
                    <span className="text-amber-300 text-[11px]">-300 RM / -400т зерна</span>
                  </div>
                  <div className="text-[11px] text-paper/60">
                    +18% лояльности рабочих профсоюзов, +10% к стабильности нации.
                  </div>
                </button>

                {/* Decree 2 */}
                <button
                  onClick={() => handleIssueDecree('militarize_factories')}
                  className="w-full p-2.5 bg-paper/10 hover:bg-paper/20 border border-paper/30 text-left transition-all"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-paper-light mb-1">
                    <span>2. Милитаризация и трудовая повинность на заводах</span>
                    <span className="text-red-400 text-[11px]">-6% стабильности</span>
                  </div>
                  <div className="text-[11px] text-paper/60">
                    +12% лояльности военных, +8% боеготовности, -14% лояльности рабочих.
                  </div>
                </button>

                {/* Decree 3 */}
                <button
                  onClick={() => handleIssueDecree('shadow_loan')}
                  className="w-full p-2.5 bg-paper/10 hover:bg-paper/20 border border-purple-500/50 text-left transition-all"
                >
                  <div className="flex items-center justify-between text-xs font-bold text-amber-200 mb-1">
                    <span>3. Секретный заём у Теневого Банковского Картеля</span>
                    <span className="text-emerald-400 text-[11px]">+8,000 RM в казну</span>
                  </div>
                  <div className="text-[11px] text-paper/60">
                    +20% влияния картеля, раскрывает тайную улику к сценарию «Black Sun».
                  </div>
                </button>
              </div>
            </div>

          </div>

        </div>

        {/* Footer */}
        <div className="bg-ink/90 border-t border-paper/20 p-2.5 px-4 flex items-center justify-between text-xs text-paper/60">
          <span>Государственный совет Доминиона</span>
          <span className="uppercase text-[10px]">VERWALTUNG FÜR INNERE ANGELEGENHEITEN</span>
        </div>
      </motion.div>
    </div>
  );
}
