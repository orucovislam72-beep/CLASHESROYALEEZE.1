import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, RotateCcw, BookOpen, Settings, Info, Target, Shield, Clock, ShieldAlert, AlertTriangle } from 'lucide-react';
import { gameStore } from '../utils/gameStore';
import { GameState, formatDate } from '../utils/gameState';
import { audioEngine } from '../utils/audioEngine';
import { CURRENT_APP_VERSION, AppVersionInfo } from '../config/version';

interface MainMenuProps {
  onStartGame: () => void;
  onOpenChronicle: () => void;
  onOpenScenarios: () => void;
}

export default function MainMenu({ onStartGame, onOpenChronicle, onOpenScenarios }: MainMenuProps) {
  const [gameState, setGameState] = useState<GameState>(gameStore.getState());
  const [appVersion] = useState<AppVersionInfo>(CURRENT_APP_VERSION);
  
  useEffect(() => {
    const unsub = gameStore.subscribe(setGameState);
    return unsub;
  }, []);

  const handleContinue = () => {
    audioEngine.playStamp();
    onStartGame();
  };

  const handleNewCampaign = () => {
    audioEngine.playStamp();
    gameStore.resetGame();
    onStartGame();
  };

  const handleTutorial = () => {
    audioEngine.playStamp();
    gameStore.resetGame();
    gameStore.resetTutorial();
    onStartGame();
  };

  const handleScenarios = () => {
    audioEngine.playClick('switch');
    onOpenScenarios();
  };

  const handleChronicle = () => {
    audioEngine.playClick('toggle');
    onOpenChronicle();
  };

  // Determine if there is a save to continue
  const canContinue = gameState.totalDaysElapsed > 0;

  return (
    <div className="min-h-screen bg-ink relative overflow-hidden font-mono text-paper-light selection:bg-blood selection:text-paper-light flex">
      <div className="noise-overlay pointer-events-none z-10 opacity-30 mix-blend-overlay"></div>
      
      {/* Decorative Topo Lines Background */}
      <svg className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-[0.06] text-paper-light z-0" viewBox="0 0 1000 1000" preserveAspectRatio="none">
        {/* Tactical Grid */}
        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.3" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#grid)" />
        
        {/* Abstract Topo Continents */}
        <path d="M100,150 Q150,100 300,120 T500,200 T650,150 T800,250 T900,100 T1000,150 L1000,1000 L0,1000 Z" fill="currentColor" opacity="0.02" />
        <path d="M150,200 Q200,150 280,180 T450,280 T600,250 T750,320 T850,220" fill="none" stroke="currentColor" strokeWidth="1" />
        <path d="M80,250 Q130,200 240,240 T400,360 T550,350 T700,400 T800,300" fill="none" stroke="currentColor" strokeWidth="1" />
        <path d="M200,350 Q350,300 450,450 T650,550 T850,450" fill="none" stroke="currentColor" strokeWidth="1.5" />
        
        <circle cx="280" cy="180" r="4" fill="currentColor" opacity="0.5"/>
        <circle cx="600" cy="250" r="3" fill="currentColor" opacity="0.5"/>
        <circle cx="450" cy="450" r="5" fill="currentColor" opacity="0.8"/>
        
        <path d="M450,450 L650,550" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="5,5" opacity="0.5" />
      </svg>

      <div className="relative z-20 flex flex-col md:flex-row w-full h-full min-h-screen p-8 md:p-16 gap-12">
        
        {/* Left Side: Logo and Menu */}
        <div className="flex-1 flex flex-col justify-center max-w-2xl">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="mb-10"
          >
            <div className="flex items-center gap-3 mb-2 opacity-70">
              <ShieldAlert className="w-6 h-6 text-blood" />
              <span className="font-mono text-sm tracking-widest text-blood uppercase font-bold">Главное командование</span>
            </div>
            <h1 className="font-serif text-6xl sm:text-8xl md:text-9xl font-bold tracking-tighter text-paper-light uppercase leading-none drop-shadow-[0_0_15px_rgba(138,3,3,0.3)]">
              Iron<br/>Dominion
            </h1>
            <div className="w-32 h-1.5 bg-blood mt-6 mb-4 shadow-[0_0_10px_rgba(138,3,3,0.5)]"></div>
            <p className="font-mono text-paper/60 text-sm max-w-md">
              Глобальная 4X стратегия в реальном времени. Война, интриги, шпионаж и тяжелая промышленность.
            </p>
          </motion.div>

          {/* Vertical Menu */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="flex flex-col gap-3 w-full max-w-sm"
          >
            <MenuButton 
              icon={<Play className="w-5 h-5" />} 
              label={canContinue ? "ПРОДОЛЖИТЬ" : "НАЧАТЬ ИГРУ"}
              onClick={handleContinue}
              highlight
            />
            <MenuButton 
              icon={<RotateCcw className="w-5 h-5" />} 
              label="НОВАЯ КАМПАНИЯ" 
              onClick={handleNewCampaign} 
            />
            <MenuButton 
              icon={<BookOpen className="w-5 h-5" />} 
              label="ХРОНИКА МИРА" 
              onClick={handleChronicle} 
            />
            <MenuButton 
              icon={<Shield className="w-5 h-5" />} 
              label="СЦЕНАРИИ" 
              onClick={handleScenarios} 
            />
            <MenuButton 
              icon={<Target className="w-5 h-5" />} 
              label="ОБУЧАЮЩИЙ СЦЕНАРИЙ" 
              onClick={handleTutorial} 
            />
            <div className="my-2 border-t border-paper/10"></div>
            
            <MenuButton 
              icon={<Settings className="w-4 h-4" />} 
              label="НАСТРОЙКИ" 
              onClick={() => alert("Настройки: Дисплей, Аудио, Геймплей")} 
              small
            />
            <MenuButton 
              icon={<Info className="w-4 h-4" />} 
              label={`ОБ ИГРЕ (v${appVersion.versionName})`} 
              onClick={() => alert(`Iron Dominion\nВерсия: v${appVersion.versionName}\nКод сборки: ${appVersion.versionCode}\nПлатформа: Android / Web`)} 
              small
            />
          </motion.div>

          {/* App Version Stamp */}
          <div className="mt-8 flex items-center gap-3 text-[11px] text-paper/40 font-mono">
            <span>Iron Dominion v{appVersion.versionName} (Сборка {appVersion.versionCode})</span>
            <span>•</span>
            <span className="text-paper/30">Верховный Генеральный Штаб</span>
          </div>
        </div>

        {/* Right Side: World Summary */}
        <div className="flex-1 flex flex-col justify-center items-end hidden lg:flex">
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5, duration: 0.8, ease: "easeOut" }}
            className="w-full max-w-md bg-paper/5 border-2 border-paper/10 p-8 shadow-2xl backdrop-blur-sm relative"
          >
            {/* Corner Accents */}
            <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-amber-500/50 -translate-x-[2px] -translate-y-[2px]" />
            <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-amber-500/50 translate-x-[2px] -translate-y-[2px]" />
            <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-amber-500/50 -translate-x-[2px] translate-y-[2px]" />
            <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-amber-500/50 translate-x-[2px] translate-y-[2px]" />

            <div className="text-xs text-amber-500/80 uppercase tracking-widest font-bold mb-6 flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Текущая Сводка
            </div>

            <div className="space-y-6">
              <div>
                <div className="text-paper/40 text-[10px] uppercase mb-1">Дата кампании</div>
                <div className="text-2xl font-serif text-amber-100">{formatDate(gameState.currentDate)}</div>
                <div className="text-paper/60 text-xs mt-1">День {gameState.totalDaysElapsed}</div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <StatBox label="Стабильность" value={`${Math.round(gameState.stability)}%`} color="text-emerald-400" />
                <StatBox label="Боеготовность" value={`${Math.round(gameState.militaryReadiness)}%`} color="text-amber-400" />
                <StatBox label="Военная усталость" value={`${Math.round(gameState.warWeariness)}%`} color="text-blood" />
                <StatBox label="Активные угрозы" value={gameState.activeCrisis ? "1 КРИТИЧЕСКАЯ" : "0"} color={gameState.activeCrisis ? "text-blood" : "text-paper/60"} />
              </div>

              <div className="pt-4 border-t border-paper/10">
                <div className="text-paper/40 text-[10px] uppercase mb-2">Последнее донесение</div>
                {gameState.consequences.length > 0 ? (
                  <div className="text-sm font-serif italic text-paper/80 border-l-2 border-paper/20 pl-3">
                    «{gameState.consequences[gameState.consequences.length - 1].title}»
                  </div>
                ) : (
                  <div className="text-sm font-serif italic text-paper/50 border-l-2 border-paper/20 pl-3">
                    Нет активных донесений. Мир в ожидании ваших приказов.
                  </div>
                )}
              </div>
            </div>
            
            {gameState.activeCrisis && (
              <div className="mt-6 bg-blood/10 border border-blood/30 p-3 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-blood shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs text-blood font-bold uppercase mb-0.5">Внимание: Активный Кризис</div>
                  <div className="text-[10px] text-paper/70 leading-tight">Игра приостановлена. Требуется немедленное решение верховного командования.</div>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function MenuButton({ icon, label, onClick, highlight = false, small = false }: { icon: React.ReactNode, label: string, onClick: () => void, highlight?: boolean, small?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`group flex items-center justify-between w-full text-left transition-all duration-300 border-l-4 
        ${small ? 'p-3 text-sm' : 'p-4 text-base sm:text-lg font-bold'}
        ${highlight 
          ? 'bg-blood border-blood text-paper-light shadow-[0_0_20px_rgba(138,3,3,0.3)] hover:bg-blood/90 hover:pl-6' 
          : 'bg-paper/5 border-paper/20 text-paper/80 hover:bg-paper/10 hover:border-amber-500 hover:text-amber-300 hover:pl-6'
        }
      `}
    >
      <div className="flex items-center gap-4">
        <div className={`transition-transform duration-300 ${highlight ? 'text-paper-light' : 'text-paper/50 group-hover:text-amber-500'} group-hover:scale-110`}>
          {icon}
        </div>
        <span className="tracking-wider uppercase">{label}</span>
      </div>
      <div className={`w-0 h-[1px] transition-all duration-300 group-hover:w-8 ${highlight ? 'bg-paper-light' : 'bg-amber-500'}`}></div>
    </button>
  );
}

function StatBox({ label, value, color }: { label: string, value: string | number, color: string }) {
  return (
    <div className="bg-ink/50 border border-paper/10 p-3">
      <div className="text-paper/40 text-[9px] uppercase tracking-wider mb-1">{label}</div>
      <div className={`text-lg font-bold font-mono ${color}`}>{value}</div>
    </div>
  );
}
