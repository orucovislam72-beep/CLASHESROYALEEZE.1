import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Newspaper, Stamp, Printer, AlertOctagon, TrendingUp, TrendingDown, Users, Flame, CheckCircle2, ShieldCheck, Sparkles, Megaphone, Zap, FileCheck, Lock } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';
import { gameStore } from '../utils/gameStore';

interface HeadlineOption {
  id: string;
  title: string;
  subtitle: string;
  bodyText: string;
  moraleImpact: number;
  industryImpact: number;
  dissentImpact: number;
  tone: 'heroic' | 'alarmist' | 'truthful' | 'conspiratorial';
}

const headlineOptions: HeadlineOption[] = [
  {
    id: 'h1',
    title: '«ТРИУМФ ОРУЖИЯ: ФРОНТ ВРАГА СОКРУШЁН!»',
    subtitle: '1-я бронетанковая группа вошла в Остенмарк под ликование освобождённых жителей',
    bodyText: 'Вчера на рассвете ударные клинья генерального штаба сломили укрепления линии Валленштейна. Враг бежит, бросая артиллерию. Заводы Штальбурга работают в три смены ради окончательного разгрома захватчиков.',
    moraleImpact: +25,
    industryImpact: +15,
    dissentImpact: -10,
    tone: 'heroic'
  },
  {
    id: 'h2',
    title: '«БИТВА ЗА ВЫЖИВАНИЕ: СТОЯТЬ НАСМЕРТЬ!»',
    subtitle: 'Верховный командующий обратился к нации: каждый рабочий — солдат второго рубежа',
    bodyText: 'Ожесточённые бои идут на подступах к реке Ворн. Потери велики, но отступать некуда — позади угольные шахты и семьи. Вводится карточная система распределения угля и хлеба.',
    moraleImpact: -5,
    industryImpact: +20,
    dissentImpact: +15,
    tone: 'alarmist'
  },
  {
    id: 'h3',
    title: '«ТАЙНЫЙ СИНДИКАТ: КТО НАЖИВАЕТСЯ НА КРОВИ?»',
    subtitle: 'Специальное расследование о поставках швейцарской стали по обе стороны фронта',
    bodyText: 'Документы, перехваченные военной контрразведкой, доказывают: банкиры Базеля финансируют обе армии. Солдаты в окопах требуют суда над международными спекулянтами.',
    moraleImpact: -15,
    industryImpact: -10,
    dissentImpact: +30,
    tone: 'conspiratorial'
  },
  {
    id: 'h4',
    title: '«ВЕРНОСТЬ И ПОРЯДОК: ПРОВОКАТОРЫ РАЗОБЛАЧЕНЫ»',
    subtitle: 'Суд военного трибунала вынес приговор саботажникам на Корсакском оружейном заводе',
    bodyText: 'Попытка забастовки на сталелитейном комбинате пресечена силами гарнизона. Провокаторы, работавшие по указке иностранной разведки, понесли заслуженную кару. Производство снарядов возобновлено.',
    moraleImpact: +10,
    industryImpact: +25,
    dissentImpact: +5,
    tone: 'truthful'
  }
];

export default function PropagandaGazette() {
  const [selectedHeadline, setSelectedHeadline] = useState<HeadlineOption>(headlineOptions[0]);
  const [stampStatus, setStampStatus] = useState<'approved' | 'censored' | 'urgent'>('approved');
  const [editorialDate, setEditorialDate] = useState<string>('15 ОКТЯБРЯ 1938 ГОДА');
  const [isPrinting, setIsPrinting] = useState<boolean>(false);
  const [printSuccessMessage, setPrintSuccessMessage] = useState<string | null>(null);

  // State Gauges
  const [publicMorale, setPublicMorale] = useState<number>(70);
  const [factoryOutput, setFactoryOutput] = useState<number>(85);
  const [dissentLevel, setDissentLevel] = useState<number>(20);

  const handleSelectHeadline = (h: HeadlineOption) => {
    setSelectedHeadline(h);
    audioEngine.playMorseBeep(false);
  };

  const handleApplyStamp = (status: 'approved' | 'censored' | 'urgent') => {
    setStampStatus(status);
    audioEngine.playMorseBeep(true);
  };

  const handlePrintEdition = () => {
    setIsPrinting(true);
    audioEngine.playTuningSweep();

    setTimeout(() => {
      setIsPrinting(false);
      // Recalculate metrics
      setPublicMorale(prev => Math.max(10, Math.min(100, prev + selectedHeadline.moraleImpact)));
      setFactoryOutput(prev => Math.max(10, Math.min(100, prev + selectedHeadline.industryImpact)));
      setDissentLevel(prev => Math.max(0, Math.min(100, prev + selectedHeadline.dissentImpact)));

      // Synchronize with unified game state & chronicle
      const stance = selectedHeadline.tone === 'heroic' ? 'militarist' : (selectedHeadline.tone === 'conspiratorial' ? 'censored' : 'calm');
      gameStore.publishGazetteHeadline(selectedHeadline.title, stance, 120);

      setPrintSuccessMessage(`Утренний тираж (250,000 экземпляров) успешно отпечатан в типографии Штальбурга! Внесено в Хронику Мира.`);
    }, 1500);
  };

  return (
    <div className="w-full bg-paper/90 border-2 border-ink p-4 md:p-6 font-sans text-ink relative shadow-[4px_4px_0_var(--color-ink)]">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-ink text-paper-light flex items-center justify-center border border-ink">
            <Newspaper className="w-6 h-6 text-blood" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-xl md:text-2xl uppercase tracking-tight text-ink">
              Главная Редакция // «Штальбургские Ведомости»
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Верстка утреннего выпуска, военная цензура и контроль общественного мнения
            </span>
          </div>
        </div>

        {/* Status indicator */}
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs text-ink/70 uppercase">ТИРАЖ: 250,000 ЭКЗ.</span>
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse" />
        </div>
      </div>

      {/* Grid: Left Editor & Selector, Right Newspaper Broadsheet View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Headline Selector & Censorship Controls (5 Cols) */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          
          {/* Public Mood & Impact Gauges */}
          <div className="bg-paper-light border border-ink/20 p-3 font-mono text-xs">
            <span className="text-[10px] uppercase font-bold text-ink/50 block border-b border-ink/15 pb-1 mb-2">
              Барометр Настроений Населения:
            </span>
            
            <div className="space-y-2 text-[10px]">
              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-ink/70">Моральный дух нации:</span>
                  <span className="font-bold text-ink">{publicMorale}%</span>
                </div>
                <div className="w-full bg-ink/10 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-full transition-all" style={{ width: `${publicMorale}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-ink/70">Производительность военных заводов:</span>
                  <span className="font-bold text-ink">{factoryOutput}%</span>
                </div>
                <div className="w-full bg-ink/10 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-blue-600 h-full transition-all" style={{ width: `${factoryOutput}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between mb-0.5">
                  <span className="text-ink/70">Угроза забастовок и бунта:</span>
                  <span className={`font-bold ${dissentLevel > 40 ? 'text-blood' : 'text-ink'}`}>{dissentLevel}%</span>
                </div>
                <div className="w-full bg-ink/10 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-blood h-full transition-all" style={{ width: `${dissentLevel}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Headline Selector */}
          <div className="space-y-2">
            <span className="font-mono text-[10px] uppercase text-ink/50 block">
              Выберите главный заголовок передовицы:
            </span>
            {headlineOptions.map(option => {
              const isSelected = option.id === selectedHeadline.id;
              return (
                <div
                  key={option.id}
                  onClick={() => handleSelectHeadline(option)}
                  className={`p-3 border cursor-pointer transition-all flex flex-col gap-1 relative ${
                    isSelected
                      ? 'bg-ink text-paper-light border-blood shadow-md'
                      : 'bg-paper-light hover:bg-paper-dark/30 border-ink/20'
                  }`}
                >
                  {isSelected && <div className="absolute left-0 top-0 bottom-0 w-1 bg-blood" />}
                  <span className="font-serif font-bold text-xs sm:text-sm leading-tight">
                    {option.title}
                  </span>
                  <div className="flex items-center gap-2 text-[9px] font-mono mt-1 opacity-70">
                    <span>Мораль: {option.moraleImpact > 0 ? `+${option.moraleImpact}` : option.moraleImpact}%</span>
                    <span>•</span>
                    <span>Бунт: {option.dissentImpact > 0 ? `+${option.dissentImpact}` : option.dissentImpact}%</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Censor Stamps Toolbar */}
          <div className="bg-ink/5 p-3 border border-ink/20 font-mono text-xs">
            <span className="text-[10px] uppercase font-bold text-ink/60 block mb-2">
              Штамп Военной Цензуры:
            </span>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                onClick={() => handleApplyStamp('approved')}
                className={`py-1.5 px-2 text-[9px] uppercase font-bold border transition-all ${
                  stampStatus === 'approved'
                    ? 'bg-emerald-800 text-paper-light border-emerald-900 shadow-sm'
                    : 'bg-paper hover:bg-ink/10 text-ink border-ink/20'
                }`}
              >
                ОДОБРЕНО
              </button>
              <button
                onClick={() => handleApplyStamp('urgent')}
                className={`py-1.5 px-2 text-[9px] uppercase font-bold border transition-all ${
                  stampStatus === 'urgent'
                    ? 'bg-blood text-paper-light border-blood shadow-sm'
                    : 'bg-paper hover:bg-ink/10 text-ink border-ink/20'
                }`}
              >
                ЭКСТРЕННО
              </button>
              <button
                onClick={() => handleApplyStamp('censored')}
                className={`py-1.5 px-2 text-[9px] uppercase font-bold border transition-all ${
                  stampStatus === 'censored'
                    ? 'bg-black text-paper-light border-black shadow-sm'
                    : 'bg-paper hover:bg-ink/10 text-ink border-ink/20'
                }`}
              >
                СЕКРЕТНО
              </button>
            </div>
          </div>

          {/* Print Button */}
          <button
            onClick={handlePrintEdition}
            disabled={isPrinting}
            className="w-full py-2.5 bg-blood text-paper-light font-mono text-xs uppercase font-bold hover:bg-ink transition-all flex items-center justify-center gap-2 shadow-[2px_2px_0_var(--color-ink)] active:translate-x-0.5 active:translate-y-0.5 disabled:opacity-50"
          >
            {isPrinting ? (
              <>
                <Printer className="w-4 h-4 animate-spin text-amber-300" />
                <span>ИДЁТ ПЕЧАТЬ В ТИПОГРАФИИ...</span>
              </>
            ) : (
              <>
                <Printer className="w-4 h-4 text-amber-300" />
                <span>Отпечатать утренний выпуск в ротацию</span>
              </>
            )}
          </button>
        </div>

        {/* Right: Realistic 1930s Broadsheet Layout (7 Cols) */}
        <div className="lg:col-span-7 bg-[#fbf7ee] border-4 border-double border-ink p-5 md:p-6 shadow-xl relative text-ink font-serif flex flex-col justify-between">
          
          {/* Newspaper Masthead */}
          <div className="text-center border-b-4 border-ink pb-3 mb-4 relative">
            <div className="flex justify-between font-mono text-[9px] uppercase text-ink/70 border-b border-ink/20 pb-1 mb-2">
              <span>ВЫПУСК № 4,182 (УТРЕННИЙ)</span>
              <span>ЦЕНА: 15 ПФЕННИГОВ</span>
              <span>{editorialDate}</span>
            </div>

            <h1 className="text-3xl md:text-5xl font-black uppercase tracking-tight text-ink font-serif">
              ШТАЛЬБУРГСКІЯ ВѢДОМОСТИ
            </h1>
            <div className="font-mono text-[10px] tracking-widest text-ink/80 uppercase mt-0.5">
              Ежедневный органъ верховнаго командованія и государственной думы
            </div>

            {/* Dynamic Visual Stamp overlaid on top corner */}
            <div className="absolute top-2 right-2 transform rotate-12 pointer-events-none">
              {stampStatus === 'approved' && (
                <div className="border-2 border-emerald-800 text-emerald-800 font-mono text-[9px] font-bold px-2 py-0.5 uppercase tracking-widest bg-emerald-50/80 flex items-center gap-1">
                  <FileCheck className="w-3 h-3 text-emerald-800" />
                  <span>ЦЕНЗУРА: ДОПУЩЕНО К ПЕЧАТИ</span>
                </div>
              )}
              {stampStatus === 'urgent' && (
                <div className="border-2 border-blood text-blood font-mono text-[9px] font-bold px-2 py-0.5 uppercase tracking-widest bg-red-50/80 animate-pulse flex items-center gap-1">
                  <Zap className="w-3 h-3 text-blood fill-blood" />
                  <span>ЭКСТРЕННЫЙ ВЫПУСК №1</span>
                </div>
              )}
              {stampStatus === 'censored' && (
                <div className="border-2 border-black text-black font-mono text-[9px] font-bold px-2 py-0.5 uppercase tracking-widest bg-amber-200/80 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-black" />
                  <span>ДЛЯ СЛУЖЕБНОГО ПОЛЬЗОВАНИЯ</span>
                </div>
              )}
            </div>
          </div>

          {/* Lead Headline Article */}
          <div className="mb-4">
            <h2 className="text-xl md:text-2xl font-bold uppercase leading-tight text-blood mb-1 font-serif">
              {selectedHeadline.title}
            </h2>
            <h3 className="font-sans font-bold text-xs md:text-sm text-ink/80 italic mb-3">
              {selectedHeadline.subtitle}
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-serif leading-relaxed text-ink/90">
              <p className="first-letter:text-3xl first-letter:font-bold first-letter:float-left first-letter:mr-1.5 first-letter:text-ink">
                {selectedHeadline.bodyText}
              </p>
              <div className="p-2.5 bg-ink/5 border border-ink/20 font-sans text-[11px] flex flex-col justify-between">
                <span className="font-bold text-ink uppercase text-[10px] block mb-1">
                  Сводка Информбюро:
                </span>
                <span className="text-ink/80 italic text-[10px]">
                  «Все граждане обязаны соблюдать светомаскировку с 21:00. При обнаружении подозрительных радиосигналов немедленно докладывать комендатуре.»
                </span>
                <div className="mt-2 text-right font-mono text-[8px] text-ink/50 uppercase">
                  Подпись: Комендант Штальбурга
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Columns (Woodcut Caricature & Secondary Chronicle) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 border-t-2 border-ink pt-3 font-sans text-xs">
            
            {/* Column 1: Woodcut Illustration / Propaganda Graphic */}
            <div className="border-r border-ink/20 pr-2 flex flex-col items-center text-center">
              <div className="w-full aspect-[4/3] bg-ink/10 border border-ink/30 flex items-center justify-center p-2 mb-1">
                <div className="border border-dashed border-ink/40 p-2 w-full h-full flex flex-col items-center justify-center text-center">
                  <Megaphone className="w-6 h-6 text-blood mb-1" />
                  <span className="font-serif text-[9px] uppercase font-bold">«СТАЛЬ — НАШЕМУ ФРОНТУ!»</span>
                </div>
              </div>
              <span className="font-serif text-[8px] text-ink/60 italic">Агитационный плакат №14</span>
            </div>

            {/* Column 2: Commercial & Rationing Notes */}
            <div className="border-r border-ink/20 pr-2">
              <span className="font-serif font-bold text-[10px] uppercase block mb-1">Нормы Снабжения:</span>
              <p className="font-serif text-[9px] text-ink/80 leading-snug">
                Хлебная норма на одного рабочего повышена на 50г. Выдача сахара производится по талонам серии "Б-3".
              </p>
            </div>

            {/* Column 3: Stock Exchange & Foreign Cable */}
            <div>
              <span className="font-serif font-bold text-[10px] uppercase block mb-1">Биржевой Вестник:</span>
              <p className="font-serif text-[9px] text-ink/80 leading-snug">
                Акции угольного синдиката выросли на 12%. Курс швейцарского франка в Базеле остаётся стабильным.
              </p>
            </div>
          </div>

          {/* Success Banner */}
          {printSuccessMessage && (
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-3 p-2 bg-emerald-950 text-paper-light font-mono text-[10px] border border-emerald-600 flex items-center gap-2"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>{printSuccessMessage}</span>
            </motion.div>
          )}

        </div>
      </div>

    </div>
  );
}
