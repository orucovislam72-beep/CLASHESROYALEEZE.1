import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, X, Eye, Skull, ShieldAlert, Flame, 
  Lock, Unlock, ChevronRight, Binary, AlertCircle,
  CheckCircle, Database, Radio, Search
} from 'lucide-react';
import { GameState, SecretScenario } from '../utils/gameState';
import { gameStore } from '../utils/gameStore';
import { audioEngine } from '../utils/audioEngine';

interface SecretScenariosModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToColossus?: () => void;
}

export default function SecretScenariosModal({ 
  isOpen, 
  onClose,
  onNavigateToColossus 
}: SecretScenariosModalProps) {
  const [state, setState] = useState<GameState>(gameStore.getState());
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(state.secretScenarios[0]?.id || 'colossus');

  React.useEffect(() => {
    return gameStore.subscribe(setState);
  }, []);

  if (!isOpen) return null;

  const selectedScenario = state.secretScenarios.find(s => s.id === selectedScenarioId) || state.secretScenarios[0];

  const getScenarioIcon = (id: string) => {
    switch (id) {
      case 'colossus': return <Sparkles className="w-5 h-5 text-amber-300" />;
      case 'black_sun': return <Eye className="w-5 h-5 text-purple-400" />;
      case 'dead_hand': return <Skull className="w-5 h-5 text-red-500" />;
      case 'phantom': return <ShieldAlert className="w-5 h-5 text-cyan-400" />;
      case 'red_meridian': return <Flame className="w-5 h-5 text-orange-400" />;
      default: return <Database className="w-5 h-5 text-amber-300" />;
    }
  };

  const handleApplyCountermeasure = () => {
    if (!selectedScenario.countermeasureAvailable) return;

    gameStore.addChronicleEntry({
      id: `countermeasure_${Date.now()}`,
      timestamp: `${state.currentDate.day} АВГ ${state.currentDate.year}`,
      dayCount: state.totalDaysElapsed,
      category: 'secret',
      title: `АКТИВАЦИЯ ПРОТОКОЛА: ПЕРЕХВАТ «${selectedScenario.code}»`,
      details: `Главный Штаб применил контрмеры против заговора «${selectedScenario.name}». Угроза нейтрализована.`,
      badge: 'НЕЙТРАЛИЗАЦИЯ',
      impactColor: '#059669'
    });

    audioEngine.playClick('heavy');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-xs font-mono">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        transition={{ duration: 0.25 }}
        className="w-full max-w-5xl max-h-[92vh] bg-[#0d1117] text-paper-light border-4 border-purple-900 shadow-2xl flex flex-col relative overflow-hidden"
      >
        {/* Top Classified Header */}
        <div className="bg-purple-950 text-paper-light p-3 sm:p-4 flex items-center justify-between border-b-2 border-amber-300">
          <div className="flex items-center gap-3">
            <Sparkles className="w-6 h-6 text-amber-300 animate-spin-slow" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-widest text-amber-300 font-bold">
                  ЗАСЕКРЕЧЕННЫЕ СЦЕНАРИИ МИРА // GLOBAL CONSPIRACIES
                </span>
                <span className="px-1.5 py-0.5 bg-blood text-paper-light text-[9px] font-mono font-bold">
                  LEVEL 5 // COSMIC TOP SECRET
                </span>
              </div>
              <h2 className="text-base sm:text-xl font-bold tracking-tight">
                Тайные Глобальные Сценарии (5 Мега-Сюжетов)
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              audioEngine.playClick('switch');
              onClose();
            }}
            className="p-1.5 bg-black/40 hover:bg-black text-paper-light border border-amber-300/40 transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Narrative Description Banner */}
        <div className="bg-purple-900/30 border-b border-purple-800/40 p-2.5 px-4 text-xs text-purple-200 flex items-center justify-between">
          <span>Скрытые силы действуют в тени войны. Ваши радиоперехваты, агенты и решения трибунала собирают улики.</span>
          <span className="font-bold text-amber-300">НАЙДЕНО УЛИК: {state.secretScenarios.reduce((a, b) => a + b.cluesFound.length, 0)}/20</span>
        </div>

        {/* Main Content Layout */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-5">
          
          {/* Left Column: 5 Scenarios List (5 cols) */}
          <div className="md:col-span-5 flex flex-col gap-2.5">
            {state.secretScenarios.map(sc => (
              <div
                key={sc.id}
                onClick={() => {
                  audioEngine.playClick('switch');
                  setSelectedScenarioId(sc.id);
                }}
                className={`p-3 border transition-all cursor-pointer ${
                  selectedScenarioId === sc.id
                    ? 'bg-purple-950/70 border-amber-300 shadow-md'
                    : 'bg-paper/5 hover:bg-paper/10 border-purple-900/40'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    {getScenarioIcon(sc.id)}
                    <span className="text-xs font-bold text-amber-200 tracking-wider">
                      {sc.code}
                    </span>
                  </div>
                  <span className="text-[10px] text-purple-300 font-bold">
                    ЭТАП {sc.unlockedStage}/4
                  </span>
                </div>

                <div className="text-xs font-serif font-bold text-paper-light mb-2">
                  {sc.name}
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-black/60 h-2 border border-purple-800/50 mb-1 overflow-hidden">
                  <div 
                    className="bg-amber-400 h-full transition-all duration-300"
                    style={{ width: `${sc.progressPercent}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[10px] text-paper/60">
                  <span>Расшифровано: <strong className="text-amber-300">{sc.progressPercent}%</strong></span>
                  <span>Улик: {sc.cluesFound.length}/{sc.maxClues}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Right Column: Selected Scenario Dossier (7 cols) */}
          <div className="md:col-span-7 bg-black/40 border border-purple-900/50 p-4 sm:p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-purple-800/50 pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-purple-900/60 text-amber-300 border border-purple-700 text-[10px] font-bold">
                    ДОСЬЕ: {selectedScenario.code}
                  </span>
                  <span className="text-xs text-paper/60">
                    // СТАТУС: {selectedScenario.status.toUpperCase()}
                  </span>
                </div>
              </div>

              <h3 className="text-lg font-bold font-serif text-amber-200 mb-2">
                {selectedScenario.name}
              </h3>

              <p className="text-sm font-serif text-paper-light/90 leading-relaxed italic bg-purple-950/40 p-3 border-l-2 border-amber-300 mb-4">
                «{selectedScenario.summary}»
              </p>

              {/* Decrypted Clues Archive */}
              <div className="mb-4">
                <div className="text-xs font-bold uppercase text-amber-300 mb-2 flex items-center gap-1.5">
                  <Binary className="w-3.5 h-3.5" />
                  <span>РАСШИФРОВАННЫЕ УЛИКИ И ПЕРЕХВАТЫ:</span>
                </div>

                {selectedScenario.cluesFound.length === 0 ? (
                  <div className="p-3 bg-black/50 border border-purple-900/30 text-xs text-paper/40 italic">
                    Улики пока не обнаружены. Направляйте агентов IV управления на перехват кабелей и слушайте частоту 1939 кГц.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {selectedScenario.cluesFound.map((clue, idx) => (
                      <div 
                        key={idx}
                        className="p-2.5 bg-paper/5 border border-purple-800/40 text-xs text-purple-200 flex items-start gap-2"
                      >
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span className="font-serif leading-relaxed">{clue}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-purple-800/50 mt-2 flex flex-col gap-2">
              {selectedScenario.id === 'colossus' && onNavigateToColossus && (
                <button
                  onClick={() => {
                    audioEngine.playClick('heavy');
                    onClose();
                    onNavigateToColossus();
                  }}
                  className="w-full py-2.5 bg-blood hover:bg-blood-hover text-paper-light font-bold text-xs uppercase tracking-wider border border-amber-300 shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>ПЕРЕЙТИ В ЦЕХ ПРОЕКТА «КОЛОСС-IX»</span>
                </button>
              )}

              {selectedScenario.countermeasureAvailable ? (
                <button
                  onClick={handleApplyCountermeasure}
                  className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-700 text-paper-light font-bold text-xs uppercase tracking-wider border border-emerald-400 shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <ShieldAlert className="w-4 h-4 text-amber-300" />
                  <span>ПРИМЕНИТЬ КОНТРМЕРЫ ШТАБА</span>
                </button>
              ) : (
                <div className="text-[11px] text-paper/50 text-center italic">
                  Соберите больше улик через шпионаж и радиоперехваты для разблокировки контрмер.
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="bg-black border-t border-purple-900/60 p-2.5 px-4 flex items-center justify-between text-xs text-purple-400">
          <span>Специальный протокол архивации №7</span>
          <span className="uppercase text-[10px]">VERWALTUNG DER SCHATTENAKTEN</span>
        </div>
      </motion.div>
    </div>
  );
}
