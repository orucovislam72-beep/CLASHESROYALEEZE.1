import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Wrench, Shield, Zap, Gauge, DollarSign, Crosshair, Play, CheckCircle, RotateCcw, AlertTriangle, Layers, Flame, Compass, Settings, Pickaxe, Database, Factory } from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';
import { gameStore } from '../utils/gameStore';

interface HullOption {
  id: string;
  name: string;
  armor: number;
  weight: number;
  costSteel: number;
}

interface GunOption {
  id: string;
  name: string;
  firepower: number;
  penetration: number; // mm
  ammoWeight: number;
  costSteel: number;
}

interface EngineOption {
  id: string;
  name: string;
  power: number; // hp
  speedBonus: number;
  reliability: number;
  costCoal: number;
}

interface ModuleOption {
  id: string;
  name: string;
  description: string;
  bonus: string;
  cost: number;
}

const hullOptions: HullOption[] = [
  { id: 'h_light', name: 'Легкобронный сварной корпус (35 мм)', armor: 35, weight: 14, costSteel: 120 },
  { id: 'h_medium', name: 'Средний клёпаный корпус «Шталь» (65 мм)', armor: 65, weight: 26, costSteel: 240 },
  { id: 'h_heavy', name: 'Тяжёлый литой монолит (110 мм)', armor: 110, weight: 48, costSteel: 450 },
  { id: 'h_train', name: 'Бронированная ж/д платформа (140 мм)', armor: 140, weight: 90, costSteel: 700 }
];

const gunOptions: GunOption[] = [
  { id: 'g_45', name: '45-мм скорострельная пушка 20-К', firepower: 40, penetration: 55, ammoWeight: 4, costSteel: 80 },
  { id: 'g_76', name: '76-мм дивизионная пушка Ф-34', firepower: 70, penetration: 82, ammoWeight: 8, costSteel: 160 },
  { id: 'g_88', name: '88-мм зенитно-танковое орудие KwK-36', firepower: 95, penetration: 135, ammoWeight: 14, costSteel: 280 },
  { id: 'g_152', name: '152-мм осадная гаубица-мортира М-10', firepower: 120, penetration: 90, ammoWeight: 22, costSteel: 360 }
];

const engineOptions: EngineOption[] = [
  { id: 'e_gas', name: 'Карбюраторный Maybach HL120 (300 л.с.)', power: 300, speedBonus: 38, reliability: 88, costCoal: 50 },
  { id: 'e_diesel', name: 'V-образный 12-цил. Дизель В-2 (500 л.с.)', power: 500, speedBonus: 48, reliability: 92, costCoal: 80 },
  { id: 'e_steam', name: 'Паротурбинная установка «Вулкан» (1100 л.с.)', power: 1100, speedBonus: 28, reliability: 74, costCoal: 190 }
];

const moduleOptions: ModuleOption[] = [
  { id: 'm_radio', name: 'Командирская радиостанция 50-Вт', description: '+25% к точности огня по наводке', bonus: '+25% Координация', cost: 60 },
  { id: 'm_tracks', name: 'Уширенные зимние гусеницы', description: 'Преодоление глубокой грязи и снега', bonus: '+15% Проходимость', cost: 45 },
  { id: 'm_smoke', name: 'Бортовые дымовые мортиры', description: 'Быстрая маскировка при отступлении', bonus: '+20% Живучесть', cost: 35 },
  { id: 'm_armor_skirts', name: 'Навесные противокумулятивные экраны', description: 'Защита бортов от бронебойных ружей', bonus: '+25 мм Борт', cost: 75 }
];

export default function ArsenalDesigner() {
  const [vehicleName, setVehicleName] = useState<string>('«Шталь-Танк V Панцирь»');
  const [selectedHull, setSelectedHull] = useState<HullOption>(hullOptions[1]);
  const [selectedGun, setSelectedGun] = useState<GunOption>(gunOptions[2]);
  const [selectedEngine, setSelectedEngine] = useState<EngineOption>(engineOptions[1]);
  const [selectedModules, setSelectedModules] = useState<string[]>(['m_radio', 'm_tracks']);

  const [isTesting, setIsTesting] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<string | null>(null);

  // Dynamic Calculated Properties
  const totalArmor = selectedHull.armor + (selectedModules.includes('m_armor_skirts') ? 25 : 0);
  const totalFirepower = selectedGun.firepower + (selectedModules.includes('m_radio') ? 15 : 0);
  const totalWeight = selectedHull.weight + selectedGun.ammoWeight + (selectedModules.length * 2);
  const calculatedSpeed = Math.max(12, Math.round((selectedEngine.power / totalWeight) * 2.1));
  const totalReliability = Math.max(40, selectedEngine.reliability - Math.round(totalWeight * 0.3));
  const totalCostSteel = selectedHull.costSteel + selectedGun.costSteel + (selectedModules.length * 50);
  const totalCostCoal = selectedEngine.costCoal + 30;

  const toggleModule = (id: string) => {
    setSelectedModules(prev => 
      prev.includes(id) ? prev.filter(m => m !== id) : [...prev, id]
    );
    audioEngine.playMorseBeep(false);
  };

  const handleRunPolygonTest = () => {
    setIsTesting(true);
    audioEngine.playTuningSweep();
    audioEngine.playMorseBeep(true);

    setTimeout(() => {
      setIsTesting(false);
      const isReliable = totalReliability > 65;
      const speedScore = calculatedSpeed > 30 ? 'ВЫСОКАЯ' : 'УДОВЛЕТВОРИТЕЛЬНАЯ';
      setTestResult(
        `[РЕЗУЛЬТАТЫ ПОЛИГОНА] Опытный образец ${vehicleName} прошёл 100-километровый марш. Пробитие мишени: ${selectedGun.penetration} мм брони. Скорость: ${calculatedSpeed} км/ч (${speedScore}). Надёжность трансмиссии: ${isReliable ? 'В НОРМЕ' : 'ТРЕБУЕТ ДОРАБОТКИ'}. Одобрено к серийному заказу на заводах Штальбурга!`
      );
    }, 1400);
  };

  return (
    <div className="w-full bg-paper/90 border-2 border-ink p-4 md:p-6 font-sans text-ink relative shadow-[4px_4px_0_var(--color-ink)]">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-ink text-paper-light flex items-center justify-center border border-ink">
            <Wrench className="w-6 h-6 text-blood" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-xl md:text-2xl uppercase tracking-tight text-ink">
              Конструкторское Бюро №7 // Дизельпанк Арсенал
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Модульная сборка бронетехники, расчет веса, брони, орудия и заводской стоимости
            </span>
          </div>
        </div>

        {/* Blueprint ID */}
        <div className="bg-ink text-paper-light px-3 py-1 font-mono text-xs font-bold border border-ink">
          ЧЕРТЁЖ: KB-1938-X
        </div>
      </div>

      {/* Main Grid: Left Configuration Knobs, Right Blueprints & Technical Specs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Component Selectors (6 Cols) */}
        <div className="lg:col-span-6 flex flex-col gap-4">
          
          {/* Vehicle Name input */}
          <div className="bg-paper-light p-3 border border-ink/20 font-mono text-xs">
            <label className="block text-[10px] uppercase font-bold text-ink/60 mb-1">
              Название проекта боевой машины:
            </label>
            <input
              type="text"
              value={vehicleName}
              onChange={(e) => setVehicleName(e.target.value)}
              className="w-full bg-paper border border-ink px-2.5 py-1.5 font-serif font-bold text-base text-ink focus:outline-none focus:ring-1 focus:ring-blood"
            />
          </div>

          {/* 1. Hull Type */}
          <div className="bg-paper-light p-3 border border-ink/20 font-mono text-xs">
            <span className="text-[10px] uppercase font-bold text-blood block border-b border-ink/15 pb-1 mb-2">
              1. Тип корпуса и толщина брони:
            </span>
            <div className="space-y-1.5">
              {hullOptions.map(h => (
                <div
                  key={h.id}
                  onClick={() => { setSelectedHull(h); audioEngine.playMorseBeep(false); }}
                  className={`p-2 border cursor-pointer transition-all flex items-center justify-between ${
                    selectedHull.id === h.id ? 'bg-ink text-paper-light border-blood shadow-sm' : 'bg-paper hover:bg-ink/5 border-ink/15 text-ink'
                  }`}
                >
                  <span className="font-bold text-[11px]">{h.name}</span>
                  <span className="text-[9px] opacity-80">{h.costSteel} т. стали</span>
                </div>
              ))}
            </div>
          </div>

          {/* 2. Main Gun */}
          <div className="bg-paper-light p-3 border border-ink/20 font-mono text-xs">
            <span className="text-[10px] uppercase font-bold text-blood block border-b border-ink/15 pb-1 mb-2">
              2. Главное танковое орудие:
            </span>
            <div className="space-y-1.5">
              {gunOptions.map(g => (
                <div
                  key={g.id}
                  onClick={() => { setSelectedGun(g); audioEngine.playMorseBeep(false); }}
                  className={`p-2 border cursor-pointer transition-all flex items-center justify-between ${
                    selectedGun.id === g.id ? 'bg-ink text-paper-light border-blood shadow-sm' : 'bg-paper hover:bg-ink/5 border-ink/15 text-ink'
                  }`}
                >
                  <span className="font-bold text-[11px]">{g.name}</span>
                  <span className="text-[9px] opacity-80">Пробитие: {g.penetration} мм</span>
                </div>
              ))}
            </div>
          </div>

          {/* 3. Engine */}
          <div className="bg-paper-light p-3 border border-ink/20 font-mono text-xs">
            <span className="text-[10px] uppercase font-bold text-blood block border-b border-ink/15 pb-1 mb-2">
              3. Силовая установка (Двигатель):
            </span>
            <div className="space-y-1.5">
              {engineOptions.map(e => (
                <div
                  key={e.id}
                  onClick={() => { setSelectedEngine(e); audioEngine.playMorseBeep(false); }}
                  className={`p-2 border cursor-pointer transition-all flex items-center justify-between ${
                    selectedEngine.id === e.id ? 'bg-ink text-paper-light border-blood shadow-sm' : 'bg-paper hover:bg-ink/5 border-ink/15 text-ink'
                  }`}
                >
                  <span className="font-bold text-[11px]">{e.name}</span>
                  <span className="text-[9px] opacity-80">{e.power} л.с.</span>
                </div>
              ))}
            </div>
          </div>

          {/* 4. Special Equipment Modules */}
          <div className="bg-paper-light p-3 border border-ink/20 font-mono text-xs">
            <span className="text-[10px] uppercase font-bold text-blood block border-b border-ink/15 pb-1 mb-2">
              4. Специальное фронтовое оборудование:
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {moduleOptions.map(m => {
                const isSelected = selectedModules.includes(m.id);
                return (
                  <div
                    key={m.id}
                    onClick={() => toggleModule(m.id)}
                    className={`p-2 border cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected ? 'bg-ink text-paper-light border-blood' : 'bg-paper hover:bg-ink/5 border-ink/15 text-ink'
                    }`}
                  >
                    <span className="font-bold text-[10px] leading-tight">{m.name}</span>
                    <span className={`text-[8px] mt-1 ${isSelected ? 'text-amber-300' : 'text-ink/60'}`}>{m.bonus}</span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Right: Technical Blueprint & Dynamic Calculations (6 Cols) */}
        <div className="lg:col-span-6 flex flex-col gap-4">
          
          {/* Engineering Blueprint Canvas */}
          <div className="bg-[#1c2b36] border-2 border-ink p-5 text-[#9ed3f2] font-mono shadow-inner relative overflow-hidden flex flex-col justify-between min-h-[320px]">
            {/* Blueprint Grid pattern */}
            <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#9ed3f2_1px,transparent_1px)] [background-size:16px_16px]" />

            <div>
              <div className="flex justify-between border-b border-[#9ed3f2]/30 pb-2 mb-3 text-xs">
                <span className="font-bold uppercase tracking-widest text-[#72b7e0]">ТЕХНИЧЕСКИЙ ПАСПОРТ МАШИНЫ</span>
                <span>МАСШТАБ 1:20</span>
              </div>

              <h4 className="font-serif font-bold text-2xl uppercase tracking-tight text-white mb-3">
                {vehicleName}
              </h4>

              {/* Graphical Tank Silhouette Schematic */}
              <div className="w-full h-28 border border-dashed border-[#9ed3f2]/40 bg-[#142029]/80 flex items-center justify-center p-3 mb-4 relative">
                {/* SVG Schematic Blueprint Tank */}
                <svg className="w-48 h-20 text-[#9ed3f2]" viewBox="0 0 160 80" fill="none" stroke="currentColor" strokeWidth="1.5">
                  {/* Gun Barrel */}
                  <line x1="10" y1="35" x2="80" y2="35" strokeWidth="3" />
                  <rect x="5" y="32" width="8" height="6" fill="currentColor" />
                  {/* Turret */}
                  <path d="M60,45 L75,25 L115,25 L125,45 Z" fill="#1c2b36" strokeWidth="2" />
                  {/* Cupola */}
                  <rect x="90" y="20" width="15" height="5" />
                  {/* Hull */}
                  <path d="M30,45 L145,45 L155,60 L20,60 Z" fill="#1c2b36" strokeWidth="2" />
                  {/* Tracks */}
                  <rect x="25" y="60" width="125" height="15" rx="7" fill="#142029" strokeWidth="2" />
                  {/* Road Wheels */}
                  <circle cx="42" cy="67" r="5" fill="none" strokeWidth="1.5" />
                  <circle cx="62" cy="67" r="5" fill="none" strokeWidth="1.5" />
                  <circle cx="82" cy="67" r="5" fill="none" strokeWidth="1.5" />
                  <circle cx="102" cy="67" r="5" fill="none" strokeWidth="1.5" />
                  <circle cx="122" cy="67" r="5" fill="none" strokeWidth="1.5" />
                </svg>

                <span className="absolute bottom-1 right-2 text-[8px] opacity-60">СХЕМА БРОНИРОВАНИЯ</span>
              </div>

              {/* Dynamic Key Specs Matrix */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-[#142029] p-2.5 border border-[#9ed3f2]/20">
                  <span className="text-[9px] opacity-70 block">ОГНЕВАЯ МОЩЬ:</span>
                  <span className="text-lg font-bold text-amber-300">{totalFirepower} pts</span>
                  <div className="text-[8px] opacity-60">Пробитие: {selectedGun.penetration} мм</div>
                </div>

                <div className="bg-[#142029] p-2.5 border border-[#9ed3f2]/20">
                  <span className="text-[9px] opacity-70 block">БРОНЕВАЯ ЗАЩИТА:</span>
                  <span className="text-lg font-bold text-emerald-300">{totalArmor} мм</span>
                  <div className="text-[8px] opacity-60">Масса: {totalWeight} тонн</div>
                </div>

                <div className="bg-[#142029] p-2.5 border border-[#9ed3f2]/20">
                  <span className="text-[9px] opacity-70 block">СКОРОСТЬ ПО ШОССЕ:</span>
                  <span className="text-lg font-bold text-sky-300">{calculatedSpeed} км/ч</span>
                  <div className="text-[8px] opacity-60">Мощность: {selectedEngine.power} л.с.</div>
                </div>

                <div className="bg-[#142029] p-2.5 border border-[#9ed3f2]/20">
                  <span className="text-[9px] opacity-70 block">НАДЁЖНОСТЬ УЗЛОВ:</span>
                  <span className={`text-lg font-bold ${totalReliability > 70 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {totalReliability}%
                  </span>
                  <div className="text-[8px] opacity-60">Гарантия: 2000 моточасов</div>
                </div>
              </div>
            </div>

            {/* Factory Cost */}
            <div className="border-t border-[#9ed3f2]/30 pt-3 mt-3 flex items-center justify-between text-xs">
              <span className="text-[10px] uppercase opacity-70">Затраты на 1 ед.:</span>
              <div className="flex gap-3 font-bold text-white">
                <span className="text-amber-200 flex items-center gap-1">
                  <Settings className="w-3.5 h-3.5 text-amber-300" />
                  <span>{totalCostSteel} т. стали</span>
                </span>
                <span className="text-stone-300 flex items-center gap-1">
                  <Pickaxe className="w-3.5 h-3.5 text-stone-400" />
                  <span>{totalCostCoal} т. угля</span>
                </span>
              </div>
            </div>
          </div>

          {/* Test Polygon Button */}
          <div className="flex flex-col gap-2">
            <button
              onClick={handleRunPolygonTest}
              disabled={isTesting}
              className="w-full py-3 bg-paper/20 text-ink border-2 border-ink font-mono text-xs uppercase font-bold hover:bg-paper/40 transition-all flex items-center justify-center gap-2 shadow-xs active:translate-y-0.5 disabled:opacity-50"
            >
              {isTesting ? (
                <>
                  <Crosshair className="w-4 h-4 animate-spin text-blood" />
                  <span>ИДУТ ПОЛИГОННЫЕ ИСПЫТАНИЯ ОГНЁМ И МАРШЕМ...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 text-blood fill-blood" />
                  <span>1. Провести полигонные стрельбы</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                const ok = gameStore.produceArsenalBlueprint(vehicleName, totalCostSteel, 100, 'ostenmark');
                if (ok) {
                  setTestResult(`[СЕРИЙНЫЙ ЗАКАЗ] Партия танков ${vehicleName} передана 1-й бронетанковой группе в Остенмарке! Списано ${totalCostSteel}т стали. Данные внесены в Хронику.`);
                } else {
                  setTestResult(`[ОШИБКА ЗАКАЗА] Недостаточно стали на складах (требуется ${totalCostSteel}т).`);
                }
              }}
              className="w-full py-3 bg-blood text-paper-light font-mono text-xs uppercase font-bold hover:bg-blood-hover transition-all flex items-center justify-center gap-2 border-2 border-amber-300 shadow-md active:translate-y-0.5"
            >
              <Factory className="w-4 h-4 text-amber-300" />
              <span>2. Передать в серийное производство на фронт ({totalCostSteel} т. стали)</span>
            </button>
          </div>

          {/* Test Feedback Banner */}
          {testResult && (
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 bg-ink text-paper-light font-mono text-xs border border-ink"
            >
              {testResult}
            </motion.div>
          )}

        </div>
      </div>

    </div>
  );
}
