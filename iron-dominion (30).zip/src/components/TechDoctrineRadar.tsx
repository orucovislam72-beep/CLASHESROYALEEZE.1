import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Zap, Shield, Crosshair, Award, Cpu, Flame, Target, ChevronRight, Clock, CheckCircle } from 'lucide-react';
import { gameStore } from '../utils/gameStore';
import { GameState } from '../utils/gameState';
import { audioEngine } from '../utils/audioEngine';

interface DoctrineSchool {
  id: string;
  name: string;
  subtitle: string;
  focus: string;
  mentality: string;
  investment: number; // 0 to 100
  color: string;
  unlockedPrototypes: string[];
  armyPerks: string[];
}

const initialSchools: DoctrineSchool[] = [
  {
    id: 'maneuver',
    name: 'Школа Глубокого Манёвра',
    subtitle: 'Моторизованный прорыв и радиосвязь',
    focus: 'Концентрация танковых клиньев и десантных групп в узком коридоре',
    mentality: '«Дерзость и автономность командиров на местах»',
    investment: 65,
    color: 'emerald',
    unlockedPrototypes: ['Танк-крейсер «Титан-III»', 'Радиорота оперативного наведения', 'Штурмовой мотополк'],
    armyPerks: ['+40% Скорость прорыва', '-25% Потери при окружении врага', 'Высокая цена моторизации']
  },
  {
    id: 'attrition',
    name: 'Школа Индустриальной Осады',
    subtitle: 'Артиллерийский вал и бетонированные линии',
    focus: 'Подавление противника непрерывным огнём тяжелых гаубиц и укрепрайонами',
    mentality: '«Ни шагу назад. Математика расхода снарядов побеждает манёвр»',
    investment: 40,
    color: 'amber',
    unlockedPrototypes: ['Сверхтяжелая ж/д мортира «Голиаф»', 'Бункерная фортификация типа «Зигфрид»', 'Химический снаряд «Мгла»'],
    armyPerks: ['+60% Защита на линии фронта', '+35% Урон артиллерии', '-30% Мобильность пехоты']
  },
  {
    id: 'subversion',
    name: 'Школа Асимметричной Войны',
    subtitle: 'Партизанские рейды и саботаж тылов',
    focus: 'Уничтожение логистических узлов, минирование рельсов, ночные диверсии',
    mentality: '«Война ведётся там, где враг её не ждёт — в его собственных складах»',
    investment: 25,
    color: 'blood',
    unlockedPrototypes: ['Диверсионный отряд «Призрак»', 'Магнитные мины замедленного действия', 'Подпольная типография'],
    armyPerks: ['+80% Шанс перерезать ж/д ветку', '+50% Маскировка на чужой территории', 'Слабость в открытом танковом бою']
  }
];

export default function TechDoctrineRadar() {
  const [schools, setSchools] = useState<DoctrineSchool[]>(initialSchools);
  const [researchPoints, setResearchPoints] = useState<number>(120);
  const [selectedSchoolId, setSelectedSchoolId] = useState<string>('maneuver');
  const [gameState, setGameState] = useState<GameState>(gameStore.getState());

  useEffect(() => {
    return gameStore.subscribe(setGameState);
  }, []);

  const selectedSchool = schools.find(s => s.id === selectedSchoolId) || schools[0];

  const handleInvest = (schoolId: string, amount: number) => {
    if (researchPoints < amount) return;

    setSchools(prev => prev.map(s => {
      if (s.id === schoolId) {
        return {
          ...s,
          investment: Math.min(100, s.investment + amount)
        };
      }
      return s;
    }));
    setResearchPoints(prev => prev - amount);
    audioEngine.playMorseBeep(true);
  };

  return (
    <div className="w-full bg-paper/60 border border-ink/20 p-4 md:p-6 relative font-sans text-ink">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b-2 border-ink pb-3 mb-5 gap-2">
        <div className="flex items-center gap-2.5">
          <BookOpen className="w-5 h-5 text-blood" />
          <div>
            <h3 className="font-serif font-bold text-xl uppercase tracking-tight text-ink">
              Научно-Военные Доктрины // Нелинейная Эволюция
            </h3>
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Инвестируйте в концепции, меняющие доктрину и психологию штаба
            </span>
          </div>
        </div>
        <div className="font-mono text-xs bg-ink text-paper-light px-3 py-1.5 flex items-center gap-2">
          <Cpu className="w-3.5 h-3.5 text-amber-400" />
          <span>НАУЧНЫЙ РЕЗЕРВ: <strong className="text-amber-300">{researchPoints} RP</strong></span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: 3 Doctrine Schools */}
        <div className="lg:col-span-6 flex flex-col gap-3">
          <div className="font-mono text-[10px] uppercase text-ink/60 border-b border-ink/15 pb-1 flex justify-between">
            <span>Школы стратегической мысли</span>
            <span>Инвестиции концепта</span>
          </div>

          {schools.map(school => {
            const isSelected = school.id === selectedSchoolId;
            return (
              <div
                key={school.id}
                onClick={() => setSelectedSchoolId(school.id)}
                className={`p-3.5 border cursor-pointer transition-all relative flex flex-col gap-2 ${
                  isSelected
                    ? 'bg-ink text-paper-light border-ink shadow-md'
                    : 'bg-paper hover:bg-paper-dark/30 border-ink/20'
                }`}
              >
                {isSelected && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-blood" />
                )}

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-serif font-bold text-base">{school.name}</span>
                  </div>
                  <span className="font-mono text-xs font-bold text-amber-400">
                    {school.investment}%
                  </span>
                </div>

                <div className={`text-xs ${isSelected ? 'text-paper-light/80' : 'text-ink-light'}`}>
                  {school.subtitle}
                </div>

                {/* Progress bar */}
                <div className="w-full h-1.5 bg-ink/20 mt-1 relative overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      school.id === 'maneuver' ? 'bg-emerald-500' :
                      school.id === 'attrition' ? 'bg-amber-500' : 'bg-blood'
                    }`}
                    style={{ width: `${school.investment}%` }}
                  />
                </div>
              </div>
            );
          })}

          {/* Quick RP Gain Generator Button */}
          <div className="mt-2 flex items-center justify-between bg-ink/5 p-2.5 border border-ink/15 font-mono text-xs">
            <span className="text-[11px] text-ink/70">Мобилизация учёных институтов:</span>
            <button
              onClick={() => setResearchPoints(prev => prev + 30)}
              className="px-2 py-1 bg-paper border border-ink text-[10px] uppercase font-bold hover:bg-ink hover:text-paper-light transition-colors"
            >
              +30 RP (Субсидия)
            </button>
          </div>
        </div>

        {/* Right: Selected School Deep Inspection & Unlocked Tech */}
        <div className="lg:col-span-6 border border-ink/30 bg-paper-light p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-ink/15 pb-2 mb-3">
              <span className="font-mono text-[10px] text-stamp border border-stamp px-1.5 uppercase font-bold">
                DOCTRINE DOSSIER // {selectedSchool.id.toUpperCase()}
              </span>
              <span className="font-mono text-[10px] text-ink/50">LEVEL: {Math.floor(selectedSchool.investment / 20) + 1}</span>
            </div>

            <h4 className="font-serif font-bold text-xl uppercase mb-1 text-ink">
              {selectedSchool.name}
            </h4>
            <div className="font-sans text-xs italic text-blood mb-3">
              {selectedSchool.mentality}
            </div>

            {/* Army Perks */}
            <div className="mb-4">
              <span className="font-mono text-[10px] uppercase text-ink/50 block mb-1">
                Влияние на менталитет и тактику дивизий:
              </span>
              <div className="space-y-1 font-mono text-xs">
                {selectedSchool.armyPerks.map((perk, i) => (
                  <div key={i} className="flex items-center gap-1.5 text-ink">
                    <ChevronRight className="w-3 h-3 text-blood shrink-0" />
                    <span>{perk}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Unlocked Prototypes */}
            <div>
              <span className="font-mono text-[10px] uppercase text-ink/50 block mb-1">
                Органически открытые прототипы:
              </span>
              <div className="grid grid-cols-1 gap-1.5">
                {selectedSchool.unlockedPrototypes.map((proto, i) => (
                  <div key={i} className="bg-ink/5 border border-ink/15 px-2.5 py-1.5 font-mono text-xs flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Target className="w-3.5 h-3.5 text-blood" />
                      <span className="font-bold text-ink">{proto}</span>
                    </div>
                    <span className="text-[9px] uppercase text-emerald-700 font-bold bg-emerald-100/60 px-1 border border-emerald-300">
                      Готов к сборке
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Investment Action Buttons */}
          <div className="mt-5 pt-3 border-t border-ink/20 flex items-center justify-between gap-2">
            <span className="font-mono text-[10px] text-ink/60 uppercase">
              Инвестировать в доктрину:
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => handleInvest(selectedSchool.id, 20)}
                disabled={researchPoints < 20}
                className="px-3 py-1.5 bg-paper border border-ink font-mono text-xs uppercase font-bold hover:bg-ink hover:text-paper-light transition-all disabled:opacity-40"
              >
                +20 RP
              </button>
              <button
                onClick={() => handleInvest(selectedSchool.id, 50)}
                disabled={researchPoints < 50}
                className="px-3 py-1.5 bg-blood text-paper-light border border-blood font-mono text-xs uppercase font-bold hover:bg-ink hover:border-ink transition-all disabled:opacity-40"
              >
                +50 RP (Форсаж)
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* Live R&D Projects Queue from unified game state */}
      <div className="mt-6 border-t-2 border-ink pt-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-blood" />
            <span className="font-mono text-xs font-bold uppercase tracking-wider text-ink">
              ПОРТФЕЛЬ ПРОЕКТОВ КБ №7 (ВРЕМЯ & РЕСУРСЫ)
            </span>
          </div>
          <span className="font-mono text-[10px] text-ink/60">
            ПРОЕКТЫ РАЗВИВАЮТСЯ ПО ХОДУ ДНЕЙ
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {gameState.techTree.map(tech => (
            <div
              key={tech.id}
              className={`p-3 border font-mono text-xs flex flex-col justify-between ${
                tech.status === 'completed'
                  ? 'bg-emerald-950/10 border-emerald-700/40 text-emerald-900'
                  : tech.status === 'researching'
                  ? 'bg-amber-950/10 border-amber-500/60 text-ink shadow-xs'
                  : 'bg-paper-light border-ink/20 text-ink'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] text-ink/60 uppercase">{tech.branch.toUpperCase()}</span>
                  {tech.status === 'completed' ? (
                    <span className="px-1.5 py-0.2 bg-emerald-700 text-paper-light text-[9px] font-bold">ИЗУЧЕНО</span>
                  ) : tech.status === 'researching' ? (
                    <span className="px-1.5 py-0.2 bg-amber-600 text-paper-light text-[9px] font-bold animate-pulse">ИССЛЕДУЕТСЯ</span>
                  ) : (
                    <span className="px-1.5 py-0.2 bg-ink/10 text-ink text-[9px]">ДОСТУПНО</span>
                  )}
                </div>

                <div className="font-serif font-bold text-sm text-ink mb-1">
                  {tech.name}
                </div>

                <div className="text-[11px] text-ink/75 italic mb-2">
                  {tech.effectDesc}
                </div>
              </div>

              <div>
                {tech.status === 'researching' ? (
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] text-ink/70">
                      <span>Осталось дней:</span>
                      <strong className="text-blood">{tech.daysRemaining} дн.</strong>
                    </div>
                    <div className="w-full bg-ink/15 h-1.5 overflow-hidden">
                      <div 
                        className="bg-amber-500 h-full transition-all"
                        style={{ width: `${Math.round(((tech.costDays - tech.daysRemaining) / tech.costDays) * 100)}%` }}
                      />
                    </div>
                  </div>
                ) : tech.status === 'available' ? (
                  <button
                    onClick={() => gameStore.startResearch(tech.id)}
                    disabled={
                      gameState.resources.steel < tech.costSteel ||
                      gameState.resources.rareEarth < tech.costRareEarth ||
                      gameState.resources.treasury < tech.costTreasury
                    }
                    className="w-full py-1.5 bg-blood hover:bg-blood-hover disabled:opacity-40 text-paper-light text-[10px] uppercase font-bold transition-all flex items-center justify-center gap-1"
                  >
                    <span>Изучить ({tech.costDays} дн. / {tech.costSteel}т стали)</span>
                  </button>
                ) : (
                  <div className="text-[10px] text-emerald-800 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Технология внедрена в войска
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
