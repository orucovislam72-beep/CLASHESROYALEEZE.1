import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, Play, Pause, Radio, Flame, Music, Disc, Sparkles, ChevronRight, ChevronLeft, Mic, MicOff, Key, Binary, Volume1, AlertCircle, FileText, X } from 'lucide-react';
import { audioEngine, AudioTheme, RADIO_STATIONS, RadioStation, EASTER_EGG_STORY, EasterEggChapter } from '../utils/audioEngine';
import { radioLogsStore, RadioLogEntry } from '../utils/radioLogsStore';
import RadioLogsPanel from './RadioLogsPanel';

interface AudioControllerProps {
  activeAlertTheme?: AudioTheme;
  compact?: boolean;
  onUnlockSecretTab?: () => void;
  latestEvent?: {
    id?: number | string;
    title: string;
    desc: string;
    type: string;
    region: string;
  } | null;
}

export default function AudioController({ activeAlertTheme, compact = false, onUnlockSecretTab, latestEvent }: AudioControllerProps) {
  const [state, setState] = useState(audioEngine.getState());
  const [logs, setLogs] = useState<RadioLogEntry[]>(radioLogsStore.getLogs());
  const [selectedChapterIndex, setSelectedChapterIndex] = useState<number>(0);
  const [showStoryDetails, setShowStoryDetails] = useState<boolean>(true);
  const [showCompactLogsPopover, setShowCompactLogsPopover] = useState<boolean>(false);
  const lastProcessedEventId = useRef<string | number | null>(null);

  useEffect(() => {
    const unsubscribeAudio = audioEngine.subscribe((newState) => {
      setState(newState);
    });
    const unsubscribeLogs = radioLogsStore.subscribe((newLogs) => {
      setLogs(newLogs);
    });
    return () => {
      unsubscribeAudio();
      unsubscribeLogs();
    };
  }, []);

  // Sync external incoming events with Radio Logs Store
  useEffect(() => {
    if (latestEvent && latestEvent.id !== lastProcessedEventId.current) {
      lastProcessedEventId.current = latestEvent.id || Date.now();
      const freqMap: Record<string, number> = {
        'Остенмарк': 1140,
        'Корсак': 1420,
        'Ворн': 780,
        'Этельгард': 890
      };
      const freq = freqMap[latestEvent.region] || 1140;
      radioLogsStore.addLog({
        frequency: freq,
        title: latestEvent.title,
        desc: latestEvent.desc,
        source: latestEvent.region,
        type: (latestEvent.type as any) || 'alert',
        classification: 'ОПЕРАТИВНЫЙ ПЕРЕХВАТ ТВД',
        impact: `Регион: ${latestEvent.region}`
      });
    }
  }, [latestEvent]);

  // Synchronization of theme is now handled centrally in App.tsx

  const handleTogglePlay = () => {
    audioEngine.playClick('switch');
    audioEngine.togglePlay();
  };

  const handleToggleMute = () => {
    audioEngine.playClick('toggle');
    audioEngine.toggleMute();
  };

  const handleSelectStation = (station: RadioStation) => {
    audioEngine.playClick('switch');
    audioEngine.setFrequency(station.frequency);
    if (!state.isPlaying) {
      audioEngine.start();
    }
    if (station.isSecret && onUnlockSecretTab) {
      onUnlockSecretTab();
    }
  };

  const handleFrequencySlider = (e: React.ChangeEvent<HTMLInputElement>) => {
    const freq = parseInt(e.target.value, 10);
    audioEngine.playClick('ratchet');
    audioEngine.setFrequency(freq);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    audioEngine.setVolume(val);
  };

  const currentChapter: EasterEggChapter = EASTER_EGG_STORY[selectedChapterIndex];

  const handlePlayVoiceNarration = () => {
    audioEngine.playClick('light');
    if (state.isSpeaking) {
      audioEngine.stopSpeech();
    } else {
      audioEngine.speakChapter(currentChapter.transcript);
    }
  };

  const handlePlayMorseCode = () => {
    audioEngine.playClick('metal');
    // Play Morse pattern
    const pattern = currentChapter.morse;
    let delay = 0;
    for (const char of pattern) {
      if (char === '.') {
        setTimeout(() => audioEngine.playMorseBeep(false), delay);
        delay += 100;
      } else if (char === '-') {
        setTimeout(() => audioEngine.playMorseBeep(true), delay);
        delay += 240;
      } else {
        delay += 160;
      }
    }
  };

  const activeCount = logs.filter(l => l.status === 'active').length;

  // Compact Header Bar View
  if (compact) {
    const activeStation = RADIO_STATIONS.find(s => s.id === state.theme) || RADIO_STATIONS[0];
    return (
      <div className="relative flex items-center gap-2 bg-ink text-paper-light px-3 py-1.5 border border-ink/40 font-mono text-xs shadow-md">
        <button
          onClick={handleTogglePlay}
          className="flex items-center gap-1.5 text-paper-light hover:text-amber-300 transition-colors"
          title={state.isPlaying ? "Остановить радио" : "Включить радио"}
        >
          {state.isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 text-blood fill-blood" />}
          <span className="uppercase text-[10px] font-bold">
            {state.isPlaying ? `${activeStation.frequency} kHz` : 'РАДИО ВЫКЛ'}
          </span>
        </button>

        <div className="w-[1px] h-3 bg-paper/30" />

        {/* Quick Station Switcher */}
        <div className="flex items-center gap-1">
          {RADIO_STATIONS.map(st => (
            <button
              key={st.id}
              onClick={() => handleSelectStation(st)}
              className={`px-1.5 py-0.5 text-[9px] uppercase transition-all ${
                state.theme === st.id
                  ? st.isSecret
                    ? 'bg-blood text-amber-200 border border-amber-400 font-bold'
                    : 'bg-amber-500/30 text-amber-200 border border-amber-500/50 font-bold'
                  : 'opacity-50 hover:opacity-100 text-paper-light'
              }`}
              title={`${st.name} (${st.frequency} kHz)`}
            >
              {st.isSecret ? '1939 kHz' : `${st.frequency}`}
            </button>
          ))}
        </div>

        <div className="w-[1px] h-3 bg-paper/30" />

        {/* Quick Radio Logs Popover Trigger */}
        <button
          onClick={() => {
            audioEngine.playClick('switch');
            setShowCompactLogsPopover(prev => !prev);
          }}
          className={`flex items-center gap-1 px-1.5 py-0.5 text-[9px] uppercase font-bold border transition-all ${
            showCompactLogsPopover
              ? 'bg-amber-400 text-ink border-amber-300 shadow-xs'
              : activeCount > 0
                ? 'bg-blood/80 hover:bg-blood text-paper-light border-blood animate-pulse'
                : 'bg-paper/20 hover:bg-paper/30 text-paper-light border-paper/30'
          }`}
          title="Открыть журнал последних радиоперехватов"
        >
          <FileText className="w-2.5 h-2.5" />
          <span>Депеши ({logs.length})</span>
          {activeCount > 0 && <span className="w-1.5 h-1.5 rounded-full bg-amber-300" />}
        </button>

        <div className="w-[1px] h-3 bg-paper/30" />

        <button
          onClick={handleToggleMute}
          className="opacity-70 hover:opacity-100 text-paper-light"
          title={state.isMuted ? "Включить звук" : "Заглушить"}
        >
          {state.isMuted ? <VolumeX className="w-3.5 h-3.5 text-blood" /> : <Volume2 className="w-3.5 h-3.5" />}
        </button>

        {/* Floating Compact Logs Popover */}
        <AnimatePresence>
          {showCompactLogsPopover && (
            <motion.div 
              initial={{ opacity: 0, y: -6, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.96 }}
              transition={{ duration: 0.2 }}
              className="absolute top-full right-0 mt-2 z-50"
            >
              <RadioLogsPanel 
                logs={logs} 
                compact={true} 
                onSelectFrequency={(freq) => {
                  audioEngine.setFrequency(freq);
                  setShowCompactLogsPopover(false);
                }} 
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  const activeStation = RADIO_STATIONS.find(s => s.id === state.theme) || RADIO_STATIONS[0];
  const isSecretActive = state.theme === 'secret_broadcast';

  return (
    <div className={`w-full border-2 p-4 relative font-mono text-ink transition-all duration-300 shadow-[4px_4px_0_var(--color-ink)] ${
      isSecretActive ? 'bg-amber-50/90 border-blood' : 'bg-paper border-ink'
    }`}>
      {/* Decorative radio chassis screws */}
      <div className="absolute top-1.5 left-1.5 w-2 h-2 rounded-full border border-ink/40 flex items-center justify-center text-[8px] text-ink/40">+</div>
      <div className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full border border-ink/40 flex items-center justify-center text-[8px] text-ink/40">+</div>
      <div className="absolute bottom-1.5 left-1.5 w-2 h-2 rounded-full border border-ink/40 flex items-center justify-center text-[8px] text-ink/40">+</div>
      <div className="absolute bottom-1.5 right-1.5 w-2 h-2 rounded-full border border-ink/40 flex items-center justify-center text-[8px] text-ink/40">+</div>

      {/* Radio Header */}
      <div className="flex items-center justify-between border-b border-ink/20 pb-2 mb-3">
        <div className="flex items-center gap-2">
          <Radio className={`w-4 h-4 animate-pulse ${isSecretActive ? 'text-blood' : 'text-amber-600'}`} />
          <span className="text-xs uppercase font-bold tracking-widest">
            {isSecretActive ? 'ПЕРЕХВАТ // ШИФРОВАЛЬНЫЙ БУНКЕР №4' : 'ШТАБНОЙ РАДИОПРИЁМНИК // T-1934'}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className={`w-2 h-2 rounded-full ${state.isPlaying ? (isSecretActive ? 'bg-blood animate-ping' : 'bg-amber-600 animate-pulse') : 'bg-ink/30'}`} />
          <span className="text-[10px] uppercase font-bold text-ink/80">
            {state.isPlaying ? `${state.frequency} kHz // СИГНАЛ 100%` : 'ВЫКЛЮЧЕНО'}
          </span>
        </div>
      </div>

      {/* Analog Frequency Tuning Scale */}
      <div className="bg-ink text-paper-light p-2.5 mb-3 border border-ink flex flex-col gap-1.5">
        <div className="flex justify-between text-[9px] text-amber-300/80 uppercase font-mono tracking-widest border-b border-paper/10 pb-1">
          <span>ШКАЛА НАСТРОЙКИ (КГц)</span>
          <span className="text-amber-400 font-bold">ТЕКУЩАЯ: {state.frequency} kHz</span>
        </div>

        {/* Frequency Dial Slider */}
        <div className="relative pt-1">
          <input
            type="range"
            min="600"
            max="2000"
            step="10"
            value={state.frequency}
            onChange={handleFrequencySlider}
            className="w-full h-2 bg-paper/20 rounded appearance-none cursor-pointer accent-blood"
          />

          {/* Station Markers on Frequency scale */}
          <div className="flex justify-between text-[8px] font-mono text-paper/60 mt-1 px-1">
            <span>600</span>
            <span className={Math.abs(state.frequency - 780) < 50 ? 'text-amber-300 font-bold' : ''}>780 [Джаз]</span>
            <span className={Math.abs(state.frequency - 1140) < 50 ? 'text-amber-300 font-bold' : ''}>1140 [Марш]</span>
            <span className={Math.abs(state.frequency - 1420) < 50 ? 'text-amber-300 font-bold' : ''}>1420 [УВБ-34]</span>
            <span className={Math.abs(state.frequency - 1939) < 50 ? 'text-blood font-bold underline' : 'text-amber-400'}>1939 [Аврора]</span>
            <span>2000</span>
          </div>
        </div>
      </div>

      {/* Preset Radio Stations Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 mb-3">
        {RADIO_STATIONS.map(station => {
          const isCurrent = state.theme === station.id;
          return (
            <button
              key={station.id}
              onClick={() => handleSelectStation(station)}
              className={`p-2 text-left border transition-all flex flex-col justify-between ${
                isCurrent
                  ? station.isSecret
                    ? 'bg-blood text-paper-light border-blood shadow-sm'
                    : 'bg-ink text-paper-light border-ink shadow-sm'
                  : 'bg-paper-light hover:bg-ink/10 border-ink/20'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-1">
                <span className={`text-[10px] font-bold ${isCurrent ? 'text-amber-300' : 'text-ink'}`}>
                  {station.frequency} kHz
                </span>
                {station.isSecret && (
                  <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
                )}
              </div>
              <div className="text-[10px] font-serif font-bold leading-tight truncate">
                {station.name}
              </div>
              <div className={`text-[8px] truncate mt-0.5 ${isCurrent ? 'text-paper-light/70' : 'text-ink/50'}`}>
                {station.genre}
              </div>
            </button>
          );
        })}
      </div>

      {/* Controls & Equalizer Row */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center border-t border-ink/15 pt-3">
        {/* Play/Stop & Equalizer */}
        <div className="md:col-span-6 flex items-center gap-3">
          <button
            onClick={handleTogglePlay}
            className={`flex items-center justify-center gap-2 px-3.5 py-1.5 border-2 border-ink uppercase text-xs font-bold transition-all shadow-[2px_2px_0_var(--color-ink)] active:translate-x-0.5 active:translate-y-0.5 ${
              state.isPlaying
                ? 'bg-ink text-paper-light hover:bg-blood hover:border-blood'
                : 'bg-paper-light hover:bg-ink hover:text-paper-light'
            }`}
          >
            {state.isPlaying ? (
              <>
                <Pause className="w-3.5 h-3.5 text-blood" />
                <span>Стоп</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 text-blood fill-blood" />
                <span>Включить эфир</span>
              </>
            )}
          </button>

          {/* Equalizer Audio simulation */}
          <div className="flex items-end gap-1 h-6 px-2 py-1 bg-ink/10 border border-ink/20">
            {[4, 12, 18, 22, 14, 8, 20, 16, 10, 6].map((h, i) => (
              <div
                key={i}
                className={`w-1 transition-all duration-150 ${
                  state.isPlaying
                    ? isSecretActive ? 'bg-blood' : state.theme === 'orchestral' ? 'bg-blood' : 'bg-ink'
                    : 'bg-ink/20'
                }`}
                style={{
                  height: state.isPlaying ? `${Math.max(3, (h * (0.4 + (i % 3) * 0.3)) % 22)}px` : '3px'
                }}
              />
            ))}
          </div>
        </div>

        {/* Volume & Mute */}
        <div className="md:col-span-6 flex items-center justify-end gap-2">
          <button
            onClick={handleToggleMute}
            className="p-1 border border-ink/30 hover:bg-ink hover:text-paper-light transition-colors text-ink"
            title={state.isMuted ? "Включить звук" : "Заглушить"}
          >
            {state.isMuted ? <VolumeX className="w-3.5 h-3.5 text-blood" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
          <div className="flex flex-col gap-0.5 w-24">
            <div className="flex justify-between text-[8px] text-ink/60 uppercase">
              <span>Громк.</span>
              <span>{state.isMuted ? '0%' : `${Math.round(state.volume * 100)}%`}</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={state.isMuted ? 0 : state.volume}
              onChange={handleVolumeChange}
              className="w-full h-1 bg-ink/20 accent-blood cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* RADIO LOGS HISTORY PANEL (LAST 5 INTERCEPTED EVENTS) */}
      <RadioLogsPanel 
        logs={logs} 
        onSelectFrequency={(freq) => audioEngine.setFrequency(freq)} 
      />

      {/* EASTER EGG STORY SECTION (ACTIVE ON 1939 kHz) */}
      <AnimatePresence>
        {isSecretActive && (
          <motion.div 
            initial={{ opacity: 0, y: 16, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.98 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="mt-4 p-3.5 bg-ink text-paper-light border-2 border-blood shadow-lg flex flex-col gap-2.5"
          >
            <div className="flex items-center justify-between border-b border-paper/20 pb-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-300 animate-spin-slow" />
                <span className="text-xs uppercase font-bold text-amber-300">
                  РАДИОХРОНИКА «ПРОЕКТ АВРОРА»
                </span>
              </div>
              <span className="text-[10px] text-paper/60 font-mono">
                ГЛАВА {selectedChapterIndex + 1} / {EASTER_EGG_STORY.length}
              </span>
            </div>

            <div>
              <div className="flex items-center justify-between text-[11px] font-bold text-amber-200 mb-1">
                <span>{currentChapter.title}</span>
                <span className="font-mono text-[9px] text-paper/50">{currentChapter.timeCode}</span>
              </div>
              <div className="text-[10px] text-paper/70 font-mono italic mb-2">
                {currentChapter.speaker}
              </div>

              {/* Transcript Quote */}
              <div className="p-2.5 bg-paper/10 border-l-2 border-blood font-serif text-xs md:text-sm text-paper-light/95 leading-relaxed italic">
                «{currentChapter.transcript}»
              </div>

              {/* Clue and Morse Bar */}
              <div className="mt-2 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 font-mono text-[10px] bg-paper/5 p-2 border border-paper/10">
                <span className="text-amber-300 font-bold">{currentChapter.secretClue}</span>
                <span className="text-paper/60 font-mono tracking-widest">{currentChapter.morse}</span>
              </div>
            </div>

            {/* Interactive Voice, Morse & Navigation Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-paper/15">
              <div className="flex gap-1.5">
                <button
                  onClick={handlePlayVoiceNarration}
                  className={`px-2.5 py-1 text-[10px] uppercase font-bold flex items-center gap-1.5 border transition-all ${
                    state.isSpeaking
                      ? 'bg-blood text-paper-light border-blood animate-pulse'
                      : 'bg-paper/20 hover:bg-paper/30 text-paper-light border-paper/30'
                  }`}
                  title="Синтезировать голос штабного радиста"
                >
                  {state.isSpeaking ? <MicOff className="w-3 h-3 text-amber-300" /> : <Mic className="w-3 h-3 text-amber-300" />}
                  <span>{state.isSpeaking ? 'Остановить голос' : 'Озвучить радио'}</span>
                </button>

                <button
                  onClick={handlePlayMorseCode}
                  className="px-2.5 py-1 text-[10px] uppercase font-bold flex items-center gap-1.5 bg-paper/20 hover:bg-paper/30 text-paper-light border border-paper/30 transition-all"
                  title="Воспроизвести сигнал морзе через динамик"
                >
                  <Binary className="w-3 h-3 text-amber-300" />
                  <span>Морзянка</span>
                </button>
              </div>

              {/* Chapter Stepper */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    audioEngine.playClick('ratchet');
                    setSelectedChapterIndex(prev => Math.max(0, prev - 1));
                  }}
                  disabled={selectedChapterIndex === 0}
                  className="p-1 bg-paper/10 hover:bg-paper/20 text-paper-light disabled:opacity-30"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-[10px] font-mono font-bold text-amber-300 px-1">
                  {selectedChapterIndex + 1}/{EASTER_EGG_STORY.length}
                </span>
                <button
                  onClick={() => {
                    audioEngine.playClick('ratchet');
                    setSelectedChapterIndex(prev => Math.min(EASTER_EGG_STORY.length - 1, prev + 1));
                  }}
                  disabled={selectedChapterIndex === EASTER_EGG_STORY.length - 1}
                  className="p-1 bg-paper/10 hover:bg-paper/20 text-paper-light disabled:opacity-30"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                {onUnlockSecretTab && (
                  <button
                    onClick={() => {
                      audioEngine.playClick('heavy');
                      onUnlockSecretTab();
                    }}
                    className="ml-2 px-2.5 py-1 bg-blood text-paper-light font-mono text-[10px] uppercase font-bold border border-amber-300 hover:bg-amber-400 hover:text-ink transition-all"
                  >
                    Открыть «Колосс»
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

