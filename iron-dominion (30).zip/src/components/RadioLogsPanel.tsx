import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Radio, 
  AlertTriangle, 
  CheckCircle, 
  Sparkles, 
  Volume2, 
  Binary, 
  ChevronDown, 
  ChevronUp, 
  RefreshCw, 
  RotateCcw, 
  Check, 
  ShieldAlert, 
  Archive, 
  RadioTower, 
  Zap, 
  Filter, 
  FileText, 
  Clock,
  Eye,
  Sliders,
  Send
} from 'lucide-react';
import { radioLogsStore, RadioLogEntry, RadioLogStatus } from '../utils/radioLogsStore';
import { audioEngine } from '../utils/audioEngine';

interface RadioLogsPanelProps {
  logs: RadioLogEntry[];
  onSelectFrequency?: (freq: number) => void;
  compact?: boolean;
}

export default function RadioLogsPanel({ logs, onSelectFrequency, compact = false }: RadioLogsPanelProps) {
  const [selectedLogId, setSelectedLogId] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [isPanelExpanded, setIsPanelExpanded] = useState<boolean>(true);

  const filteredLogs = logs.filter(log => {
    if (filterStatus === 'all') return true;
    return log.status === filterStatus;
  });

  const activeCount = logs.filter(l => l.status === 'active').length;
  const investigatingCount = logs.filter(l => l.status === 'investigating').length;

  const handleTuneFrequency = (freq: number, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    audioEngine.setFrequency(freq);
    audioEngine.playClick('switch');
    if (onSelectFrequency) {
      onSelectFrequency(freq);
    }
  };

  const handleCycleStatus = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    radioLogsStore.cycleLogStatus(id);
    audioEngine.playClick('toggle');
  };

  const handleScanAirwaves = () => {
    setIsScanning(true);
    audioEngine.playTuningSweep();
    audioEngine.playTelemetryBeep();
    setTimeout(() => {
      audioEngine.playClick('ratchet');
    }, 180);
    setTimeout(() => {
      audioEngine.playClick('heavy');
      const newLog = radioLogsStore.scanRandomIntercept();
      setSelectedLogId(newLog.id);
      setIsScanning(false);
    }, 450);
  };

  const handleResetLogs = (e: React.MouseEvent) => {
    e.stopPropagation();
    radioLogsStore.resetToDefault();
    audioEngine.playStampThud();
  };

  const handleSpeakLog = (text: string, e: React.MouseEvent) => {
    e.stopPropagation();
    audioEngine.playClick('light');
    audioEngine.speakChapter(text);
  };

  const handlePlayMorse = (morsePattern: string, e: React.MouseEvent) => {
    e.stopPropagation();
    audioEngine.playClick('metal');
    let delay = 0;
    for (const char of morsePattern) {
      if (char === '.') {
        setTimeout(() => audioEngine.playMorseBeep(false), delay);
        delay += 90;
      } else if (char === '-') {
        setTimeout(() => audioEngine.playMorseBeep(true), delay);
        delay += 230;
      } else {
        delay += 140;
      }
    }
  };

  const getStatusBadge = (status: RadioLogStatus) => {
    switch (status) {
      case 'active':
        return {
          label: 'ТРЕВОГА',
          bg: 'bg-blood text-paper-light border-blood',
          indicator: 'bg-blood animate-ping',
          dot: 'bg-blood'
        };
      case 'investigating':
        return {
          label: 'В ОБРАБОТКЕ',
          bg: 'bg-amber-600 text-paper-light border-amber-600',
          indicator: 'bg-amber-500 animate-pulse',
          dot: 'bg-amber-500'
        };
      case 'resolved':
        return {
          label: 'ПОДТВЕРЖДЕНО',
          bg: 'bg-emerald-700 text-paper-light border-emerald-700',
          indicator: 'bg-emerald-500',
          dot: 'bg-emerald-500'
        };
      case 'decrypted':
        return {
          label: 'ШИФР-1939',
          bg: 'bg-purple-800 text-amber-200 border-purple-800',
          indicator: 'bg-purple-400 animate-pulse',
          dot: 'bg-purple-400'
        };
      case 'archived':
        return {
          label: 'В АРХИВЕ',
          bg: 'bg-ink/60 text-paper-light border-ink/40',
          indicator: 'bg-ink/40',
          dot: 'bg-ink/40'
        };
    }
  };

  // Compact Header Popover View with slide-in animation
  if (compact) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: -12, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -8, scale: 0.95 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="w-80 max-h-96 overflow-y-auto bg-ink text-paper-light border-2 border-amber-500/80 shadow-2xl p-3 font-mono text-xs z-50"
      >
        <div className="flex items-center justify-between border-b border-paper/20 pb-2 mb-2">
          <div className="flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-blood animate-pulse" />
            <span className="font-bold text-[11px] uppercase tracking-wider text-amber-300">
              ЖУРНАЛ РАДИОПЕРЕХВАТОВ ({logs.length})
            </span>
          </div>
          <button
            onClick={handleScanAirwaves}
            disabled={isScanning}
            className="flex items-center gap-1 px-1.5 py-0.5 bg-paper/20 hover:bg-paper/30 text-[9px] uppercase font-bold text-amber-200 transition-colors"
          >
            <RefreshCw className={`w-2.5 h-2.5 ${isScanning ? 'animate-spin' : ''}`} />
            <span>+ Скан</span>
          </button>
        </div>

        <div className="flex flex-col gap-1.5">
          <AnimatePresence mode="popLayout">
            {logs.map((log) => {
              const badge = getStatusBadge(log.status);
              return (
                <motion.div 
                  key={log.id}
                  layout
                  initial={{ opacity: 0, x: -20, scale: 0.96 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: 20, scale: 0.95 }}
                  transition={{ duration: 0.28, ease: 'easeOut' }}
                  onClick={() => handleTuneFrequency(log.frequency)}
                  className="p-2 bg-paper/10 hover:bg-paper/20 border border-paper/15 cursor-pointer transition-all flex flex-col gap-1 text-[10px]"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-amber-300 font-bold">{log.frequency} kHz</span>
                    <span className={`px-1 py-0.2 text-[8px] font-bold uppercase ${badge.bg}`}>
                      {badge.label}
                    </span>
                  </div>
                  <div className="font-serif font-bold text-paper-light leading-tight">
                    {log.title}
                  </div>
                  <div className="text-[9px] text-paper/60 line-clamp-1 italic font-sans">
                    {log.desc}
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </motion.div>
    );
  }

  // Full Standard Panel View inside Radio Chassis
  return (
    <div className="mt-3 bg-paper-light border-2 border-ink/80 shadow-sm relative overflow-hidden font-mono">
      {/* Telegraph Header Bar */}
      <div className="bg-ink text-paper-light px-3 py-2 border-b border-ink flex items-center justify-between">
        <div className="flex items-center gap-2">
          <RadioTower className="w-4 h-4 text-amber-400 animate-pulse" />
          <div className="flex flex-col">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
              ЖУРНАЛ РАДИОПЕРЕХВАТОВ
              {activeCount > 0 && (
                <span className="inline-block w-2 h-2 rounded-full bg-blood animate-ping" />
              )}
            </span>
            <span className="text-[9px] text-paper/60 font-mono">
              ПОСЛЕДНИЕ {logs.length} ДЕПЕШ // ЭФИР ГЕНШТАБА
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Quick Scan Airwaves button */}
          <button
            onClick={handleScanAirwaves}
            disabled={isScanning}
            className="flex items-center gap-1 px-2 py-1 bg-amber-500/20 hover:bg-amber-500/40 text-amber-300 border border-amber-400/50 text-[9px] uppercase font-bold transition-all"
            title="Сканировать коротковолновый эфир и перехватить депешу"
          >
            <Zap className={`w-3 h-3 text-amber-300 ${isScanning ? 'animate-bounce' : ''}`} />
            <span className="hidden sm:inline">{isScanning ? 'СКАНИРОВАНИЕ...' : '+ ПЕРЕХВАТ'}</span>
          </button>

          {/* Reset to defaults button */}
          <button
            onClick={handleResetLogs}
            className="p-1 hover:bg-paper/20 text-paper-light/70 hover:text-paper-light transition-colors"
            title="Сбросить журнал к исходным депешам"
          >
            <RotateCcw className="w-3 h-3" />
          </button>

          {/* Collapse/Expand Toggle */}
          <button
            onClick={() => {
              setIsPanelExpanded(prev => !prev);
              audioEngine.playClick('switch');
            }}
            className="p-1 hover:bg-paper/20 text-paper-light/70 hover:text-paper-light transition-colors"
          >
            {isPanelExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      <AnimatePresence initial={false}>
        {isPanelExpanded && (
          <motion.div
            initial={{ opacity: 0, height: 0, y: -8 }}
            animate={{ opacity: 1, height: 'auto', y: 0 }}
            exit={{ opacity: 0, height: 0, y: -8 }}
            transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
            className="overflow-hidden"
          >
            <div className="p-2.5 flex flex-col gap-2 bg-paper/60">
              {/* Filter & Status Counters Bar */}
              <div className="flex flex-wrap items-center justify-between gap-1 pb-1.5 border-b border-ink/15 text-[9px]">
                <div className="flex items-center gap-1 overflow-x-auto">
                  {[
                    { id: 'all', label: `ВСЕ (${logs.length})` },
                    { id: 'active', label: `ТРЕВОГА (${activeCount})`, color: 'text-blood' },
                    { id: 'investigating', label: `ОБРАБОТКА (${investigatingCount})`, color: 'text-amber-600' },
                    { id: 'resolved', label: `ПОДТВЕРЖДЕНО`, color: 'text-emerald-700' },
                    { id: 'archived', label: `АРХИВ`, color: 'text-ink/60' }
                  ].map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setFilterStatus(cat.id);
                        audioEngine.playClick('light');
                      }}
                      className={`px-1.5 py-0.5 border font-bold uppercase transition-all whitespace-nowrap ${
                        filterStatus === cat.id
                          ? 'bg-ink text-paper-light border-ink shadow-xs'
                          : 'bg-paper-light hover:bg-ink/10 border-ink/20 text-ink/70'
                      }`}
                    >
                      <span className={filterStatus === cat.id ? 'text-amber-300' : cat.color || ''}>
                        {cat.label}
                      </span>
                    </button>
                  ))}
                </div>

                <div className="text-[8px] text-ink/50 italic hidden sm:block">
                  Кликните статус для смены
                </div>
              </div>

              {/* List of Intercepted Logs with Smooth Slide-in Motion */}
              <div className="flex flex-col gap-1.5 max-h-[360px] overflow-y-auto pr-0.5">
                {filteredLogs.length === 0 ? (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="p-4 text-center text-ink/50 text-xs italic font-serif"
                  >
                    Нет депеш с выбранным статусом в журнале
                  </motion.div>
                ) : (
                  <AnimatePresence mode="popLayout">
                    {filteredLogs.map((log) => {
                      const isSelected = selectedLogId === log.id;
                      const badge = getStatusBadge(log.status);

                      return (
                        <motion.div
                          key={log.id}
                          layout
                          initial={{ opacity: 0, x: -32, scale: 0.97 }}
                          animate={{ opacity: 1, x: 0, scale: 1 }}
                          exit={{ opacity: 0, x: 32, scale: 0.95 }}
                          transition={{ 
                            type: 'spring',
                            stiffness: 450,
                            damping: 35
                          }}
                          className={`border transition-all duration-200 ${
                            isSelected
                              ? 'bg-amber-50/90 border-blood shadow-sm ring-1 ring-blood/20'
                              : 'bg-paper-light hover:bg-paper border-ink/20 hover:border-ink/40'
                          }`}
                        >
                          {/* Log Row Header */}
                          <div 
                            onClick={() => {
                              setSelectedLogId(isSelected ? null : log.id);
                              audioEngine.playClick('ratchet');
                            }}
                            className="p-2 flex flex-col gap-1 cursor-pointer select-none"
                          >
                            <div className="flex items-center justify-between gap-1.5">
                              <div className="flex items-center gap-1.5 min-w-0">
                                {/* Frequency Tag Pill */}
                                <button
                                  onClick={(e) => handleTuneFrequency(log.frequency, e)}
                                  className="px-1.5 py-0.5 bg-ink text-amber-300 font-bold text-[9px] hover:bg-blood hover:text-paper-light transition-colors shrink-0 flex items-center gap-1"
                                  title={`Настроить шкалу радио на ${log.frequency} кГц`}
                                >
                                  <Radio className="w-2.5 h-2.5" />
                                  <span>{log.frequency} kHz</span>
                                </button>

                                <span className="text-[9px] text-ink/50 font-mono shrink-0">
                                  {log.time}
                                </span>

                                <span className="text-[9px] text-ink/70 uppercase truncate font-serif font-bold">
                                  [{log.source}]
                                </span>
                              </div>

                              {/* Interactive Status Badge Button */}
                              <button
                                onClick={(e) => handleCycleStatus(log.id, e)}
                                className={`px-1.5 py-0.5 text-[8px] font-bold uppercase border shadow-xs transition-all flex items-center gap-1 shrink-0 ${badge.bg}`}
                                title="Кликните чтобы изменить статус (Тревога -> В обработке -> Подтверждено -> В архиве)"
                              >
                                <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                                <span>{badge.label}</span>
                              </button>
                            </div>

                            {/* Log Title */}
                            <div className="flex items-center justify-between">
                              <h4 className="font-serif font-bold text-xs text-ink leading-snug truncate">
                                {log.title}
                              </h4>
                              <div className="text-ink/40 shrink-0 ml-1">
                                {isSelected ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                              </div>
                            </div>

                            {/* Decrypted Telegraph Snip */}
                            <p className="font-sans text-[11px] text-ink-light leading-tight line-clamp-1 italic">
                              {log.desc}
                            </p>
                          </div>

                          {/* Expanded Inspection & Telegraph Report Drawer */}
                          <AnimatePresence>
                            {isSelected && (
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: 'auto' }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
                                className="overflow-hidden bg-ink text-paper-light border-t border-ink/40"
                              >
                                <div className="p-2.5 flex flex-col gap-2">
                                  {/* Wire Classification Banner */}
                                  <div className="flex items-center justify-between text-[9px] border-b border-paper/15 pb-1">
                                    <span className="text-amber-300 font-bold uppercase tracking-wider flex items-center gap-1">
                                      <Send className="w-2.5 h-2.5 text-amber-400" />
                                      <span>{log.classification || 'ШТАБНОЙ ПЕРЕХВАТ // СВОДКА'}</span>
                                    </span>
                                    <span className="text-paper/50 font-mono">
                                      ИСТОЧНИК: {log.source}
                                    </span>
                                  </div>

                                  {/* Full Wire Transcript in Typewriter Block */}
                                  <div className="p-2 bg-paper/10 border-l-2 border-blood font-serif text-xs leading-relaxed text-paper-light/95 italic">
                                    «{log.desc}»
                                  </div>

                                  {/* Impact Tag */}
                                  {log.impact && (
                                    <div className="text-[10px] bg-paper/5 p-1.5 border border-paper/10 flex items-center justify-between">
                                      <span className="text-paper/60 uppercase">Оперативное влияние:</span>
                                      <span className="text-amber-200 font-bold">{log.impact}</span>
                                    </div>
                                  )}

                                  {/* Status Manager & Action Buttons */}
                                  <div className="flex flex-wrap items-center justify-between gap-1.5 pt-1 border-t border-paper/15">
                                    {/* Tune Radio to Station */}
                                    <button
                                      onClick={() => handleTuneFrequency(log.frequency)}
                                      className="px-2 py-1 bg-amber-500 text-ink font-bold text-[9px] uppercase hover:bg-amber-400 transition-colors flex items-center gap-1"
                                    >
                                      <Radio className="w-3 h-3" />
                                      <span>Настроить шкалу ({log.frequency} kHz)</span>
                                    </button>

                                    <div className="flex items-center gap-1">
                                      {/* Voice Reader */}
                                      <button
                                        onClick={(e) => handleSpeakLog(log.desc, e)}
                                        className="p-1 bg-paper/20 hover:bg-paper/30 text-paper-light border border-paper/20 transition-colors"
                                        title="Озвучить депешу радистом"
                                      >
                                        <Volume2 className="w-3 h-3 text-amber-300" />
                                      </button>

                                      {/* Morse Beep */}
                                      {log.morse && (
                                        <button
                                          onClick={(e) => handlePlayMorse(log.morse!, e)}
                                          className="p-1 bg-paper/20 hover:bg-paper/30 text-paper-light border border-paper/20 transition-colors"
                                          title={`Воспроизвести морзянку: ${log.morse}`}
                                        >
                                          <Binary className="w-3 h-3 text-amber-300" />
                                        </button>
                                      )}

                                      {/* Quick Status Setter Dropdown/Cycle */}
                                      <div className="flex items-center gap-0.5 ml-1">
                                        {(['active', 'investigating', 'resolved', 'archived'] as RadioLogStatus[]).map((st) => (
                                          <button
                                            key={st}
                                            onClick={() => {
                                              radioLogsStore.updateLogStatus(log.id, st);
                                              audioEngine.playClick('toggle');
                                            }}
                                            className={`px-1 py-0.5 text-[8px] uppercase border transition-all ${
                                              log.status === st
                                                ? 'bg-blood text-paper-light border-blood font-bold'
                                                : 'bg-paper/10 text-paper/70 hover:text-paper-light border-paper/20'
                                            }`}
                                            title={`Установить статус: ${st}`}
                                          >
                                            {st === 'active' ? (
                                              <span className="flex items-center gap-0.5"><AlertTriangle className="w-2.5 h-2.5 text-blood" />ТР</span>
                                            ) : st === 'investigating' ? (
                                              <span className="flex items-center gap-0.5"><Clock className="w-2.5 h-2.5 text-amber-400" />ОБ</span>
                                            ) : st === 'resolved' ? (
                                              <span className="flex items-center gap-0.5"><CheckCircle className="w-2.5 h-2.5 text-emerald-400" />ПО</span>
                                            ) : (
                                              <span className="flex items-center gap-0.5"><Archive className="w-2.5 h-2.5 text-paper/70" />АР</span>
                                            )}
                                          </button>
                                        ))}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
