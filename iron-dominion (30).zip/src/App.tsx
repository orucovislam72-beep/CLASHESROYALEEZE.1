import { motion, AnimatePresence } from 'motion/react';
import { Target, Globe, BookOpen, Skull, Users, Coins, Eye, Radio, ShieldAlert, Crosshair, MapPin, X, AlertTriangle, CheckCircle, Maximize2, Minimize2, Paperclip, MoveDiagonal, ZoomIn, ZoomOut, Layers, Sparkles, Swords, Newspaper, Wrench, GitBranch, Scale, Flame, HardHat, FileText, Activity } from 'lucide-react';
import React, { useState, useEffect, useRef } from 'react';
import LivingWorldMap from './components/LivingWorldMap';
import CommanderGenerator from './components/CommanderGenerator';
import DiplomaticIntelligence from './components/DiplomaticIntelligence';
import TechDoctrineRadar from './components/TechDoctrineRadar';
import LogisticsNetwork from './components/LogisticsNetwork';
import ShadowPuppets from './components/ShadowPuppets';
import AudioController from './components/AudioController';
import SecretProjectColossus from './components/SecretProjectColossus';
import WarRoomTabletop from './components/WarRoomTabletop';
import PropagandaGazette from './components/PropagandaGazette';
import CounterIntelTribunal from './components/CounterIntelTribunal';
import ArsenalDesigner from './components/ArsenalDesigner';
import CrisisTimeline from './components/CrisisTimeline';
import GrandStrategyHUD from './components/GrandStrategyHUD';
import WorldChronicleModal from './components/WorldChronicleModal';
import EspionageHubModal from './components/EspionageHubModal';
import SecretScenariosModal from './components/SecretScenariosModal';
import DomesticPoliticsModal from './components/DomesticPoliticsModal';
import CrisisModal from './components/CrisisModal';
import TutorialOverlay from './components/TutorialOverlay';
import MainMenu from './components/MainMenu';
import { AudioTheme, audioEngine, RADIO_STATIONS } from './utils/audioEngine';
import { gameStore } from './utils/gameStore';
import { aiEventDirector } from './utils/aiEventDirector';
import { GameState } from './utils/gameState';

export interface FeatureItem {
  id: string;
  title: string;
  category: 'tactics' | 'rear' | 'politics' | 'archives';
  icon: any;
  description: string;
  stamp: string;
}

const features: FeatureItem[] = [
  {
    id: 'world',
    title: 'Живой мир',
    category: 'tactics',
    icon: Globe,
    description: 'Не просто клетки на карте — каждый регион имеет население с реальными нуждами, культурой и памятью. Сожги деревню в 1920-м — в 1940-м оттуда придут партизаны. Мир помнит всё.',
    stamp: 'DECLASSIFIED'
  },
  {
    id: 'war_room',
    title: 'Штабной Стол // ТВД',
    category: 'tactics',
    icon: Swords,
    description: 'Тактический стол оперативного командования: перемещение деревянных дивизионных маркеров, планирование фланговых «Клещей» и артподготовки, учет распутицы и симуляция прорыва фронта в реальном времени.',
    stamp: 'WAR ROOM // OPERATIONAL'
  },
  {
    id: 'arsenal',
    title: 'Арсенал & КБ №7',
    category: 'rear',
    icon: Wrench,
    description: 'Конструкторское бюро бронетехники и дизельпанк-арсенала. Модульная сборка танков, бронепоездов и дирижаблей: выбор шасси, калибра пушек, двигателей, брони и полигонные испытания.',
    stamp: 'BUREAU №7 // BLUEPRINT'
  },
  {
    id: 'gazette',
    title: 'Военная Газета & Цензура',
    category: 'rear',
    icon: Newspaper,
    description: 'Редакция «Штальбургских Ведомостей»: выбор передовиц, военные штампы цензуры, тиражирование пропаганды и влияние на моральный дух нации, работу военных заводов и бунты в тылу.',
    stamp: 'PRESS // CENSORED'
  },
  {
    id: 'tribunal',
    title: 'Контрразведка & Трибунал',
    category: 'politics',
    icon: ShieldAlert,
    description: 'Управление госбезопасности: прослушка телефонных кабелей, досье на высший генералитет, уровень паранойи верховного командования и вынесение вердиктов (оправдание, слежка, ссылка или трибунал).',
    stamp: 'SECRET POLICE // EYES ONLY'
  },
  {
    id: 'timeline',
    title: 'Хроника Развилок (1920–45)',
    category: 'archives',
    icon: GitBranch,
    description: 'Интерактивное дерево ключевых исторических решений межвоенного периода: Рурский кризис, крах биржи 1931 года, пограничные войны в Корсаке и альтернативные развилки Второй мировой.',
    stamp: 'TIMELINE // ARCHIVES'
  },
  {
    id: 'diplomacy',
    title: 'Дипломатия без скриптов',
    category: 'politics',
    icon: Users,
    description: 'Лидеры других держав — AI с характером, амбициями и личными обидами. Можно подружиться с диктатором через взятку, но его генерал тебя ненавидит и устроит переворот. Альянсы рушатся по-настоящему непредсказуемо.',
    stamp: 'CONFIDENTIAL'
  },
  {
    id: 'tech',
    title: 'Школы мысли',
    category: 'rear',
    icon: BookOpen,
    description: 'Нет линейного дерева tech tree. Есть исследовательские школы — ты вкладываешься в концепции (например, "манёвренная война" vs "война на истощение"), и они органично дают разные юниты, доктрины, и даже меняют менталитет армии.',
    stamp: 'RESTRICTED'
  },
  {
    id: 'economy',
    title: 'Экономика с кровью',
    category: 'rear',
    icon: Coins,
    description: 'Уголь, сталь, нефть, зерно — всё физически перемещается по карте поездами и кораблями. Перерезал железную дорогу врага — его фронтовые танки встали через 3 игровых дня. Можно выиграть войну, не убив ни одного солдата.',
    stamp: 'TOP SECRET'
  },
  {
    id: 'commanders',
    title: 'Живые командиры',
    category: 'tactics',
    icon: Skull,
    description: 'Генералы стареют, выгорают, предают, влюбляются в идеи, спорят с тобой на совещаниях. Можно назначить гения-алкоголика — он выиграет кампанию и пропьёт награды.',
    stamp: 'EYES ONLY'
  },
  {
    id: 'secret',
    title: 'Теневые кукловоды',
    category: 'politics',
    icon: Eye,
    description: 'Можно играть не за государство, а за тайную организацию — банкиров, масонов, спецслужбу — и дёргать за ниточки несколько держав одновременно. Победа определяется тем, насколько твоя организация контролирует мир через марионеток.',
    stamp: 'CLASSIFIED // BLACK'
  },
  {
    id: 'colossus',
    title: 'Проект «Колосс»',
    category: 'archives',
    icon: Sparkles,
    description: 'Запретные архивы Главного Штаба, обнаруженные при радиоперехвате волны 1939 кГц. Сверхтяжёлый шагоход «Колосс-IX», дешифратор «Энигма-1934» и засекреченные протоколы теневого синдиката.',
    stamp: 'CLASSIFIED // LEVEL 5'
  }
];


const TypewriterText = ({ text, delay = 30 }: { text: string, delay?: number }) => {
  const [displayedText, setDisplayedText] = useState('');
  
  useEffect(() => {
    setDisplayedText('');
    let i = 0;
    const interval = setInterval(() => {
      setDisplayedText(text.substring(0, i + 1));
      i++;
      if (i >= text.length) clearInterval(interval);
    }, delay);
    return () => clearInterval(interval);
  }, [text, delay]);

  return <span>{displayedText}</span>;
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'menu' | 'game'>('menu');
  const [activeFeature, setActiveFeature] = useState(features[0]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'tactics' | 'rear' | 'politics' | 'archives'>('all');
  const [time, setTime] = useState('');
  const [activeEvent, setActiveEvent] = useState<any>(null);
  const [gameState, setGameState] = useState<GameState>(gameStore.getState());

  // Simulation Modals State
  const [isChronicleOpen, setIsChronicleOpen] = useState<boolean>(false);
  const [isEspionageOpen, setIsEspionageOpen] = useState<boolean>(false);
  const [isSecretScenariosOpen, setIsSecretScenariosOpen] = useState<boolean>(false);
  const [isPoliticsOpen, setIsPoliticsOpen] = useState<boolean>(false);
  
  // Window Resizing State (PC Window Style)
  const [dossierHeight, setDossierHeight] = useState<number>(680);
  const [windowMode, setWindowMode] = useState<'normal' | 'wide' | 'fullscreen'>('normal');
  const [isClipFastened, setIsClipFastened] = useState<boolean>(true);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const resizeStartY = useRef<number>(0);
  const startHeight = useRef<number>(680);

  useEffect(() => {
    return gameStore.subscribe(setGameState);
  }, []);


  // Ref for gameState to avoid resetting interval
  const gameStateRef = useRef(gameState);
  useEffect(() => {
    gameStateRef.current = gameState;
  }, [gameState]);

  // AI Event Director Integration - Radio Intercepts
  useEffect(() => {
    const interval = setInterval(async () => {
      const currentState = gameStateRef.current;
      if (currentState.isPaused || currentState.activeCrisis) return;

      try {
        const event = await aiEventDirector.generateRadioEvent(currentState);
        if (event && event.title && event.desc) {
          setActiveEvent(event);
          
          // Auto-dismiss after 25 seconds if it has options, otherwise 15
          const timeout = (event.options && event.options.length > 0) ? 25000 : 15000;
          setTimeout(() => {
            setActiveEvent((prev: any) => (prev?.id === event.id ? null : prev));
          }, timeout);
        }
      } catch (error) {
        console.warn("AI Radio Intercept generation failed", error);
      }
    }, 5 * 60 * 1000); // 5 minutes

    return () => clearInterval(interval);
  }, []);

  // Audio theme dynamically switches
  const activeAudioTheme: AudioTheme | undefined = activeEvent ? 'orchestral' : undefined;

  const filteredFeatures = selectedCategory === 'all'
    ? features
    : features.filter(f => f.category === selectedCategory);

  const handleUnlockSecretTab = () => {
    const colossusFeature = features.find(f => f.id === 'colossus') || features[features.length - 1];
    setActiveFeature(colossusFeature);
    setSelectedCategory('archives');
  };

  const handleRegionClick = (region: any) => {
    let eventTitle = "";
    let eventDesc = "";
    let type = "alert";

    switch(region.name) {
      case "Остенмарк":
        eventTitle = "ВСПЫШКА НАСИЛИЯ";
        eventDesc = "Шахтёры помнят события 1923 года. Массовая забастовка парализовала поставки угля. Лояльность падает, требуется вмешательство гарнизона.";
        type = "alert";
        break;
      case "Корсак":
        eventTitle = "ПАРТИЗАНСКАЯ АТАКА";
        eventDesc = "Местное подполье подорвало военный эшелон в лесах. Потеряно 400 единиц оружия. Логистическая линия временно перерезана.";
        type = "alert";
        break;
      case "Ворн":
        eventTitle = "МАРШ ЛОЯЛИСТОВ";
        eventDesc = "Пропаганда работает идеально. Местное население добровольно сдает излишки зерна и записывается в рекруты. Угроза бунта снижена.";
        type = "success";
        break;
      case "Этельгард":
        eventTitle = "ТРЕБОВАНИЯ ЭЛИТ";
        eventDesc = "Промышленники угрожают саботажем заводов, если не получат квоты на сталь и нефть. Нарастает экономическая нестабильность.";
        type = "warning";
        break;
    }

    const newEvent = { title: eventTitle, desc: eventDesc, type, region: region.name, id: Date.now() };
    setActiveEvent(newEvent);

    // Auto-dismiss after 8 seconds
    setTimeout(() => {
      setActiveEvent((prev: any) => (prev?.id === newEvent.id ? null : prev));
    }, 8000);
  };

  const handleDismissEvent = () => {
    setActiveEvent(null);
  };

  // Centralized audio theme management based on active events
  useEffect(() => {
    if (activeEvent) {
      audioEngine.setTheme('orchestral');
    } else {
      audioEngine.setTheme('jazz');
    }
  }, [activeEvent]);

  // Drag to Resize Window Logic (PC corner resize)
  const handleMouseDownResize = (e: React.MouseEvent) => {
    e.preventDefault();
    setIsDragging(true);
    resizeStartY.current = e.clientY;
    startHeight.current = dossierHeight;
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaY = e.clientY - resizeStartY.current;
      const newHeight = Math.max(500, Math.min(1200, startHeight.current + deltaY));
      setDossierHeight(newHeight);
    };

    const handleMouseUp = () => {
      if (isDragging) {
        setIsDragging(false);
      }
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const cycleHeightPreset = () => {
    if (dossierHeight < 650) setDossierHeight(780);
    else if (dossierHeight < 850) setDossierHeight(980);
    else setDossierHeight(580);
  };

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toISOString().replace('T', ' ').substring(0, 19) + 'Z');
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  if (currentScreen === 'menu') {
    return (
      <MainMenu 
        onStartGame={() => setCurrentScreen('game')}
        onOpenChronicle={() => { setCurrentScreen('game'); setIsChronicleOpen(true); }}
        onOpenScenarios={() => { setCurrentScreen('game'); setIsSecretScenariosOpen(true); }}
      />
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden font-sans text-ink selection:bg-blood selection:text-paper-light">
      <div className="noise-overlay"></div>
      
      {/* Decorative Topo Lines Background */}
      <svg className="fixed top-0 left-0 w-full h-full pointer-events-none opacity-[0.03] text-ink z-0" viewBox="0 0 1000 1000" preserveAspectRatio="none">
        <path d="M0,200 Q250,300 500,200 T1000,200" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="M0,400 Q300,500 600,300 T1000,400" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="M0,600 Q200,800 500,600 T1000,700" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="M200,0 Q300,250 200,500 T200,1000" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="M700,0 Q800,250 700,500 T700,1000" fill="none" stroke="currentColor" strokeWidth="2" />
      </svg>

      {/* Main Container with Fullscreen / Wide mode adaptations */}
      <main className={`relative z-10 w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-10 min-h-screen flex flex-col transition-all duration-300 ${
        windowMode === 'fullscreen' ? 'max-w-[98vw]' : windowMode === 'wide' ? 'max-w-[94vw]' : 'max-w-7xl'
      }`}>
        
        {/* Header / Dossier Top */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-end border-b-2 border-ink pb-5 mb-6 gap-4">
          <div>
            <div className="flex items-center gap-3 mb-1.5 opacity-70">
              <ShieldAlert className="w-5 h-5 text-blood" />
              <span className="font-mono text-sm tracking-widest uppercase">File REF: IRN-DMN-01</span>
            </div>
            <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-ink uppercase">
              Iron Dominion
            </h1>
            <p className="font-mono text-ink-light mt-1 max-w-2xl text-xs sm:text-sm">
              Глобальная 4X стратегия в реальном времени с паузой. Альтернативная история XX века.
            </p>
          </div>
          
          <div className="flex flex-col items-start md:items-end gap-2.5 shrink-0">
            <div className="flex items-center gap-2">
              <div className="font-mono text-xs bg-ink text-paper-light px-2.5 py-1">
                TOP SECRET // EYES ONLY
              </div>
              <AudioController 
                activeAlertTheme={activeAudioTheme} 
                compact={true} 
                onUnlockSecretTab={handleUnlockSecretTab}
                latestEvent={activeEvent}
              />
            </div>

            <div className="font-mono text-xs opacity-70 flex items-center gap-2">
              <Radio className="w-3 h-3 animate-pulse text-blood" />
              SYS.TIME: {time}
            </div>
          </div>
        </header>

        {/* Grand Strategy Unified State HUD & Ticking Engine */}
        <div className="mb-6">
          <GrandStrategyHUD
            onOpenChronicle={() => setIsChronicleOpen(true)}
            onOpenEspionage={() => setIsEspionageOpen(true)}
            onOpenSecretScenarios={() => setIsSecretScenariosOpen(true)}
            onOpenPolitics={() => setIsPoliticsOpen(true)}
          />
        </div>

        {/* Content Grid */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
          
          {/* Left Sidebar - Navigation & Radio */}
          <div className={`${windowMode === 'fullscreen' ? 'lg:col-span-3' : 'lg:col-span-4'} flex flex-col gap-3`}>
            <div className="font-mono text-xs tracking-widest text-ink-light uppercase border-b border-ink/20 pb-2 flex items-center justify-between">
              <span className="flex items-center gap-2">
                <MapPin className="w-3 h-3 text-blood" />
                Штабные Департаменты
              </span>
              <span className="text-[10px] text-ink/40 font-bold">{features.length} МОДУЛЕЙ</span>
            </div>

            {/* Department Category Filter Bar */}
            <div className="grid grid-cols-5 gap-1 font-mono text-[9px] uppercase font-bold bg-ink/5 p-1 border border-ink/20">
              {[
                { id: 'all', label: 'Все' },
                { id: 'tactics', label: 'Фронт' },
                { id: 'rear', label: 'Тыл' },
                { id: 'politics', label: 'Тайны' },
                { id: 'archives', label: 'Архив' }
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id as any)}
                  className={`py-1 px-1 text-center transition-all ${
                    selectedCategory === cat.id
                      ? 'bg-ink text-paper-light border-blood shadow-sm font-bold'
                      : 'hover:bg-ink/10 text-ink/70'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
            
            <nav className="flex flex-col gap-1.5 max-h-[380px] overflow-y-auto pr-1">
              {filteredFeatures.map((feature) => {
                const isEasterEgg = feature.id === 'colossus';
                const isCurrent = activeFeature.id === feature.id;
                return (
                  <button
                    key={feature.id}
                    onClick={() => { setActiveFeature(feature); audioEngine.playMorseBeep(false); }}
                    className={`flex items-center gap-3 p-2.5 sm:p-3 text-left border transition-all duration-200 relative group ${
                      isCurrent 
                        ? isEasterEgg
                          ? 'bg-blood text-paper-light border-blood shadow-lg'
                          : 'bg-ink text-paper-light border-ink shadow-md' 
                        : isEasterEgg
                          ? 'bg-amber-500/10 hover:bg-amber-500/20 border-blood/40 text-blood'
                          : 'bg-paper/60 hover:bg-paper border-ink/10 hover:border-ink/40'
                    }`}
                  >
                    {isCurrent && (
                      <motion.div 
                        layoutId="activeTabIndicator"
                        className={`absolute left-0 top-0 bottom-0 w-1.5 ${isEasterEgg ? 'bg-amber-300' : 'bg-blood'}`}
                      />
                    )}
                    <feature.icon className={`w-4 h-4 sm:w-5 sm:h-5 shrink-0 ${
                      isCurrent 
                        ? isEasterEgg ? 'text-amber-300 animate-spin-slow' : 'text-blood' 
                        : isEasterEgg ? 'text-blood animate-pulse' : 'text-ink-light group-hover:text-ink'
                    }`} />
                    <div className="flex flex-col min-w-0 flex-1">
                      <span className="font-serif text-sm sm:text-base leading-tight truncate">{feature.title}</span>
                      <span className={`font-mono text-[8px] uppercase tracking-wider truncate ${
                        isCurrent 
                          ? 'text-paper-light/70' 
                          : isEasterEgg ? 'text-blood/80 font-bold' : 'text-ink/40'
                      }`}>
                        {feature.stamp}
                      </span>
                    </div>
                    {isCurrent && (
                      <Crosshair className="w-3.5 h-3.5 opacity-60 animate-spin-slow shrink-0" />
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Audio Controller Panel inside Visual & Atmosphere Box */}
            <div className="mt-1">
              <AudioController 
                activeAlertTheme={activeAudioTheme} 
                compact={false} 
                onUnlockSecretTab={handleUnlockSecretTab}
                latestEvent={activeEvent}
              />
            </div>

            {/* PC Window Scaling Quick Box */}
            <div className="p-4 border border-ink/20 bg-paper/40 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-ink/15 pb-1.5 mb-2">
                <span className="text-[10px] uppercase font-bold text-ink/70">Масштаб окна досье (PC Режим)</span>
                <span className="text-blood font-bold">{dossierHeight}px</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 mb-2">
                <button
                  onClick={() => { setDossierHeight(580); setWindowMode('normal'); }}
                  className={`px-2 py-1 text-[10px] uppercase border font-bold transition-all ${
                    dossierHeight <= 600 && windowMode === 'normal'
                      ? 'bg-ink text-paper-light border-ink'
                      : 'bg-paper hover:bg-ink/10 border-ink/20'
                  }`}
                >
                  Компакт
                </button>
                <button
                  onClick={() => { setDossierHeight(760); setWindowMode('wide'); }}
                  className={`px-2 py-1 text-[10px] uppercase border font-bold transition-all ${
                    windowMode === 'wide'
                      ? 'bg-ink text-paper-light border-ink'
                      : 'bg-paper hover:bg-ink/10 border-ink/20'
                  }`}
                >
                  Широкий
                </button>
                <button
                  onClick={() => { setDossierHeight(950); setWindowMode('fullscreen'); }}
                  className={`px-2 py-1 text-[10px] uppercase border font-bold transition-all ${
                    windowMode === 'fullscreen'
                      ? 'bg-blood text-paper-light border-blood'
                      : 'bg-paper hover:bg-ink/10 border-ink/20'
                  }`}
                >
                  Максимум
                </button>
              </div>
              <div className="text-[10px] text-ink/50 italic leading-snug">
                * Вы также можете тянуть за уголок справа внизу досье для произвольного размера.
              </div>
            </div>
          </div>

          {/* Right Main Content Area - Resizable Interactive PC Window */}
          <div className={`${windowMode === 'fullscreen' ? 'lg:col-span-9' : 'lg:col-span-8'} relative flex flex-col`}>
            
            {/* Main Dossier Container */}
            <div 
              style={{ height: `${dossierHeight}px` }}
              className="w-full border-2 border-ink bg-paper-light p-1 shadow-2xl relative flex flex-col transition-[height] duration-75 select-text"
            >
              {/* PC Window Top Control Header Bar */}
              <div className="w-full bg-ink text-paper-light px-3 py-1.5 flex items-center justify-between border-b border-ink font-mono text-xs select-none">
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${activeFeature.id === 'colossus' ? 'bg-amber-400 animate-ping' : 'bg-blood'}`} />
                  <span className="font-bold tracking-wider text-[11px] uppercase">
                    DOSSIER_VIEWER // {activeFeature.id.toUpperCase()} // RES: {dossierHeight}px
                  </span>
                </div>

                {/* PC Window Action Controls */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      setDossierHeight(prev => Math.max(500, prev - 100));
                    }}
                    className="p-1 hover:bg-paper/20 text-paper-light transition-colors"
                    title="Уменьшить высоту окна"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      setDossierHeight(prev => Math.min(1200, prev + 100));
                    }}
                    className="p-1 hover:bg-paper/20 text-paper-light transition-colors"
                    title="Увеличить высоту окна"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>

                  <div className="w-[1px] h-3 bg-paper/30 mx-1" />

                  <button
                    onClick={() => setWindowMode(prev => prev === 'fullscreen' ? 'normal' : 'fullscreen')}
                    className={`p-1 transition-colors flex items-center gap-1 px-1.5 text-[10px] uppercase font-bold ${
                      windowMode === 'fullscreen' ? 'bg-blood text-paper-light' : 'hover:bg-paper/20 text-paper-light'
                    }`}
                    title={windowMode === 'fullscreen' ? "Обычный вид" : "Развернуть на весь экран"}
                  >
                    {windowMode === 'fullscreen' ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                    <span className="hidden sm:inline">{windowMode === 'fullscreen' ? 'Свернуть' : 'Развернуть'}</span>
                  </button>
                </div>
              </div>

              {/* Dossier Document Inner Body */}
              <div className="w-full flex-1 border border-ink/20 bg-paper/30 p-5 md:p-8 relative overflow-y-auto overflow-x-hidden flex flex-col">
                
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeFeature.id}
                    initial={{ opacity: 0, y: 10, filter: 'blur(4px)' }}
                    animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                    exit={{ opacity: 0, y: -10, filter: 'blur(4px)' }}
                    transition={{ duration: 0.35, ease: "easeOut" }}
                    className="flex-1 flex flex-col relative z-10"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <activeFeature.icon className={`w-9 h-9 ${activeFeature.id === 'colossus' ? 'text-blood' : 'text-ink/40'}`} />
                      
                      {/* Fake Ink Stamp */}
                      <div className="transform rotate-6 border-4 border-stamp text-stamp px-3.5 py-0.5 font-mono text-base md:text-lg font-bold tracking-widest opacity-85 shadow-sm mix-blend-multiply">
                        {activeFeature.stamp}
                      </div>
                    </div>

                    <h2 className="font-serif text-2xl sm:text-4xl md:text-5xl font-bold mb-4 text-ink leading-tight">
                      {activeFeature.title}
                    </h2>
                    
                    <div className="prose prose-lg prose-p:font-mono prose-p:text-ink-light prose-p:leading-relaxed max-w-none mb-4">
                      <p className="text-sm md:text-base">
                        {activeFeature.description}
                      </p>
                    </div>

                    {/* Feature 1: Living World Map */}
                    {activeFeature.id === 'world' && (
                      <div className="mt-2 flex-1 min-h-[350px]">
                        <LivingWorldMap 
                          onRegionClick={handleRegionClick} 
                          activeEventRegion={activeEvent?.region}
                        />
                      </div>
                    )}

                    {/* Feature 2: War Room Tabletop (NEW) */}
                    {activeFeature.id === 'war_room' && (
                      <div className="mt-2 flex-1">
                        <WarRoomTabletop />
                      </div>
                    )}

                    {/* Feature 3: Arsenal & Bureau No. 7 Designer (NEW) */}
                    {activeFeature.id === 'arsenal' && (
                      <div className="mt-2 flex-1">
                        <ArsenalDesigner />
                      </div>
                    )}

                    {/* Feature 4: Propaganda & Censorship Gazette (NEW) */}
                    {activeFeature.id === 'gazette' && (
                      <div className="mt-2 flex-1">
                        <PropagandaGazette />
                      </div>
                    )}

                    {/* Feature 5: Counter Intelligence & Loyalty Tribunal (NEW) */}
                    {activeFeature.id === 'tribunal' && (
                      <div className="mt-2 flex-1">
                        <CounterIntelTribunal />
                      </div>
                    )}

                    {/* Feature 6: Crisis Timeline & Branching History (NEW) */}
                    {activeFeature.id === 'timeline' && (
                      <div className="mt-2 flex-1">
                        <CrisisTimeline />
                      </div>
                    )}

                    {/* Feature 7: Diplomatic Intelligence */}
                    {activeFeature.id === 'diplomacy' && (
                      <div className="mt-2 flex-1">
                        <DiplomaticIntelligence />
                      </div>
                    )}

                    {/* Feature 8: Non-linear Tech & Doctrine Radar */}
                    {activeFeature.id === 'tech' && (
                      <div className="mt-2 flex-1">
                        <TechDoctrineRadar />
                      </div>
                    )}

                    {/* Feature 9: Physical Supply Line & Convoy Logistics */}
                    {activeFeature.id === 'economy' && (
                      <div className="mt-2 flex-1">
                        <LogisticsNetwork />
                      </div>
                    )}

                    {/* Feature 10: Living Commanders */}
                    {activeFeature.id === 'commanders' && (
                      <div className="mt-2 flex-1">
                        <CommanderGenerator />
                      </div>
                    )}

                    {/* Feature 11: Shadow Puppeteers & Conspiracy Board */}
                    {activeFeature.id === 'secret' && (
                      <div className="mt-2 flex-1">
                        <ShadowPuppets />
                      </div>
                    )}

                    {/* Feature 12: Secret Project Colossus (Easter Egg Module) */}
                    {activeFeature.id === 'colossus' && (
                      <div className="mt-2 flex-1">
                        <SecretProjectColossus />
                      </div>
                    )}

                    <div className="mt-auto pt-6 flex justify-between items-end border-t border-ink/10">
                      <div className="font-mono text-xs text-ink/40">
                        СТРАНИЦА {features.findIndex(f => f.id === activeFeature.id) + 1} ИЗ {features.length}
                      </div>
                      <div className="font-mono text-xs text-ink/40 flex items-center gap-2">
                        <Target className="w-3 h-3" />
                        СТАТУС: УТВЕРЖДЕНО ГЕНШТАБОМ
                      </div>
                    </div>
                  </motion.div>
                </AnimatePresence>

                {/* Decorative map elements inside the dossier */}
                <div className="absolute -bottom-24 -right-24 w-96 h-96 border-[1px] border-ink/5 rounded-full pointer-events-none" />
                <div className="absolute -bottom-32 -right-32 w-96 h-96 border-[1px] border-ink/5 rounded-full pointer-events-none" />
              </div>

              {/* PC WINDOW CORNER RESIZE HANDLE (КАК В КОМПЬЮТЕРЕ ПО КРАЯМ/УГЛАМ) */}
              <div 
                onMouseDown={handleMouseDownResize}
                onClick={cycleHeightPreset}
                className="absolute bottom-0 right-0 w-8 h-8 cursor-nwse-resize z-30 flex items-end justify-end p-1 group select-none"
                title="Тяните за край или кликните для изменения размера досье (как в окне ПК)"
              >
                {/* Diagonal Grip Lines */}
                <div className="flex flex-col items-end gap-[2px] opacity-60 group-hover:opacity-100 transition-opacity">
                  <div className="w-5 h-[2px] bg-ink group-hover:bg-blood transition-colors -rotate-45 translate-x-1" />
                  <div className="w-3.5 h-[2px] bg-ink group-hover:bg-blood transition-colors -rotate-45 translate-x-1" />
                  <div className="w-2 h-[2px] bg-ink group-hover:bg-blood transition-colors -rotate-45 translate-x-1" />
                </div>
                <div className="absolute bottom-1 right-1 text-[8px] font-mono text-ink/40 opacity-0 group-hover:opacity-100 transition-opacity font-bold">
                  RESIZE
                </div>
              </div>

              {/* Left Edge Indicator */}
              <div 
                onClick={cycleHeightPreset}
                className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-ink/40 hover:border-blood cursor-pointer z-30 transition-colors"
                title="Кликните для переключения размера"
              />
            </div>

            {/* ENLARGED REALISTIC METALLIC BINDER CLIP / ЗАКРЕПКА-ЗАЖИМ ДЛЯ БУМАГ */}
            <div 
              onClick={() => setIsClipFastened(prev => !prev)}
              className="absolute -top-5 left-10 md:left-14 z-40 cursor-pointer group select-none"
              title={isClipFastened ? "Зажим закреплён. Кликните чтобы отстегнуть!" : "Зажим отстёгнут. Кликните чтобы закрепить!"}
            >
              <motion.div
                animate={{ 
                  y: isClipFastened ? 0 : -6, 
                  rotate: isClipFastened ? -4 : 8,
                  scale: isClipFastened ? 1 : 1.06
                }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
                className="relative"
              >
                {/* Metallic Chrome Body */}
                <div className="w-12 h-20 md:w-14 md:h-24 rounded-full border-[3px] border-slate-700 bg-gradient-to-r from-slate-300 via-slate-100 to-slate-400 shadow-[4px_6px_12px_rgba(0,0,0,0.35)] flex flex-col items-center justify-between p-1.5">
                  {/* Clip wire loop inner cutout */}
                  <div className="w-6 h-12 md:w-7 md:h-14 rounded-full border-2 border-slate-600/80 bg-paper/40 mt-1 shadow-inner" />
                  
                  {/* Metal Rivet / Fastener Dot */}
                  <div className="w-3 h-3 rounded-full bg-gradient-to-b from-slate-600 to-slate-900 border border-slate-400 shadow-sm" />
                </div>

                {/* Heavy Cast Shadow */}
                <div className="absolute -bottom-1 left-2 w-10 h-3 bg-black/30 rounded-full blur-[2px] -z-10" />

                {/* Interactive Tooltip Badge on Hover */}
                <div className="absolute -top-6 -left-6 bg-ink text-paper-light font-mono text-[9px] uppercase px-2 py-0.5 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity border border-paper/40 shadow-lg pointer-events-none">
                  {isClipFastened ? "ЗАКРЕПКА: СЖАТА [КЛИК]" : "ЗАКРЕПКА: СНЯТА"}
                </div>
              </motion.div>
            </div>

            {/* Bottom Corner Binder Pin (Нижняя закрепка-уголок) */}
            <div 
              onClick={() => setIsClipFastened(prev => !prev)}
              className="absolute -bottom-4 right-12 z-40 cursor-pointer group select-none hidden sm:block"
              title="Нижняя металлическая скоба досье"
            >
              <div className="w-10 h-14 rounded-full border-2 border-slate-700 bg-gradient-to-tr from-slate-400 via-slate-100 to-slate-300 shadow-lg rotate-45 transform flex items-center justify-center">
                <div className="w-4 h-7 rounded-full border border-slate-600 bg-paper/30" />
              </div>
            </div>

          </div>
        </div>

        {/* Footer */}
        <footer className="mt-10 pt-5 border-t-2 border-ink/20 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="font-serif italic text-ink-light text-sm sm:text-base">
            "Hearts of Iron встречает Crusader Kings..."
          </div>
          <div className="flex items-center gap-2">
            <div className="font-mono text-xs text-ink/60 bg-ink/5 px-3 py-1.5 border border-ink/10">
              IRON DOMINION ENGINE v1.0 // UNIFIED SIMULATION
            </div>
          </div>
        </footer>
      </main>

      {/* Grand Strategy Unified Simulation Modals */}
      <WorldChronicleModal
        isOpen={isChronicleOpen}
        onClose={() => setIsChronicleOpen(false)}
      />

      <EspionageHubModal
        isOpen={isEspionageOpen}
        onClose={() => setIsEspionageOpen(false)}
      />

      <SecretScenariosModal
        isOpen={isSecretScenariosOpen}
        onClose={() => setIsSecretScenariosOpen(false)}
      />

      <DomesticPoliticsModal
        isOpen={isPoliticsOpen}
        onClose={() => setIsPoliticsOpen(false)}
      />

      <CrisisModal
        crisis={gameState.activeCrisis}
      />

      {/* Global Event Overlay (Radio Intercept) */}
      <AnimatePresence>
        {activeEvent && (
          <motion.div
            key={activeEvent.id}
            initial={{ opacity: 0, x: 50, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 20, scale: 0.95, filter: 'blur(4px)' }}
            className={`fixed bottom-6 right-6 md:bottom-12 md:right-12 z-50 w-[90vw] max-w-sm border-2 bg-ink text-paper-light shadow-2xl overflow-hidden ${
              activeEvent.type === 'alert' ? 'border-blood' :
              activeEvent.type === 'warning' ? 'border-amber-500' : 'border-emerald-500'
            }`}
          >
            <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(0,0,0,0.2)_50%)] bg-[length:100%_4px] pointer-events-none opacity-50 z-0" />
            
            <div className="relative z-10 p-5 flex flex-col gap-3">
              <div className="flex items-center justify-between border-b border-paper/20 pb-2">
                <div className="flex items-center gap-2">
                  <Radio className={`w-4 h-4 animate-pulse ${
                    activeEvent.type === 'alert' ? 'text-blood' :
                    activeEvent.type === 'warning' ? 'text-amber-500' : 'text-emerald-500'
                  }`} />
                  <span className="font-mono text-xs tracking-widest uppercase opacity-80">
                    РАДИОПЕРЕХВАТ // {activeEvent.region}
                  </span>
                </div>
                <button 
                  onClick={handleDismissEvent}
                  className="opacity-50 hover:opacity-100 transition-opacity p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex gap-3 mt-1">
                <div className="mt-1 shrink-0">
                  {activeEvent.type === 'alert' && <AlertTriangle className="w-6 h-6 text-blood" />}
                  {activeEvent.type === 'warning' && <AlertTriangle className="w-6 h-6 text-amber-500" />}
                  {activeEvent.type === 'success' && <CheckCircle className="w-6 h-6 text-emerald-500" />}
                </div>
                <div className="flex flex-col gap-1.5 w-full">
                  <h4 className={`font-serif font-bold text-lg uppercase leading-tight ${
                    activeEvent.type === 'alert' ? 'text-blood' :
                    activeEvent.type === 'warning' ? 'text-amber-500' : 'text-emerald-500'
                  }`}>
                    {activeEvent.title}
                  </h4>
                  <p className="font-mono text-sm opacity-90 leading-relaxed">
                    <TypewriterText text={activeEvent.desc} delay={25} />
                  </p>
                  
                  {activeEvent.options && activeEvent.options.length > 0 && (
                    <div className="flex flex-col gap-2 mt-3 w-full">
                      {activeEvent.options.map((opt: any, idx: number) => (
                        <button
                          key={idx}
                          onClick={() => {
                            if (opt.effect) {
                              gameStore.applyQuickEffect(opt.effect);
                            }
                            handleDismissEvent();
                          }}
                          className="w-full text-left bg-black/40 hover:bg-black/60 border border-paper/10 hover:border-paper/40 p-2 text-xs font-mono transition-colors"
                        >
                          <span className="text-amber-400 font-bold block mb-1">► {opt.text}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tutorial Overlay */}
      {!gameState.tutorialCompleted && <TutorialOverlay activeTabId={activeFeature.id} />}

      <style>{`
        .animate-spin-slow {
          animation: spin 8s linear infinite;
        }
      `}</style>
    </div>
  );
}
