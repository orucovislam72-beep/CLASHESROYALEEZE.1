import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.irondominiongame.app',
  appName: 'Iron Dominion',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
