#!/usr/bin/env bash
# ==============================================================================
# Iron Dominion - Android Release Keystore Generator Helper
# ==============================================================================
# This script generates a secure, persistent RSA-2048 signing keystore for
# Iron Dominion Android APK / AAB releases with a 10,000-day validity period.
#
# NOTE: The resulting keystore file (.keystore / .jks) is strictly ignored in .gitignore
# and must NEVER be committed to Git.
# ==============================================================================

set -e

KEYSTORE_NAME="release.keystore"
KEY_ALIAS="iron-dominion"
KEYSTORE_OUTPUT="./android/${KEYSTORE_NAME}"

echo "======================================================="
echo "   IRON DOMINION - RELEASE KEYSTORE GENERATOR"
echo "======================================================="

if [ -f "$KEYSTORE_OUTPUT" ]; then
    echo "⚠️ Keystore already exists at: $KEYSTORE_OUTPUT"
    echo "Aborting to prevent overwriting existing keys."
    exit 0
fi

if ! command -v keytool &> /dev/null; then
    echo "❌ Error: 'keytool' utility (part of Java JDK) is required."
    echo "Please run this command in an environment with OpenJDK / Java 17+ installed."
    exit 1
fi

echo "Generating permanent release keystore..."
keytool -genkey -v \
    -keystore "$KEYSTORE_OUTPUT" \
    -alias "$KEY_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -dname "CN=Iron Dominion, OU=Gaming Division, O=Iron Dominion Studios, L=General Staff, ST=HQ, C=WW"

echo "✅ Keystore successfully generated at: $KEYSTORE_OUTPUT"
echo ""
echo "To convert this keystore into a Base64 secret for GitHub Actions (CI/CD), run:"
echo "  base64 -w 0 $KEYSTORE_OUTPUT"
echo "======================================================="
